import api from '@/api'

export default {
    namespaced: true,
    state: () => ({
      user: null,
      token: localStorage.getItem('token') || null
    }),
    mutations: {
      SET_USER(state, user) {
        state.user = user
      },
      SET_TOKEN(state, token) {
        state.token = token
        localStorage.setItem('token', token)
      },
      CLEAR_AUTH(state) {
        state.user = null
        state.token = null
        localStorage.removeItem('token')
      }
    },
    actions: {
      async login({ commit }, credentials) {
        try {
          const response = await api.login(credentials)
          commit('SET_TOKEN', response.access_token)
          
          // Obtener el perfil del usuario
          const userProfile = await api.getProfile()
          commit('SET_USER', userProfile)
          
          return response
        } catch (error) {
          console.error('Error de login:', error)
          throw error
        }
      },
      async register({ commit }, userData) {
        try {
          const response = await api.register(userData)
          commit('SET_TOKEN', response.access_token)
          
          // Obtener el perfil del usuario
          const userProfile = await api.getProfile()
          commit('SET_USER', userProfile)
          
          return response
        } catch (error) {
          console.error('Error de registro:', error)
          throw error
        }
      },
      async logout({ commit }) {
        commit('CLEAR_AUTH')
      },
      async checkAuth({ commit, state }) {
        if (!state.token) return false
        
        try {
          const userProfile = await api.getProfile()
          commit('SET_USER', userProfile)
          return true
        } catch (error) {
          commit('CLEAR_AUTH')
          return false
        }
      }
    },
    getters: {
      isAuthenticated: state => !!state.token,
      currentUser: state => state.user
    }
  }