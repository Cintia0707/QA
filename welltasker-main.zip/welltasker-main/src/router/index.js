import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AuthView from '../views/AuthView.vue'
import WorkspaceView from '../views/WorkspaceView.vue'
import LimboView from '../views/LimboView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/auth',
    name: 'auth',
    component: AuthView,
    meta: { requiresGuest: true }
  },
  {
    path: '/login',
    redirect: { path: '/auth', query: { mode: 'login' } }
  },
  {
    path: '/register',
    redirect: { path: '/auth', query: { mode: 'register' } }
  },
  {
    path: '/workspace',
    component: WorkspaceView,
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        redirect: '/workspace/projects'
      },
      {
        path: 'projects',
        name: 'projects',
        component: () => import('../views/workspace/ProjectsView.vue')
      },
      {
        path: 'projects/new',
        name: 'new-project',
        component: () => import('../views/workspace/NewProjectView.vue')
      },
      {
        path: 'tasks',
        name: 'tasks',
        component: () => import('../views/workspace/TasksView.vue')
      },
      {
        path: 'tasks/new',
        name: 'new-task',
        component: () => import('../views/workspace/NewTaskView.vue')
      },
      {
        path: 'files',
        name: 'files',
        component: () => import('../views/workspace/FilesView.vue')
      },
      {
        path: 'files/upload',
        name: 'upload-files',
        component: () => import('../views/workspace/UploadFilesView.vue')
      },
      {
        path: 'chat',
        name: 'chat',
        component: () => import('../views/workspace/ChatView.vue')
      },
      {
        path: 'video-calls',
        name: 'video-calls',
        component: () => import('../views/workspace/VideoCallsView.vue')
      },
      {
        path: 'reports',
        name: 'reports',
        component: () => import('../views/workspace/ReportsView.vue')
      },
      {
        path: 'settings',
        name: 'settings',
        component: () => import('../views/workspace/SettingsView.vue')
      },
      {
        path: 'language',
        name: 'language',
        component: () => import('../views/workspace/LanguageView.vue')
      }
    ]
  },
  {
    path: '/limbo',
    name: 'Limbo',
    component: LimboView,
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory('/'),
  routes
})

// Función para verificar si el usuario está autenticado
const isAuthenticated = () => {
  const token = localStorage.getItem('token');
  return !!token;
};

// Guardia de navegación global
router.beforeEach((to, from, next) => {
  // Verificar si la ruta requiere autenticación
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
  
  // Si la ruta requiere autenticación y el usuario no está autenticado
  if (requiresAuth && !isAuthenticated()) {
    // Redirigir al login
    next({ name: 'auth' });
  } else {
    // Si el usuario está autenticado y trata de acceder a la página de login
    if (to.name === 'auth' && isAuthenticated()) {
      // Redirigir al limbo
      next({ name: 'limbo' });
    } else {
      next();
    }
  }
});

export default router