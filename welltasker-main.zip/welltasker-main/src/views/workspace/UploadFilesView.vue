<template>
  <div class="upload-files-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Subir Archivos</h1>
    </div>

    <div class="view-content" data-aos="fade-up" data-aos-delay="100">
      <div class="upload-area" 
           :class="{ 'dragging': isDragging }"
           @dragenter.prevent="isDragging = true"
           @dragleave.prevent="isDragging = false"
           @dragover.prevent
           @drop.prevent="handleDrop"
           @click="triggerFileInput">
        <input 
          type="file" 
          ref="fileInput"
          multiple
          @change="handleFileSelect"
          style="display: none"
        >
        <div class="upload-content">
          <i class="fas fa-cloud-upload-alt"></i>
          <h3>Arrastra y suelta tus archivos aquí</h3>
          <p>o</p>
          <button class="browse-btn">Examinar Archivos</button>
          <p class="file-types">Tipos de archivo permitidos: PDF, DOC, DOCX, XLS, XLSX, JPG, PNG, ZIP</p>
        </div>
      </div>

      <div v-if="selectedFiles.length > 0" class="files-list">
        <div class="list-header">
          <h2>Archivos Seleccionados ({{ selectedFiles.length }})</h2>
          <button class="upload-btn" @click="uploadFiles" :disabled="uploading">
            <i class="fas fa-upload"></i>
            {{ uploading ? 'Subiendo...' : 'Subir Archivos' }}
          </button>
        </div>

        <div class="files-grid">
          <div v-for="file in selectedFiles" :key="file.id" class="file-card">
            <div class="file-icon">
              <i :class="getFileIcon(file.type)"></i>
            </div>
            <div class="file-info">
              <h3>{{ file.name }}</h3>
              <p>{{ formatFileSize(file.size) }}</p>
            </div>
            <div class="file-actions">
              <button class="action-btn" @click="removeFile(file)">
                <i class="fas fa-times"></i>
              </button>
            </div>
            <div class="upload-progress" v-if="file.uploading">
              <div class="progress-bar">
                <div class="progress" :style="{ width: file.progress + '%' }"></div>
              </div>
              <span class="progress-text">{{ file.progress }}%</span>
            </div>
          </div>
        </div>
      </div>

      <div class="upload-options">
        <div class="option-group">
          <label>Proyecto</label>
          <select v-model="uploadOptions.project">
            <option value="">Seleccionar Proyecto</option>
            <option v-for="project in projects" :key="project.id" :value="project.id">
              {{ project.name }}
            </option>
          </select>
        </div>

        <div class="option-group">
          <label>Permisos</label>
          <div class="permissions-options">
            <label class="permission-option">
              <input type="checkbox" v-model="uploadOptions.permissions" value="private">
              <span>Privado</span>
            </label>
            <label class="permission-option">
              <input type="checkbox" v-model="uploadOptions.permissions" value="team">
              <span>Equipo</span>
            </label>
            <label class="permission-option">
              <input type="checkbox" v-model="uploadOptions.permissions" value="public">
              <span>Público</span>
            </label>
          </div>
        </div>

        <div class="option-group">
          <label>Etiquetas</label>
          <div class="tags-input">
            <div class="tags-container">
              <span 
                v-for="tag in uploadOptions.tags" 
                :key="tag"
                class="tag"
              >
                {{ tag }}
                <button class="remove-tag" @click="removeTag(tag)">×</button>
              </span>
            </div>
            <input 
              type="text"
              v-model="newTag"
              @keyup.enter="addTag"
              placeholder="Añadir etiqueta..."
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UploadFilesView',
  data() {
    return {
      isDragging: false,
      selectedFiles: [],
      uploading: false,
      newTag: '',
      uploadOptions: {
        project: '',
        permissions: ['private'],
        tags: []
      },
      projects: [
        { id: 1, name: 'Sitio Web Corporativo' },
        { id: 2, name: 'Aplicación Móvil' },
        { id: 3, name: 'Rediseño de Marca' }
      ]
    }
  },
  methods: {
    triggerFileInput() {
      this.$refs.fileInput.click()
    },
    handleFileSelect(event) {
      const files = Array.from(event.target.files)
      this.addFiles(files)
    },
    handleDrop(event) {
      this.isDragging = false
      const files = Array.from(event.dataTransfer.files)
      this.addFiles(files)
    },
    addFiles(files) {
      files.forEach(file => {
        if (this.isValidFileType(file)) {
          this.selectedFiles.push({
            id: Date.now() + Math.random(),
            name: file.name,
            size: file.size,
            type: file.type,
            file: file,
            uploading: false,
            progress: 0
          })
        } else {
          // Mostrar mensaje de error para archivos no válidos
          console.error(`Tipo de archivo no válido: ${file.name}`)
        }
      })
    },
    isValidFileType(file) {
      const validTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'image/jpeg',
        'image/png',
        'application/zip'
      ]
      return validTypes.includes(file.type)
    },
    getFileIcon(type) {
      const icons = {
        'application/pdf': 'fas fa-file-pdf',
        'application/msword': 'fas fa-file-word',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'fas fa-file-word',
        'application/vnd.ms-excel': 'fas fa-file-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'fas fa-file-excel',
        'image/jpeg': 'fas fa-file-image',
        'image/png': 'fas fa-file-image',
        'application/zip': 'fas fa-file-archive'
      }
      return icons[type] || 'fas fa-file'
    },
    formatFileSize(bytes) {
      if (bytes === 0) return '0 Bytes'
      const k = 1024
      const sizes = ['Bytes', 'KB', 'MB', 'GB']
      const i = Math.floor(Math.log(bytes) / Math.log(k))
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
    },
    removeFile(file) {
      const index = this.selectedFiles.findIndex(f => f.id === file.id)
      if (index !== -1) {
        this.selectedFiles.splice(index, 1)
      }
    },
    addTag() {
      if (this.newTag && !this.uploadOptions.tags.includes(this.newTag)) {
        this.uploadOptions.tags.push(this.newTag)
        this.newTag = ''
      }
    },
    removeTag(tag) {
      const index = this.uploadOptions.tags.indexOf(tag)
      if (index !== -1) {
        this.uploadOptions.tags.splice(index, 1)
      }
    },
    async uploadFiles() {
      this.uploading = true
      
      for (const file of this.selectedFiles) {
        file.uploading = true
        file.progress = 0

        try {
          // Simular carga de archivo
          await this.simulateFileUpload(file)
          file.progress = 100
        } catch (error) {
          console.error('Error al subir archivo:', error)
        }
      }

      this.uploading = false
      // Limpiar lista de archivos después de la carga
      this.selectedFiles = []
    },
    simulateFileUpload(file) {
      return new Promise((resolve) => {
        let progress = 0
        const interval = setInterval(() => {
          progress += 10
          file.progress = progress

          if (progress >= 100) {
            clearInterval(interval)
            resolve()
          }
        }, 500)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.upload-files-view {
  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .header-description {
      color: rgba(255, 255, 255, 0.8);
      margin: 0;
      font-size: 1rem;
    }
  }

  .view-content {
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius);
    padding: 2rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .upload-area {
      background: rgba(255, 255, 255, 0.05);
      border: 2px dashed rgba(255, 255, 255, 0.2);
      border-radius: var(--border-radius);
      padding: 3rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s ease;

      &.dragging {
        border-color: var(--primary);
        background: rgba(var(--primary-rgb), 0.1);
      }

      .upload-content {
        i {
          font-size: 3rem;
          color: var(--primary);
          margin-bottom: 1rem;
        }

        h3 {
          color: white;
          margin: 0 0 0.5rem;
        }

        p {
          color: rgba(255, 255, 255, 0.8);
          margin: 0.5rem 0;
        }

        .browse-btn {
          background: var(--primary);
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          font-size: 1rem;
          transition: all 0.2s ease;

          &:hover {
            background: var(--primary-dark);
          }
        }

        .file-types {
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.6);
        }
      }
    }

    .files-list {
      margin-top: 2rem;

      .list-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;

        h2 {
          color: white;
          font-size: 1.2rem;
          margin: 0;
        }

        .upload-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: var(--primary);
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover:not(:disabled) {
            background: var(--primary-dark);
          }

          &:disabled {
            opacity: 0.7;
            cursor: not-allowed;
          }
        }
      }

      .files-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 1.5rem;

        .file-card {
          background: rgba(255, 255, 255, 0.05);
          padding: 1.5rem;
          border-radius: var(--border-radius);
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          display: flex;
          align-items: center;
          gap: 1rem;
          position: relative;

          .file-icon {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: var(--border-radius);
            display: flex;
            align-items: center;
            justify-content: center;

            i {
              font-size: 1.2rem;
              color: var(--primary);
            }
          }

          .file-info {
            flex: 1;
            min-width: 0;

            h3 {
              margin: 0 0 0.5rem;
              color: white;
              font-size: 1rem;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }

            p {
              margin: 0;
              color: rgba(255, 255, 255, 0.8);
              font-size: 0.8rem;
            }
          }

          .file-actions {
            .action-btn {
              background: none;
              border: none;
              color: rgba(255, 255, 255, 0.8);
              cursor: pointer;
              padding: 0.5rem;
              border-radius: 50%;
              transition: all 0.2s ease;

              &:hover {
                background: rgba(255, 255, 255, 0.1);
                color: #ef4444;
              }
            }
          }

          .upload-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 0.5rem;
            background: rgba(0, 0, 0, 0.2);

            .progress-bar {
              height: 4px;
              background: rgba(255, 255, 255, 0.1);
              border-radius: 2px;
              overflow: hidden;

              .progress {
                height: 100%;
                background: var(--primary);
                transition: width 0.3s ease;
              }
            }

            .progress-text {
              display: block;
              text-align: center;
              font-size: 0.8rem;
              color: rgba(255, 255, 255, 0.8);
              margin-top: 0.25rem;
            }
          }
        }
      }
    }

    .upload-options {
      margin-top: 2rem;
      background: rgba(255, 255, 255, 0.05);
      padding: 1.5rem;
      border-radius: var(--border-radius);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

      .option-group {
        margin-bottom: 1.5rem;

        label {
          display: block;
          margin-bottom: 0.75rem;
          color: white;
          font-weight: 500;
        }

        select {
          appearance: none;
          width: 100%;
          padding: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: var(--border-radius);
          font-size: 1rem;
          background: rgba(255, 255, 255, 0.1);
          color: white;

          option {
          background-color: rgb(60, 68, 81);
          }

          &:focus {
            outline: none;
            border-color: var(--primary);
          }
        }

        .permissions-options {
          display: flex;
          gap: 1rem;

          .permission-option {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;

            input[type="checkbox"] {
              width: 16px;
              height: 16px;
            }

            span {
              color: rgba(255, 255, 255, 0.8);
            }
          }
        }

        .tags-input {
          .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 0.5rem;

            .tag {
              display: flex;
              align-items: center;
              gap: 0.5rem;
              padding: 0.25rem 0.75rem;
              background: rgba(255, 255, 255, 0.1);
              border-radius: 15px;
              font-size: 0.8rem;
              color: rgba(255, 255, 255, 0.8);

              .remove-tag {
                background: none;
                border: none;
                color: rgba(255, 255, 255, 0.8);
                cursor: pointer;
                padding: 0;
                font-size: 1rem;
                line-height: 1;

                &:hover {
                  color: #ef4444;
                }
              }
            }
          }

          input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: var(--border-radius);
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.1);
            color: white;

            &:focus {
              outline: none;
              border-color: var(--primary);
            }
          }
        }
      }
    }
  }
}
</style> 