<template>
  <div class="new-task-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Nueva Tarea</h1>
    </div>

    <div v-if="error" class="error-message">
      {{ error }}
    </div>

    <form @submit.prevent="handleSubmit" class="task-form" data-aos="fade-up" data-aos-delay="100">
      <div class="form-group">
        <label for="title">Título de la Tarea</label>
        <input 
          type="text" 
          id="title" 
          v-model="taskData.titulo" 
          required
          placeholder="Ingresa el título de la tarea"
        >
      </div>

      <div class="form-group">
        <label for="description">Descripción</label>
        <textarea 
          id="description" 
          v-model="taskData.descripcion" 
          rows="4"
          placeholder="Describe la tarea en detalle"
        ></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="project">Proyecto</label>
          <select id="project" v-model="taskData.id_proyecto" required>
            <option value="">Selecciona un proyecto</option>
            <option v-for="project in projects" :key="project.id_proyecto" :value="project.id_proyecto">
              {{ project.nombre }}
            </option>
          </select>
        </div>

        <div class="form-group">
          <label for="assignee">Asignar a</label>
          <div class="member-select">
            <select id="assignee" v-model="taskData.id_asignado" class="member-select-input">
              <option value="">Selecciona un miembro</option>
              <option v-for="member in teamMembers" :key="member.id_usuario" :value="member.id_usuario">
                {{ member.nombre }} - {{ member.funcion }}
              </option>
            </select>
            <div v-if="teamMembers.length === 0" class="no-members">
              No hay miembros disponibles en este proyecto
            </div>
          </div>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="dueDate">Fecha límite</label>
          <input 
            type="date" 
            id="dueDate" 
            v-model="taskData.fecha_vencimiento"
            required
          >
        </div>

        <div class="form-group">
          <label for="priority">Prioridad</label>
          <select id="priority" v-model="taskData.prioridad">
            <option value="baja">Baja</option>
            <option value="media">Media</option>
            <option value="alta">Alta</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label for="attachments">Archivos adjuntos</label>
        <div class="file-upload">
          <input 
            type="file" 
            id="attachments" 
            multiple
            @change="handleFileUpload"
          >
          <label for="attachments" class="upload-label">
            <i class="fas fa-cloud-upload-alt"></i>
            <span>Arrastra archivos aquí o haz clic para seleccionar</span>
          </label>
        </div>
      </div>

      <div class="form-actions">
        <button type="button" class="cancel-btn" @click="$router.push('/workspace/tasks')">
          Cancelar
        </button>
        <button type="submit" class="submit-btn" :disabled="loading">
          {{ loading ? 'Creando...' : 'Crear Tarea' }}
        </button>
      </div>
    </form>
  </div>
</template>

<script>
import AOS from 'aos';
import 'aos/dist/aos.css';
import api from '@/api';

export default {
  name: 'NewTaskView',
  data() {
    return {
      taskData: {
        titulo: '',
        descripcion: '',
        id_proyecto: '',
        id_asignado: '',
        fecha_vencimiento: '',
        prioridad: 'media',
        estado: 'pendiente'
      },
      projects: [],
      teamMembers: [],
      loading: false,
      error: null
    }
  },
  watch: {
    'taskData.id_proyecto': {
      async handler(newProjectId) {
        if (newProjectId) {
          try {
            console.log('Cargando miembros del proyecto:', newProjectId);
            const membersResponse = await api.getProjectMembers(newProjectId);
            console.log('Miembros del proyecto cargados:', membersResponse);
            this.teamMembers = membersResponse.miembros || [];
          } catch (error) {
            console.error('Error al cargar miembros del proyecto:', error);
            this.error = 'Error al cargar los miembros del proyecto';
            this.teamMembers = [];
          }
        } else {
          this.teamMembers = [];
        }
      }
    }
  },
  async mounted() {
    AOS.init({
      duration: 800,
      once: true,
      offset: 50,
      disable: 'mobile'
    });

    try {
      console.log('Iniciando carga de datos...');
      
      // Cargar proyectos
      console.log('Cargando proyectos...');
      const projectsResponse = await api.getUserProjects();
      console.log('Proyectos cargados:', projectsResponse);
      // Filtrar solo los proyectos donde el usuario es administrador (rol_id = 2)
      this.projects = projectsResponse.filter(project => project.rol_id === 2);
      console.log('Proyectos filtrados (solo admin):', this.projects);

      console.log('Carga de datos completada exitosamente');
    } catch (error) {
      console.error('Error detallado al cargar datos:', error);
      this.error = error.message || 'Error al cargar los datos necesarios';
    }
  },
  beforeUnmount() {
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  },
  methods: {
    async handleSubmit() {
      try {
        this.loading = true;
        const response = await api.createTask(this.taskData);
        console.log('Tarea creada:', response);
        this.$router.push('/workspace/tasks');
      } catch (error) {
        console.error('Error al crear la tarea:', error);
        this.error = 'Error al crear la tarea';
      } finally {
        this.loading = false;
      }
    },
    handleFileUpload(event) {
      const files = event.target.files
      this.taskData.attachments = Array.from(files)
    }
  }
}
</script>

<style lang="scss" scoped>
.new-task-view {
  max-width: 800px;
  margin: 0 auto;

  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .back-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: white;
      text-decoration: none;
      font-weight: 500;

      &:hover {
        color: var(--primary);
      }
    }
  }

  .task-form {
    background: rgba(255, 255, 255, 0.1);
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .form-group {
      margin-bottom: 1.5rem;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      input[type="text"],
      input[type="date"],
      textarea,
      select {
        appearance: none;
        width: 100%;
        padding: 0.75rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 1rem;
        background: rgba(79, 79, 79, 0.1);
        color: white;

        option {
        background-color: rgb(60, 68, 81);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }

        &::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }
      }

      textarea {
        resize: vertical;
      }
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .file-upload {
      input[type="file"] {
        display: none;
      }

      .upload-label {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 2rem;
        border: 2px dashed rgba(255, 255, 255, 0.2);
        border-radius: var(--border-radius);
        cursor: pointer;
        transition: all 0.2s ease;
        background: rgba(255, 255, 255, 0.05);
        color: rgba(255, 255, 255, 0.8);

        &:hover {
          border-color: var(--primary);
          color: var(--primary);
        }

        i {
          font-size: 2rem;
          margin-bottom: 1rem;
        }
      }
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;

      button {
        padding: 0.75rem 1.5rem;
        border-radius: var(--border-radius);
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;

        &.cancel-btn {
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.2);
          color: white;

          &:hover {
            background: rgba(255, 255, 255, 0.2);
          }
        }

        &.submit-btn {
          background: var(--primary);
          border: none;
          color: white;

          &:hover {
            background: var(--primary-dark);
          }
        }
      }
    }
  }

  .error-message {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
    padding: 1rem;
    border-radius: var(--border-radius);
    margin-bottom: 1rem;
    text-align: center;
  }

  .member-select {
    position: relative;
    
    .member-select-input {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--border-radius);
      background: rgba(79, 79, 79, 0.1);
      color: white;
      font-size: 1rem;
      cursor: pointer;
      appearance: none;
      
      &:focus {
        outline: none;
        border-color: var(--primary);
      }
      
      option {
        background-color: rgb(60, 68, 81);
        padding: 0.5rem;
      }
    }
    
    .no-members {
      margin-top: 0.5rem;
      color: rgba(255, 255, 255, 0.6);
      font-size: 0.9rem;
      text-align: center;
    }
  }
}
</style> 