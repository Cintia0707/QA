<template>
  <div class="reports-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Reportes</h1>
    </div>

    <div class="reports-container">
      <div class="reports-sidebar" data-aos="fade-right" data-aos-delay="100">
        <div class="sidebar-section">
          <h3>Filtros</h3>
          <div class="filter-group">
            <label>Proyecto</label>
            <select v-model="filters.project">
              <option value="">Todos los Proyectos</option>
              <option v-for="project in projects" :key="project.id" :value="project.id">
                {{ project.name }}
              </option>
            </select>
          </div>

          <div class="filter-group">
            <label>Período</label>
            <select v-model="filters.period">
              <option value="week">Última Semana</option>
              <option value="month">Último Mes</option>
              <option value="quarter">Último Trimestre</option>
              <option value="year">Último Año</option>
            </select>
          </div>

          <div class="filter-group">
            <label>Equipo</label>
            <select v-model="filters.team">
              <option value="">Todos los Equipos</option>
              <option v-for="team in teams" :key="team.id" :value="team.id">
                {{ team.name }}
              </option>
            </select>
          </div>
        </div>

        <div class="sidebar-section">
          <h3>Exportar</h3>
          <div class="export-options">
            <button class="export-btn" @click="exportReport('pdf')">
              <i class="fas fa-file-pdf"></i>
              PDF
            </button>
            <button class="export-btn" @click="exportReport('excel')">
              <i class="fas fa-file-excel"></i>
              Excel
            </button>
            <button class="export-btn" @click="exportReport('csv')">
              <i class="fas fa-file-csv"></i>
              CSV
            </button>
          </div>
        </div>
      </div>

      <div class="reports-content">
        <div class="reports-grid">
          <!-- Resumen de Proyectos -->
          <div class="report-card">
            <div class="card-header">
              <h3>Resumen de Proyectos</h3>
              <div class="card-actions">
                <button class="action-btn" @click="refreshData">
                  <i class="fas fa-sync"></i>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="stats-grid">
                <div class="stat-item">
                  <div class="stat-value">{{ projectStats.total }}</div>
                  <div class="stat-label">Total Proyectos</div>
                </div>
                <div class="stat-item">
                  <div class="stat-value">{{ projectStats.active }}</div>
                  <div class="stat-label">Activos</div>
                </div>
                <div class="stat-item">
                  <div class="stat-value">{{ projectStats.completed }}</div>
                  <div class="stat-label">Completados</div>
                </div>
                <div class="stat-item">
                  <div class="stat-value">{{ projectStats.onHold }}</div>
                  <div class="stat-label">En Espera</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Progreso de Tareas -->
          <div class="report-card" data-aos="fade-up" data-aos-delay="200">
            <div class="card-header">
              <h3>Progreso de Tareas</h3>
              <div class="card-actions">
                <button class="action-btn" @click="refreshData">
                  <i class="fas fa-sync"></i>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="chart-container">
                <canvas ref="taskProgressChart"></canvas>
              </div>
            </div>
          </div>

          <!-- Rendimiento del Equipo -->
          <div class="report-card">
            <div class="card-header">
              <h3>Rendimiento del Equipo</h3>
              <div class="card-actions">
                <button class="action-btn" @click="refreshData">
                  <i class="fas fa-sync"></i>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="team-performance">
                <div 
                  v-for="member in teamPerformance" 
                  :key="member.id"
                  class="performance-item"
                >
                  <div class="member-info">
                    <img :src="member.avatar" :alt="member.name">
                    <div class="member-details">
                      <span class="member-name">{{ member.name }}</span>
                      <span class="member-role">{{ member.role }}</span>
                    </div>
                  </div>
                  <div class="performance-stats">
                    <div class="stat">
                      <span class="stat-label">Tareas Completadas</span>
                      <span class="stat-value">{{ member.completedTasks }}</span>
                    </div>
                    <div class="stat">
                      <span class="stat-label">Tiempo Promedio</span>
                      <span class="stat-value">{{ member.avgTime }}h</span>
                    </div>
                    <div class="stat">
                      <span class="stat-label">Productividad</span>
                      <span class="stat-value">{{ member.productivity }}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Tendencias -->
          <div class="report-card" data-aos="fade-up" data-aos-delay="300">
            <div class="card-header">
              <h3>Tendencias</h3>
              <div class="card-actions">
                <button class="action-btn" @click="refreshData">
                  <i class="fas fa-sync"></i>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="chart-container">
                <canvas ref="trendsChart"></canvas>
              </div>
            </div>
          </div>

          <!-- Métricas Clave -->
          <div class="report-card">
            <div class="card-header">
              <h3>Métricas Clave</h3>
              <div class="card-actions">
                <button class="action-btn" @click="refreshData">
                  <i class="fas fa-sync"></i>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="metrics-grid">
                <div class="metric-item">
                  <div class="metric-icon">
                    <i class="fas fa-clock"></i>
                  </div>
                  <div class="metric-info">
                    <span class="metric-value">{{ keyMetrics.avgTaskTime }}h</span>
                    <span class="metric-label">Tiempo Promedio por Tarea</span>
                  </div>
                </div>
                <div class="metric-item">
                  <div class="metric-icon">
                    <i class="fas fa-check-circle"></i>
                  </div>
                  <div class="metric-info">
                    <span class="metric-value">{{ keyMetrics.completionRate }}%</span>
                    <span class="metric-label">Tasa de Completado</span>
                  </div>
                </div>
                <div class="metric-item">
                  <div class="metric-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                  </div>
                  <div class="metric-info">
                    <span class="metric-value">{{ keyMetrics.overdueTasks }}</span>
                    <span class="metric-label">Tareas Atrasadas</span>
                  </div>
                </div>
                <div class="metric-item">
                  <div class="metric-icon">
                    <i class="fas fa-chart-line"></i>
                  </div>
                  <div class="metric-info">
                    <span class="metric-value">{{ keyMetrics.efficiency }}%</span>
                    <span class="metric-label">Eficiencia</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Análisis de Tiempo -->
          <div class="report-card" data-aos="fade-up" data-aos-delay="400">
            <div class="card-header">
              <h3>Análisis de Tiempo</h3>
              <div class="card-actions">
                <button class="action-btn" @click="refreshData">
                  <i class="fas fa-sync"></i>
                </button>
              </div>
            </div>
            <div class="card-content">
              <div class="time-analysis">
                <div class="time-chart">
                  <canvas ref="timeAnalysisChart"></canvas>
                </div>
                <div class="time-stats">
                  <div class="time-stat">
                    <span class="stat-label">Tiempo Total</span>
                    <span class="stat-value">{{ timeAnalysis.totalTime }}h</span>
                  </div>
                  <div class="time-stat">
                    <span class="stat-label">Tiempo Productivo</span>
                    <span class="stat-value">{{ timeAnalysis.productiveTime }}h</span>
                  </div>
                  <div class="time-stat">
                    <span class="stat-label">Tiempo en Reuniones</span>
                    <span class="stat-value">{{ timeAnalysis.meetingTime }}h</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Chart from 'chart.js/auto'
import AOS from 'aos'
import 'aos/dist/aos.css'

export default {
  name: 'ReportsView',
  data() {
    return {
      filters: {
        project: '',
        period: 'month',
        team: ''
      },
      projects: [
        { id: 1, name: 'Sitio Web Corporativo' },
        { id: 2, name: 'Aplicación Móvil' },
        { id: 3, name: 'Rediseño de Marca' }
      ],
      teams: [
        { id: 1, name: 'Desarrollo Frontend' },
        { id: 2, name: 'Desarrollo Backend' },
        { id: 3, name: 'Diseño UI/UX' }
      ],
      projectStats: {
        total: 12,
        active: 8,
        completed: 3,
        onHold: 1
      },
      teamPerformance: [
        {
          id: 1,
          name: 'María García',
          role: 'Desarrollador Frontend',
          avatar: 'https://via.placeholder.com/40',
          completedTasks: 24,
          avgTime: 4.5,
          productivity: 92
        },
        {
          id: 2,
          name: 'Juan Pérez',
          role: 'Diseñador UI',
          avatar: 'https://via.placeholder.com/40',
          completedTasks: 18,
          avgTime: 3.8,
          productivity: 88
        }
      ],
      keyMetrics: {
        avgTaskTime: 4.2,
        completionRate: 85,
        overdueTasks: 5,
        efficiency: 92
      },
      timeAnalysis: {
        totalTime: 160,
        productiveTime: 120,
        meetingTime: 40
      },
      charts: {
        taskProgress: null,
        trends: null,
        timeAnalysis: null
      }
    }
  },
  methods: {
    initializeCharts() {
      // Gráfico de Progreso de Tareas
      const taskProgressCtx = this.$refs.taskProgressChart.getContext('2d')
      this.charts.taskProgress = new Chart(taskProgressCtx, {
        type: 'doughnut',
        data: {
          labels: ['Completadas', 'En Progreso', 'Pendientes'],
          datasets: [{
            data: [65, 25, 10],
            backgroundColor: ['#10B981', '#3B82F6', '#F59E0B']
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false
        }
      })

      // Gráfico de Tendencias
      const trendsCtx = this.$refs.trendsChart.getContext('2d')
      this.charts.trends = new Chart(trendsCtx, {
        type: 'line',
        data: {
          labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
          datasets: [{
            label: 'Tareas Completadas',
            data: [12, 19, 15, 25, 22, 30],
            borderColor: '#3B82F6',
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false
        }
      })

      // Gráfico de Análisis de Tiempo
      const timeAnalysisCtx = this.$refs.timeAnalysisChart.getContext('2d')
      this.charts.timeAnalysis = new Chart(timeAnalysisCtx, {
        type: 'bar',
        data: {
          labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie'],
          datasets: [{
            label: 'Horas Trabajadas',
            data: [8, 7.5, 8.5, 8, 7],
            backgroundColor: '#3B82F6'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false
        }
      })
    },
    refreshData() {
      // Implementar lógica de actualización de datos
      console.log('Actualizando datos...')
    },
    exportReport(format) {
      // Implementar lógica de exportación
      console.log(`Exportando reporte en formato ${format}...`)
    }
  },
  mounted() {
    AOS.init({
      duration: 800,
      once: true,
      offset: 50,
      disable: 'mobile'
    })
    this.initializeCharts()
  },
  beforeUnmount() {
    if (document) {
      const elements = document.querySelectorAll('[data-aos]')
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos')
          el.removeAttribute('data-aos-delay')
          el.removeAttribute('data-aos-duration')
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.reports-view {
  padding: 2rem;

  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .generate-report-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: var(--primary);
      color: white;
      text-decoration: none;
      border-radius: var(--border-radius);
      transition: all 0.2s ease;

      &:hover {
        background: var(--primary-dark);
      }

      i {
        font-size: 1.1rem;
      }
    }
  }

  .reports-filters {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .filter-group {
      flex: 1;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      select {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }

    .search-group {
      flex: 2;
      position: relative;

      i {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.7);
      }

      input {
        width: 100%;
        padding: 0.75rem 1rem 0.75rem 2.5rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;

        &::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }
  }

  .reports-container {
    display: grid;
    grid-template-columns: 250px 1fr;
    gap: 2rem;
  }

  .reports-sidebar {
    .sidebar-section {
      background: white;
      padding: 1.5rem;
      border-radius: var(--border-radius);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      margin-bottom: 1.5rem;

      h3 {
        color: var(--dark);
        margin: 0 0 1rem;
        font-size: 1.1rem;
      }

      .filter-group {
        margin-bottom: 1.5rem;

        label {
          display: block;
          margin-bottom: 0.5rem;
          color: #666;
          font-size: 0.9rem;
        }

        select {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: var(--border-radius);
          font-size: 1rem;

          &:focus {
            outline: none;
            border-color: var(--primary);
          }
        }
      }

      .export-options {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;

        .export-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem;
          background: #f3f4f6;
          border: none;
          border-radius: var(--border-radius);
          color: #666;
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover {
            background: #e5e7eb;
            color: var(--primary);
          }

          i {
            font-size: 1.1rem;
          }
        }
      }
    }
  }

  .reports-content {
    .reports-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .report-card {
      background: rgba(255, 255, 255, 0.05);
      padding: 1.5rem;
      border-radius: var(--border-radius);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

      .report-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;

        h3 {
          margin: 0;
          color: white;
          font-size: 1.1rem;
        }

        .report-type {
          padding: 0.25rem 0.75rem;
          border-radius: 1rem;
          font-size: 0.8rem;
          font-weight: 500;

          &.performance {
            background: rgba(33, 150, 243, 0.2);
            color: #2196f3;
          }

          &.progress {
            background: rgba(76, 175, 80, 0.2);
            color: #4caf50;
          }

          &.analytics {
            background: rgba(156, 39, 176, 0.2);
            color: #9c27b0;
          }
        }
      }

      .report-info {
        color: rgba(255, 255, 255, 0.8);
        font-size: 0.9rem;
        margin-bottom: 1rem;

        .info-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          margin-bottom: 0.5rem;

          i {
            color: var(--primary);
          }
        }
      }

      .report-actions {
        display: flex;
        gap: 0.5rem;

        .action-btn {
          flex: 1;
          padding: 0.5rem;
          border: none;
          border-radius: var(--border-radius);
          font-size: 0.9rem;
          cursor: pointer;
          transition: all 0.2s ease;

          &.view-btn {
            background: var(--primary);
            color: white;

            &:hover {
              background: var(--primary-dark);
            }
          }

          &.download-btn {
            background: rgba(255, 255, 255, 0.1);
            color: white;

            &:hover {
              background: rgba(255, 255, 255, 0.2);
            }
          }
        }
      }

      .card-content {
        padding: 1.5rem;

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;

          .stat-item {
            text-align: center;

            .stat-value {
              font-size: 1.8rem;
              font-weight: 600;
              color: var(--dark);
              margin-bottom: 0.25rem;
            }

            .stat-label {
              color: #666;
              font-size: 0.9rem;
            }
          }
        }

        .chart-container {
          height: 300px;
        }

        .team-performance {
          .performance-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: #f3f4f6;
            border-radius: var(--border-radius);
            margin-bottom: 0.5rem;

            .member-info {
              display: flex;
              align-items: center;
              gap: 1rem;

              img {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                object-fit: cover;
              }

              .member-details {
                display: flex;
                flex-direction: column;

                .member-name {
                  color: var(--dark);
                  font-weight: 500;
                }

                .member-role {
                  color: #666;
                  font-size: 0.8rem;
                }
              }
            }

            .performance-stats {
              display: flex;
              gap: 1.5rem;

              .stat {
                display: flex;
                flex-direction: column;
                align-items: flex-end;

                .stat-label {
                  color: #666;
                  font-size: 0.8rem;
                  margin-bottom: 0.25rem;
                }

                .stat-value {
                  color: var(--dark);
                  font-weight: 500;
                }
              }
            }
          }
        }

        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;

          .metric-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: #f3f4f6;
            border-radius: var(--border-radius);

            .metric-icon {
              width: 40px;
              height: 40px;
              background: var(--primary);
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;

              i {
                color: white;
                font-size: 1.2rem;
              }
            }

            .metric-info {
              display: flex;
              flex-direction: column;

              .metric-value {
                color: var(--dark);
                font-weight: 500;
              }

              .metric-label {
                color: #666;
                font-size: 0.8rem;
              }
            }
          }
        }

        .time-analysis {
          .time-chart {
            height: 200px;
            margin-bottom: 1rem;
          }

          .time-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;

            .time-stat {
              text-align: center;
              padding: 1rem;
              background: #f3f4f6;
              border-radius: var(--border-radius);

              .stat-label {
                display: block;
                color: #666;
                font-size: 0.8rem;
                margin-bottom: 0.25rem;
              }

              .stat-value {
                color: var(--dark);
                font-weight: 500;
              }
            }
          }
        }
      }
    }
  }
}
</style> 