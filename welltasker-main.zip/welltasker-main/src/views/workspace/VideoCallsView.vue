<template>
  <div class="video-calls-view">
    <div class="view-header">
      <h1>Videollamadas</h1>
    </div>

    <div class="video-container">
      <div class="main-video">
        <div class="video-wrapper">
          <video 
            ref="localVideo"
            autoplay 
            muted 
            playsinline
            class="video-element"
          ></video>
          <div class="video-overlay">
            <div class="participant-info">
              <span class="participant-name">Tú</span>
              <span class="participant-status">
                <i class="fas fa-microphone"></i>
                <i class="fas fa-video"></i>
              </span>
            </div>
          </div>
        </div>
      </div>

      <div class="participants-grid">
        <div 
          v-for="participant in participants" 
          :key="participant.id"
          class="participant-video"
        >
          <div class="video-wrapper">
            <video 
              :ref="'remoteVideo' + participant.id"
              autoplay 
              playsinline
              class="video-element"
            ></video>
            <div class="video-overlay">
              <div class="participant-info">
                <span class="participant-name">{{ participant.name }}</span>
                <span class="participant-status">
                  <i :class="participant.audio ? 'fas fa-microphone' : 'fas fa-microphone-slash'"></i>
                  <i :class="participant.video ? 'fas fa-video' : 'fas fa-video-slash'"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="controls-bar">
        <div class="controls-left">
          <button 
            class="control-btn"
            :class="{ active: isAudioEnabled }"
            @click="toggleAudio"
          >
            <i class="fas fa-microphone"></i>
            <span>Micrófono</span>
          </button>
          <button 
            class="control-btn"
            :class="{ active: isVideoEnabled }"
            @click="toggleVideo"
          >
            <i class="fas fa-video"></i>
            <span>Cámara</span>
          </button>
        </div>

        <div class="controls-center">
          <button class="control-btn" @click="toggleScreenShare">
            <i class="fas fa-desktop"></i>
            <span>Compartir Pantalla</span>
          </button>
          <button class="control-btn" @click="toggleChat">
            <i class="fas fa-comments"></i>
            <span>Chat</span>
          </button>
          <button class="control-btn" @click="toggleParticipants">
            <i class="fas fa-users"></i>
            <span>Participantes</span>
          </button>
        </div>

        <div class="controls-right">
          <button class="control-btn" @click="toggleSettings">
            <i class="fas fa-cog"></i>
            <span>Configuración</span>
          </button>
          <button class="control-btn end-call" @click="endCall">
            <i class="fas fa-phone-slash"></i>
            <span>Finalizar Llamada</span>
          </button>
        </div>
      </div>

      <!-- Panel de Chat -->
      <div v-if="showChat" class="chat-panel">
        <div class="chat-header">
          <h3>Chat</h3>
          <button class="close-btn" @click="showChat = false">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="chat-messages" ref="chatMessages">
          <div 
            v-for="message in chatMessages" 
            :key="message.id"
            class="message"
            :class="{ 'message-self': message.isSelf }"
          >
            <div class="message-content">
              <div class="message-header">
                <span class="message-sender">{{ message.sender }}</span>
                <span class="message-time">{{ message.time }}</span>
              </div>
              <p class="message-text">{{ message.text }}</p>
            </div>
          </div>
        </div>
        <div class="chat-input">
          <input 
            type="text"
            v-model="newMessage"
            placeholder="Escribe un mensaje..."
            @keyup.enter="sendMessage"
          >
          <button @click="sendMessage">
            <i class="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>

      <!-- Panel de Participantes -->
      <div v-if="showParticipants" class="participants-panel">
        <div class="panel-header">
          <h3>Participantes ({{ participants.length + 1 }})</h3>
          <button class="close-btn" @click="showParticipants = false">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="participants-list">
          <div class="participant-item">
            <div class="participant-avatar">
              <img src="https://via.placeholder.com/40" alt="Tu avatar">
            </div>
            <div class="participant-info">
              <span class="participant-name">Tú</span>
              <span class="participant-role">Organizador</span>
            </div>
            <div class="participant-status">
              <i class="fas fa-microphone"></i>
              <i class="fas fa-video"></i>
            </div>
          </div>
          <div 
            v-for="participant in participants" 
            :key="participant.id"
            class="participant-item"
          >
            <div class="participant-avatar">
              <img :src="participant.avatar" :alt="participant.name">
            </div>
            <div class="participant-info">
              <span class="participant-name">{{ participant.name }}</span>
              <span class="participant-role">{{ participant.role }}</span>
            </div>
            <div class="participant-status">
              <i :class="participant.audio ? 'fas fa-microphone' : 'fas fa-microphone-slash'"></i>
              <i :class="participant.video ? 'fas fa-video' : 'fas fa-video-slash'"></i>
            </div>
          </div>
        </div>
      </div>

      <!-- Panel de Configuración -->
      <div v-if="showSettings" class="settings-panel">
        <div class="panel-header">
          <h3>Configuración</h3>
          <button class="close-btn" @click="showSettings = false">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="settings-content">
          <div class="setting-group">
            <label>Micrófono</label>
            <select v-model="selectedMicrophone">
              <option v-for="device in audioDevices" :key="device.id" :value="device.id">
                {{ device.label }}
              </option>
            </select>
          </div>
          <div class="setting-group">
            <label>Cámara</label>
            <select v-model="selectedCamera">
              <option v-for="device in videoDevices" :key="device.id" :value="device.id">
                {{ device.label }}
              </option>
            </select>
          </div>
          <div class="setting-group">
            <label>Calidad de Video</label>
            <select v-model="videoQuality">
              <option value="low">Baja</option>
              <option value="medium">Media</option>
              <option value="high">Alta</option>
            </select>
          </div>
          <div class="setting-group">
            <label>Calidad de Audio</label>
            <select v-model="audioQuality">
              <option value="low">Baja</option>
              <option value="medium">Media</option>
              <option value="high">Alta</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'VideoCallsView',
  data() {
    return {
      isAudioEnabled: true,
      isVideoEnabled: true,
      showChat: false,
      showParticipants: false,
      showSettings: false,
      newMessage: '',
      chatMessages: [
        {
          id: 1,
          sender: 'Tú',
          text: '¡Hola a todos!',
          time: '10:30',
          isSelf: true
        },
        {
          id: 2,
          sender: 'María García',
          text: 'Hola, ¿cómo están?',
          time: '10:31',
          isSelf: false
        }
      ],
      participants: [
        {
          id: 1,
          name: 'María García',
          role: 'Desarrollador',
          avatar: 'https://via.placeholder.com/40',
          audio: true,
          video: true
        },
        {
          id: 2,
          name: 'Juan Pérez',
          role: 'Diseñador',
          avatar: 'https://via.placeholder.com/40',
          audio: false,
          video: true
        }
      ],
      selectedMicrophone: '',
      selectedCamera: '',
      videoQuality: 'medium',
      audioQuality: 'medium',
      audioDevices: [
        { id: 'mic1', label: 'Micrófono Integrado' },
        { id: 'mic2', label: 'Micrófono Externo' }
      ],
      videoDevices: [
        { id: 'cam1', label: 'Cámara Integrada' },
        { id: 'cam2', label: 'Cámara Externa' }
      ]
    }
  },
  methods: {
    async initializeMedia() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: true
        })
        this.$refs.localVideo.srcObject = stream
      } catch (error) {
        console.error('Error al acceder a los dispositivos:', error)
      }
    },
    toggleAudio() {
      this.isAudioEnabled = !this.isAudioEnabled
      // Implementar lógica de toggle de audio
    },
    toggleVideo() {
      this.isVideoEnabled = !this.isVideoEnabled
      // Implementar lógica de toggle de video
    },
    toggleScreenShare() {
      // Implementar lógica de compartir pantalla
    },
    toggleChat() {
      this.showChat = !this.showChat
      this.showParticipants = false
      this.showSettings = false
    },
    toggleParticipants() {
      this.showParticipants = !this.showParticipants
      this.showChat = false
      this.showSettings = false
    },
    toggleSettings() {
      this.showSettings = !this.showSettings
      this.showChat = false
      this.showParticipants = false
    },
    sendMessage() {
      if (this.newMessage.trim()) {
        this.chatMessages.push({
          id: Date.now(),
          sender: 'Tú',
          text: this.newMessage,
          time: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
          isSelf: true
        })
        this.newMessage = ''
        this.$nextTick(() => {
          this.scrollToBottom()
        })
      }
    },
    scrollToBottom() {
      const chatMessages = this.$refs.chatMessages
      chatMessages.scrollTop = chatMessages.scrollHeight
    },
    endCall() {
      // Implementar lógica para finalizar la llamada
      this.$router.push('/workspace')
    }
  },
  mounted() {
    this.initializeMedia()
  }
}
</script>

<style lang="scss" scoped>
.video-calls-view {
  height: 100vh;
  display: flex;
  flex-direction: column;

  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .new-call-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: var(--primary);
      color: white;
      text-decoration: none;
      border-radius: var(--border-radius);
      transition: all 0.2s ease;

      &:hover {
        background: var(--primary-dark);
      }

      i {
        font-size: 1.1rem;
      }
    }
  }

  .calls-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
  }

  .call-card {
    background: rgba(255, 255, 255, 0.05);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .call-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;

      h3 {
        margin: 0;
        color: white;
        font-size: 1.1rem;
      }

      .call-status {
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-size: 0.8rem;
        font-weight: 500;

        &.scheduled {
          background: rgba(33, 150, 243, 0.2);
          color: #2196f3;
        }

        &.in-progress {
          background: rgba(76, 175, 80, 0.2);
          color: #4caf50;
        }

        &.completed {
          background: rgba(158, 158, 158, 0.2);
          color: #9e9e9e;
        }
      }
    }

    .call-info {
      color: rgba(255, 255, 255, 0.8);
      font-size: 0.9rem;
      margin-bottom: 1rem;

      .info-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.5rem;

        i {
          color: var(--primary);
        }
      }
    }

    .call-actions {
      display: flex;
      gap: 0.5rem;

      .action-btn {
        flex: 1;
        padding: 0.5rem;
        border: none;
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        cursor: pointer;
        transition: all 0.2s ease;

        &.join-btn {
          background: var(--primary);
          color: white;

          &:hover {
            background: var(--primary-dark);
          }
        }

        &.cancel-btn {
          background: rgba(244, 67, 54, 0.2);
          color: #f44336;

          &:hover {
            background: rgba(244, 67, 54, 0.3);
          }
        }
      }
    }
  }

  .video-container {
    flex: 1;
    display: flex;
    flex-direction: column;
    background: #1a1a1a;
    position: relative;
    overflow: hidden;

    .main-video {
      flex: 1;
      position: relative;
      background: #000;

      .video-wrapper {
        position: relative;
        width: 100%;
        height: 100%;

        .video-element {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .video-overlay {
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          padding: 1rem;
          background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));

          .participant-info {
            display: flex;
            align-items: center;
            gap: 1rem;

            .participant-name {
              color: white;
              font-weight: 500;
            }

            .participant-status {
              display: flex;
              gap: 0.5rem;
              color: white;

              i {
                font-size: 0.9rem;
              }
            }
          }
        }
      }
    }

    .participants-grid {
      position: absolute;
      top: 1rem;
      right: 1rem;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      max-width: 300px;

      .participant-video {
        aspect-ratio: 16/9;
        background: #000;
        border-radius: var(--border-radius);
        overflow: hidden;

        .video-wrapper {
          position: relative;
          width: 100%;
          height: 100%;

          .video-element {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }

          .video-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 0.5rem;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));

            .participant-info {
              display: flex;
              align-items: center;
              gap: 0.5rem;

              .participant-name {
                color: white;
                font-size: 0.9rem;
              }

              .participant-status {
                display: flex;
                gap: 0.25rem;
                color: white;

                i {
                  font-size: 0.8rem;
                }
              }
            }
          }
        }
      }
    }

    .controls-bar {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 1rem;
      background: rgba(0, 0, 0, 0.8);
      display: flex;
      justify-content: space-between;
      align-items: center;

      .controls-left,
      .controls-center,
      .controls-right {
        display: flex;
        gap: 1rem;
      }

      .control-btn {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        padding: 0.5rem;
        border-radius: var(--border-radius);
        transition: all 0.2s ease;

        i {
          font-size: 1.2rem;
        }

        span {
          font-size: 0.8rem;
        }

        &:hover {
          background: rgba(255, 255, 255, 0.1);
        }

        &.active {
          background: var(--primary);
        }

        &.end-call {
          background: #ef4444;

          &:hover {
            background: #dc2626;
          }
        }
      }
    }

    .chat-panel,
    .participants-panel,
    .settings-panel {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      width: 300px;
      background: white;
      display: flex;
      flex-direction: column;

      .panel-header {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;

        h3 {
          margin: 0;
          color: var(--dark);
        }

        .close-btn {
          background: none;
          border: none;
          color: #666;
          cursor: pointer;
          padding: 0.5rem;
          border-radius: 50%;
          transition: all 0.2s ease;

          &:hover {
            background: #f3f4f6;
            color: #ef4444;
          }
        }
      }
    }

    .chat-panel {
      .chat-messages {
        flex: 1;
        padding: 1rem;
        overflow-y: auto;

        .message {
          margin-bottom: 1rem;
          display: flex;
          flex-direction: column;

          &.message-self {
            align-items: flex-end;

            .message-content {
              background: var(--primary);
              color: white;
              border-radius: 15px 0 15px 15px;
            }
          }

          .message-content {
            max-width: 80%;
            background: #f3f4f6;
            padding: 0.75rem;
            border-radius: 0 15px 15px 15px;

            .message-header {
              display: flex;
              justify-content: space-between;
              margin-bottom: 0.25rem;
              font-size: 0.8rem;

              .message-sender {
                font-weight: 500;
              }

              .message-time {
                color: #666;
              }
            }

            .message-text {
              margin: 0;
              font-size: 0.9rem;
            }
          }
        }
      }

      .chat-input {
        padding: 1rem;
        border-top: 1px solid #eee;
        display: flex;
        gap: 0.5rem;

        input {
          flex: 1;
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: var(--border-radius);
          font-size: 1rem;

          &:focus {
            outline: none;
            border-color: var(--primary);
          }
        }

        button {
          background: var(--primary);
          color: white;
          border: none;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover {
            background: var(--primary-dark);
          }
        }
      }
    }

    .participants-panel {
      .participants-list {
        flex: 1;
        padding: 1rem;
        overflow-y: auto;

        .participant-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 0.75rem;
          border-radius: var(--border-radius);
          background: #f3f4f6;
          margin-bottom: 0.5rem;

          .participant-avatar {
            img {
              width: 40px;
              height: 40px;
              border-radius: 50%;
              object-fit: cover;
            }
          }

          .participant-info {
            flex: 1;

            .participant-name {
              display: block;
              color: var(--dark);
              font-weight: 500;
            }

            .participant-role {
              display: block;
              color: #666;
              font-size: 0.8rem;
            }
          }

          .participant-status {
            display: flex;
            gap: 0.5rem;
            color: #666;

            i {
              font-size: 0.9rem;
            }
          }
        }
      }
    }

    .settings-panel {
      .settings-content {
        flex: 1;
        padding: 1rem;
        overflow-y: auto;

        .setting-group {
          margin-bottom: 1.5rem;

          label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--dark);
            font-weight: 500;
          }

          select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;

            &:focus {
              outline: none;
              border-color: var(--primary);
            }
          }
        }
      }
    }
  }
}
</style> 