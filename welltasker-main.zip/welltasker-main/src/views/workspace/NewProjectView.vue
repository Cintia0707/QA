<template>
  <div class="new-project-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Nuevo Proyecto</h1>
    </div>

    <div class="project-form" data-aos="fade-up" data-aos-delay="100">
      <!-- Mensaje de error general -->
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>

      <div class="form-section">
        <h2>Información Básica</h2>
        <div class="form-group" :class="{ 'field-error': hasFieldError('nombre') }">
          <label for="projectName">Nombre del Proyecto</label>
          <input 
            type="text" 
            id="projectName" 
            v-model="project.nombre"
            placeholder="Ej: Sitio Web Corporativo"
            autocomplete="off"

          >
        </div>

        <div class="form-group" :class="{ 'field-error': hasFieldError('descripcion') }">
          <label for="projectDescription">Descripción</label>
          <textarea 
            id="projectDescription" 
            v-model="project.descripcion"
            rows="4"
            placeholder="Describe el propósito y objetivos del proyecto"
            autocomplete="off"
          ></textarea>
        </div>

        <div class="form-row">
          <div class="form-group" :class="{ 'field-error': hasFieldError('fecha_inicio') }">
            <label for="startDate">Fecha de Inicio</label>
            <input 
              type="date" 
              id="startDate" 
              v-model="project.fecha_inicio"
            >
          </div>

          <div class="form-group" :class="{ 'field-error': hasFieldError('fecha_limite') }">
            <label for="endDate">Fecha de Fin</label>
            <input 
              type="date" 
              id="endDate" 
              v-model="project.fecha_limite"
            >
          </div>
        </div>
      </div>

      <div class="form-section">
        <h2>Configuración</h2>
        <div class="form-group" :class="{ 'field-error': hasFieldError('tipo') }">
          <label for="projectType">Tipo de Proyecto</label>
          <input 
            type="text" 
            id="projectType" 
            v-model="project.tipo"
            placeholder="Ej: Desarrollo Web, Marketing, etc."
            autocomplete="off"
          >
        </div>

        <div class="form-group" :class="{ 'field-error': hasFieldError('estado') }">
          <label for="projectStatus">Estado Inicial</label>
          <select id="projectStatus" v-model="project.estado">
            <option value="planning">En Planificación</option>
            <option value="active">Activo</option>
          </select>
        </div>
      </div>

      <div class="form-section">
        <h2>Equipo</h2>
        <div class="form-group">
          <label>Miembros del Equipo</label>
          <div class="team-members">
            <div 
              v-for="member in project.miembros" 
              :key="member.id_usuario"
              class="team-member"
            >
              <img :src="member.avatar || 'https://via.placeholder.com/40'" :alt="member.nombre" class="member-avatar">
              <div class="member-info">
                <span class="member-name">{{ member.nombre }}</span>
                <span class="member-role">{{ member.rol_nombre }}</span>
                <span class="member-function">{{ member.funcion }}</span>
              </div>
              <button class="remove-member" @click="removeTeamMember(member)">
                <i class="fas fa-times"></i>
              </button>
            </div>
            <button class="add-member-btn" @click="showMembersModal = true; centerModal()">
              <i class="fas fa-plus"></i>
              Añadir Miembro
            </button>
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button class="cancel-btn" @click="$router.push('/workspace/projects')">
          Cancelar
        </button>
        <button class="create-btn" @click="createProject" :disabled="isSubmitting">
          {{ isSubmitting ? 'Creando proyecto...' : 'Crear Proyecto' }}
        </button>
      </div>
    </div>

    <!-- Modal para añadir miembros -->
    <div v-if="showMembersModal" class="modal-overlay" @click.self="closeMemberModal">
      <div class="modal" ref="memberModal">
        <div class="modal-header">
          <h3>Añadir Miembro al Equipo</h3>
          <button class="close-modal" @click="closeMemberModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="role-selection">
            <h4>Seleccionar Rol</h4>
            <div class="role-options">
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="3"
                >
                <span>Líder</span>
              </label>
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="4"
                >
                <span>Miembro</span>
              </label>
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="5"
                >
                <span>Observador</span>
              </label>
            </div>
          </div>

          <div class="form-group">
            <label for="memberFunction">Función en el Proyecto</label>
            <input 
              type="text" 
              id="memberFunction" 
              v-model="memberFunction"
              placeholder="Ej: Desarrollador, Diseñador, etc."
              autocomplete="off"
            >
          </div>

          <div class="form-group">
            <label for="memberEmail">Email del Usuario</label>
            <div class="search-input-group">
              <input 
                type="email" 
                id="memberEmail" 
                v-model="memberSearch"
                placeholder="ejemplo@correo.com"
                @keyup.enter="searchUser"
                autocomplete="off"
              >
              <button class="search-btn" @click="searchUser">
                <i class="fas fa-search"></i>
                Buscar
              </button>
            </div>
          </div>

          <div v-if="searchedUser" class="user-details">
            <div class="user-info">
              <div class="user-avatar-container">
                <img 
                  v-if="searchedUser.avatar" 
                  :src="searchedUser.avatar" 
                  :alt="searchedUser.nombre" 
                  class="user-avatar"
                  @error="handleImageError"
                >
                <div v-else class="user-avatar-placeholder">
                  {{ searchedUser.nombre.charAt(0) }}
                </div>
              </div>
              <div class="user-text">
                <h4>{{ searchedUser.nombre }}</h4>
                <p>{{ searchedUser.email }}</p>
              </div>
            </div>

            <button 
              class="add-member-btn" 
              @click="addTeamMember"
              :disabled="!canAddMember"
            >
              Añadir al Equipo
            </button>
          </div>

          <div v-else-if="searchError" class="search-error">
            {{ searchError }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'NewProjectView',
  data() {
    return {
      project: {
        nombre: '',
        descripcion: '',
        fecha_inicio: '',
        fecha_limite: '',
        tipo: '',
        estado: 'planning',
        miembros: []
      },
      showMembersModal: false,
      memberSearch: '',
      searchedUser: null,
      selectedRole: null,
      memberFunction: '',
      searchError: null,
      errorMessage: '',
      errorFields: [],
      isSubmitting: false
    }
  },
  computed: {
    isFormValid() {
      return this.project.nombre && 
             this.project.descripcion && 
             this.project.fecha_inicio && 
             this.project.fecha_limite && 
             this.project.tipo && 
             this.project.estado;
    },
    canAddMember() {
      return this.searchedUser && 
             this.selectedRole && 
             this.memberFunction.trim();
    }
  },
  watch: {
    // Observar cambios en los campos del proyecto
    'project.nombre'(newValue) {
      if (newValue && this.errorFields.includes('nombre')) {
        this.errorFields = this.errorFields.filter(field => field !== 'nombre');
      }
    },
    'project.descripcion'(newValue) {
      if (newValue && this.errorFields.includes('descripcion')) {
        this.errorFields = this.errorFields.filter(field => field !== 'descripcion');
      }
    },
    'project.fecha_inicio'(newValue) {
      if (newValue && this.errorFields.includes('fecha_inicio')) {
        this.errorFields = this.errorFields.filter(field => field !== 'fecha_inicio');
      }
    },
    'project.fecha_limite'(newValue) {
      if (newValue && this.errorFields.includes('fecha_limite')) {
        this.errorFields = this.errorFields.filter(field => field !== 'fecha_limite');
      }
    },
    'project.tipo'(newValue) {
      if (newValue && this.errorFields.includes('tipo')) {
        this.errorFields = this.errorFields.filter(field => field !== 'tipo');
      }
    }
  },
  methods: {
    hasFieldError(fieldName) {
      return this.errorFields.includes(fieldName);
    },
    setFieldError(fieldName, message) {
      this.errorMessage = message;
      this.errorFields = [fieldName];
    },
    clearErrors() {
      this.errorMessage = '';
      this.errorFields = [];
    },
    async searchUser() {
      if (!this.memberSearch) {
        this.searchError = 'Por favor, introduce un email';
        return;
      }

      // Validar formato de email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(this.memberSearch)) {
        this.searchError = 'Por favor, ingresa un correo electrónico válido';
        return;
      }

      try {
        this.searchError = null;
        this.searchedUser = null;
        
        // Añadir estado de carga
        const searchButton = document.querySelector('.search-btn');
        if (searchButton) {
          searchButton.disabled = true;
          searchButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';
        }
        
        const response = await api.searchUserByEmail(this.memberSearch);
        
        if (response && response.id_usuario) {
          this.searchedUser = {
            id_usuario: response.id_usuario,
            nombre: response.nombre,
            email: response.email,
            avatar: response.avatar ? `data:image/jpeg;base64,${response.avatar}` : null
          };
          
          // Verificar si el usuario ya es miembro del proyecto
          const existingMember = this.project.miembros.find(
            m => m.id_usuario === this.searchedUser.id_usuario
          );
          
          if (existingMember) {
            this.searchError = 'Este usuario ya es miembro del proyecto';
            this.searchedUser = null;
          }
        } else {
          this.searchError = 'Usuario no encontrado';
          this.searchedUser = null;
        }
      } catch (error) {
        console.error('Error al buscar usuario:', error);
        this.searchError = error.message || 'Error al buscar el usuario';
        this.searchedUser = null;
      } finally {
        // Restaurar el botón de búsqueda
        const searchButton = document.querySelector('.search-btn');
        if (searchButton) {
          searchButton.disabled = false;
          searchButton.innerHTML = '<i class="fas fa-search"></i> Buscar';
        }
      }
    },
    addTeamMember() {
      if (!this.canAddMember) return;

      const newMember = {
        id_usuario: this.searchedUser.id_usuario,
        nombre: this.searchedUser.nombre,
        email: this.searchedUser.email,
        avatar: this.searchedUser.avatar,
        rol_id: this.selectedRole,
        rol_nombre: this.getRoleName(this.selectedRole),
        funcion: this.memberFunction
      };

      if (!this.project.miembros.find(m => m.id_usuario === newMember.id_usuario)) {
        this.project.miembros.push(newMember);
      }

      this.closeMemberModal();
    },
    removeTeamMember(member) {
      this.project.miembros = this.project.miembros.filter(m => m.id_usuario !== member.id_usuario);
    },
    getRoleName(roleId) {
      const roles = {
        3: 'Líder',
        4: 'Miembro',
        5: 'Observador'
      };
      return roles[roleId] || '';
    },
    closeMemberModal() {
      this.showMembersModal = false;
      this.memberSearch = '';
      this.searchedUser = null;
      this.selectedRole = null;
      this.memberFunction = '';
      this.searchError = null;
    },
    centerModal() {
      this.$nextTick(() => {
        // Centrar el modal en la pantalla
        if (this.$refs.memberModal) {
          this.$refs.memberModal.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    },
    async createProject() {
      try {
        this.isSubmitting = true;
        this.errorMessage = '';
        this.errorFields = [];

        // Validar campos requeridos
        const requiredFields = ['nombre', 'descripcion', 'fecha_inicio', 'fecha_limite', 'tipo'];
        const missingFields = requiredFields.filter(field => !this.project[field]);
        
        if (missingFields.length > 0) {
          this.errorFields = missingFields;
          this.errorMessage = 'Por favor, completa todos los campos requeridos';
          return;
        }

        // Validar fechas
        if (new Date(this.project.fecha_inicio) > new Date(this.project.fecha_limite)) {
          this.errorMessage = 'La fecha de inicio no puede ser posterior a la fecha de fin';
          this.errorFields = ['fecha_inicio', 'fecha_limite'];
          return;
        }

        // Crear el proyecto
        const projectResponse = await api.createProject(this.project);
        
        // Añadir miembros al proyecto
        if (this.project.miembros.length > 0) {
          for (const member of this.project.miembros) {
            try {
              await api.addUserToProject(projectResponse.id_proyecto, {
                id_usuario: member.id_usuario,
                rol_id: member.rol_id,
                funcion: member.funcion
              });
            } catch (error) {
              console.warn(`No se pudo añadir al miembro ${member.nombre}:`, error.message);
              // Continuar con los siguientes miembros aunque falle uno
            }
          }
        }

        // Redirigir al workspace de proyectos
        this.$router.push('/workspace/projects');
      } catch (error) {
        console.error('Error al crear el proyecto:', error);
        this.errorMessage = error.message || 'Error al crear el proyecto';
        
        // Manejar errores específicos
        if (error.status === 401) {
          this.errorMessage = 'Tu sesión ha expirado. Por favor, inicia sesión nuevamente.';
          this.$router.push('/login');
        } else if (error.status === 403) {
          this.errorMessage = 'No tienes permisos para crear proyectos.';
        }
      } finally {
        this.isSubmitting = false;
      }
    },
    handleImageError(e) {
      // Reemplazar la imagen con un placeholder
      e.target.style.display = 'none';
      const container = e.target.parentElement;
      const placeholder = document.createElement('div');
      placeholder.className = 'user-avatar-placeholder';
      placeholder.textContent = this.searchedUser.nombre.charAt(0);
      container.appendChild(placeholder);
    }
  }
}
</script>

<style lang="scss" scoped>
.new-project-view {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;

  option {
    background-color: rgb(60, 68, 81);
  }

  .error-message {
    background-color: rgba(239, 68, 68, 0.2);
    color: #ef4444;
    border-left: 3px solid #ef4444;
    padding: 0.75rem 1rem;
    margin: 1rem 0;
    border-radius: var(--border-radius);
    font-size: 0.9rem;
  }

  .field-error {
    input, textarea, select {
      border-color: #ef4444 !important;
      background-color: rgba(239, 68, 68, 0.05) !important;
    }

    label {
      color: #ef4444 !important;
    }
  }

  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .back-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: white;
      text-decoration: none;
      font-weight: 500;

      &:hover {
        color: var(--primary);
      }
    }

    .header-description {
      color:rgb(162, 162, 162);
      margin: 0;
      font-size: 1rem;
    }
  }

  .project-form {
    background: rgba(255, 255, 255, 0.1);
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .form-section {
    margin-bottom: 2rem;

    h2 {
      color: white;
      font-size: 1.2rem;
      margin: 0 0 1.5rem;
    }
  }

  .form-group {
    margin-bottom: 1.5rem;

    label {
      display: block;
      margin-bottom: 0.5rem;
      color: white;
      font-weight: 500;
    }

    input[type="text"],
    input[type="date"],
    textarea,
    select {
      appearance: none;
      width: 100%;
      padding: 0.75rem;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--border-radius);
      font-size: 1rem;
      background: rgba(255, 255, 255, 0.1);
      color: white;
      font-family: inherit;

      option{
          background: rgb(60, 68, 81);
        }

      &:focus {
        outline: none;
        border-color: var(--primary);
      }

      &::placeholder {
        color: rgba(255, 255, 255, 0.5);
        font-family: inherit;
      }
    }

    textarea {
      resize: vertical;
    }
  }

  .form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
  }

  .team-members {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;

    .team-member {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem;
      background: rgba(255, 255, 255, 0.05);
      border-radius: var(--border-radius);

      .member-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        object-fit: cover;
      }

      .member-info {
        display: flex;
        flex-direction: column;

        .member-name {
          font-size: 0.9rem;
          color: white;
        }

        .member-role {
          font-size: 0.8rem;
          color: rgba(255, 255, 255, 0.7);
        }

        .member-function {
          font-size: 0.8rem;
          color: rgba(255, 255, 255, 0.7);
        }
      }

      .remove-member {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.7);
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 50%;
        transition: all 0.2s ease;

        &:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ef4444;
        }
      }
    }

    .add-member-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      background: none;
      border: 1px dashed rgba(255, 255, 255, 0.2);
      border-radius: var(--border-radius);
      color: rgba(255, 255, 255, 0.7);
      cursor: pointer;
      transition: all 0.2s ease;

      &:hover {
        border-color: var(--primary);
        color: var(--primary);
      }
    }
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    margin-top: 2rem;

    button {
      padding: 0.75rem 1.5rem;
      border-radius: var(--border-radius);
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;

      &.cancel-btn {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;

        &:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      }

      &.create-btn {
        background: var(--primary);
        border: none;
        color: white;

        &:hover {
          background: var(--primary-dark);
        }
      }
    }
  }

  .create-btn:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }

  .modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    backdrop-filter: blur(5px);
  }

  .modal {
    background: rgba(30, 41, 59, 0.85);
    border-radius: var(--border-radius);
    width: 90%;
    max-width: 500px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
    transform: translateY(0);
    opacity: 1;

    &.modal-enter-active, &.modal-leave-active {
      transition: all 0.3s ease;
    }

    &.modal-enter-from, &.modal-leave-to {
      opacity: 0;
      transform: translateY(-20px);
    }

    .modal-header {
      padding: 1.5rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(30, 41, 59, 0.95);

      h3 {
        color: white;
        margin: 0;
        font-size: 1.2rem;
      }

      .close-modal {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.7);
        cursor: pointer;
        padding: 0.5rem;
        border-radius: 50%;
        transition: all 0.2s ease;

        &:hover {
          background: rgba(255, 255, 255, 0.1);
          color: white;
        }
      }
    }

    .modal-body {
      padding: 1.5rem;

      .role-selection {
        margin-bottom: 1.5rem;

        h4 {
          color: white;
          margin: 0 0 1rem;
          font-size: 1rem;
        }

        .role-options {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;

          .role-option {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            cursor: pointer;
            color: white;
            padding: 0.5rem;
            border-radius: var(--border-radius);
            transition: all 0.2s ease;
            background: rgba(255, 255, 255, 0.05);

            &:hover {
              background: rgba(255, 255, 255, 0.1);
            }

            input[type="radio"] {
              margin: 0;
              accent-color: var(--primary);
            }
          }
        }
      }

      .form-group {
        margin-bottom: 1.5rem;

        label {
          color: white;
          display: block;
          margin-bottom: 0.5rem;
        }

        input {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: var(--border-radius);
          background: rgba(255, 255, 255, 0.05);
          color: white;
          transition: all 0.2s ease;

          &:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.1);
          }

          &::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }
        }
      }

      .search-input-group {
        display: flex;
        gap: 0.5rem;

        input {
          flex: 1;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: white;
          transition: all 0.2s ease;

          &:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.1);
          }

          &::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }
        }

        .search-btn {
          white-space: nowrap;
          background: var(--primary);
          color: white;
          border: none;
          padding: 0.75rem 1rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover {
            background: var(--primary-dark);
          }
        }
      }

      .user-details {
        margin-top: 1.5rem;
        padding: 1rem;
        background: rgba(255, 255, 255, 0.05);
        border-radius: var(--border-radius);

        .user-info {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 1rem;

          .user-avatar-container {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            overflow: hidden;
            position: relative;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;

            .user-avatar {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }

            .user-avatar-placeholder {
              width: 100%;
              height: 100%;
              display: flex;
              justify-content: center;
              align-items: center;
              font-size: 1.5rem;
              font-weight: bold;
              color: white;
              background: var(--primary);
            }
          }

          .user-text {
            h4 {
              color: white;
              margin: 0;
            }

            p {
              color: rgba(255, 255, 255, 0.7);
              margin: 0.25rem 0 0;
            }
          }
        }

        .add-member-btn {
          width: 100%;
          padding: 0.75rem;
          background: var(--primary);
          color: white;
          border: none;
          border-radius: var(--border-radius);
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover:not(:disabled) {
            background: var(--primary-dark);
          }

          &:disabled {
            opacity: 0.5;
            cursor: not-allowed;
          }
        }
      }

      .search-error {
        color: #ef4444;
        margin-top: 1rem;
        text-align: center;
        padding: 0.5rem;
        background: rgba(239, 68, 68, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
      }
    }
  }
}
</style> 