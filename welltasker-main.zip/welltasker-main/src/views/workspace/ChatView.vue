<template>
  <div class="chat-view">
    <div class="chat-sidebar">
      <div class="sidebar-header" data-aos="fade-down">
        <h2>Conversaciones</h2>
      </div>

      <div class="conversations-list" data-aos="fade-right" data-aos-delay="100">
        <div 
          v-for="chat in chats" 
          :key="chat.id" 
          class="conversation-item"
          :class="{ active: currentChat?.id === chat.id }"
          @click="selectChat(chat)"
        >
          <div class="chat-avatar ">
            <i class="far fa-user-circle"></i>
            <span class="status-indicator" :class="chat.status"></span>
          </div>
          <div class="chat-info">
            <div class="chat-header">
              <h3>{{ chat.name }}</h3>
              <span class="chat-time">{{ chat.lastMessageTime }}</span>
            </div>
            <p class="last-message">{{ chat.lastMessage }}</p>
          </div>
          <div v-if="chat.unreadCount" class="unread-badge">
            {{ chat.unreadCount }}
          </div>
        </div>
      </div>

      <button class="new-chat-btn" data-aos="fade-up" data-aos-delay="400">
        <i class="far fa-comment-alt"></i>
      </button>
    </div>

    <div class="chat-main" data-aos="fade-left" data-aos-delay="100">
      <div v-if="currentChat" class="chat-container">
        <div class="chat-header">
          <div class="chat-user-info">
            <div class="chat-avatar">
              <img :src="currentChat.avatar" :alt="currentChat.name">
              <span class="status-indicator" :class="currentChat.status"></span>
            </div>
            <div>
              <h2>{{ currentChat.name }}</h2>
              <span class="status-text">{{ getStatusText(currentChat.status) }}</span>
            </div>
          </div>
          <div class="chat-actions">
            <button class="action-btn">
              <i class="fas fa-phone"></i>
            </button>
            <button class="action-btn">
              <i class="fas fa-video"></i>
            </button>
          </div>
        </div>

        <div class="messages-container" ref="messagesContainer">
          <div 
            v-for="message in currentChat.messages" 
            :key="message.id" 
            class="message"
            :class="{ 'message-sent': message.sent }"
          >
            <div class="message-content">
              <p>{{ message.text }}</p>
              <span class="message-time">{{ message.time }}</span>
            </div>
            <div v-if="message.sent" class="message-status">
              <i class="fas fa-check-double"></i>
            </div>
          </div>
        </div>

        <div class="message-input">
          <button class="attach-btn">
            <i class="fas fa-paperclip"></i>
          </button>
          <input 
            type="text" 
            v-model="newMessage" 
            placeholder="Escribe un mensaje..."
            @keyup.enter="sendMessage"
          >
          <button class="send-btn" @click="sendMessage">
            <i class="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>

      <div v-else class="no-chat-selected">
        <i class="fas fa-comments"></i>
        <h2>Selecciona una conversación</h2>
        <p>Elige una conversación del menú lateral para comenzar a chatear</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ChatView',
  data() {
    return {
      currentChat: null,
      newMessage: '',
      chats: [
        {
          id: 1,
          name: 'Juan Pérez',
          avatar: 'https://via.placeholder.com/40',
          status: 'online',
          lastMessage: '¿Cómo va el desarrollo?',
          lastMessageTime: '10:30',
          unreadCount: 2,
          messages: [
            {
              id: 1,
              text: 'Hola, ¿cómo estás?',
              time: '10:25',
              sent: true
            },
            {
              id: 2,
              text: '¿Cómo va el desarrollo?',
              time: '10:30',
              sent: false
            }
          ]
        },
        {
          id: 2,
          name: 'María García',
          avatar: 'https://via.placeholder.com/40',
          status: 'offline',
          lastMessage: 'Revisa los cambios en el diseño',
          lastMessageTime: 'Ayer',
          unreadCount: 0,
          messages: []
        },
        {
          id: 3,
          name: 'Carlos López',
          avatar: 'https://via.placeholder.com/40',
          status: 'away',
          lastMessage: 'Perfecto, lo implementaré mañana',
          lastMessageTime: 'Lun',
          unreadCount: 1,
          messages: []
        }
      ]
    }
  },
  methods: {
    selectChat(chat) {
      this.currentChat = chat
      chat.unreadCount = 0
      this.$nextTick(() => {
        this.scrollToBottom()
      })
    },
    sendMessage() {
      if (!this.newMessage.trim() || !this.currentChat) return

      const message = {
        id: Date.now(),
        text: this.newMessage,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sent: true
      }

      this.currentChat.messages.push(message)
      this.newMessage = ''
      this.$nextTick(() => {
        this.scrollToBottom()
      })
    },
    scrollToBottom() {
      const container = this.$refs.messagesContainer
      if (container) {
        container.scrollTop = container.scrollHeight
      }
    },
    getStatusText(status) {
      const statusTexts = {
        online: 'En línea',
        offline: 'Fuera de línea',
        away: 'Ausente'
      }
      return statusTexts[status] || status
    }
  }
}
</script>

<style lang="scss" scoped>
.chat-view {
  padding: 2rem;
  display: flex;
  gap: 2rem;
  height: calc(100vh - 100px);

  .chat-sidebar {
    width: 300px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius);
    display: flex;
    flex-direction: column;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    position: relative;

    .sidebar-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(255, 255, 255, 0.05);

      h2 {
        margin: 0;
        font-size: 1.1rem;
        color: white;
      }
    }

    .conversations-list {
      flex: 1;
      overflow-y: auto;
      padding: 0.75rem;
      height: calc(100% - 70px);
      padding-bottom: 5rem;

      &::-webkit-scrollbar {
        width: 8px;
      }

      &::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 4px;
      }

      &::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.2);
        border-radius: 4px;

        &:hover {
          background: rgba(255, 255, 255, 0.3);
        }
      }

      .conversation-item {
        display: flex;
        align-items: center;
        padding: 1rem;
        cursor: pointer;
        transition: all 0.2s ease;
        border-radius: var(--border-radius);
        margin-bottom: 0.5rem;

        &:hover {
          background: rgba(255, 255, 255, 0.1);
        }

        &.active {
          background: rgba(var(--primary-rgb), 0.2);
        }

        .chat-avatar {
          position: relative;
          margin-right: 1rem;

          img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
          }

          .status-indicator {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 2px solid rgba(30, 30, 30, 0.95);

            &.online {
              background-color: #10b981;
            }

            &.offline {
              background-color: #6b7280;
            }

            &.away {
              background-color: #f59e0b;
            }
          }
        }

        .chat-info {
          flex: 1;
          min-width: 0;

          .chat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.25rem;

            h3 {
              margin: 0;
              font-size: 0.9rem;
              color: white;
            }

            .chat-time {
              font-size: 0.8rem;
              color: rgba(255, 255, 255, 0.6);
            }
          }

          .last-message {
            margin: 0;
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.7);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
        }

        .unread-badge {
          background-color: var(--primary);
          color: white;
          font-size: 0.7rem;
          padding: 0.2rem 0.4rem;
          border-radius: 10px;
          margin-left: 0.5rem;
        }
      }
    }

    .new-chat-btn {
      position: absolute;
      bottom: 1rem;
      right: 1rem;
      background: var(--primary);
      border: none;
      color: white;
      cursor: pointer;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
      z-index: 10;

      &:hover {
        background: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      }

      i {
        font-size: 1.2rem;
      }
    }
  }

  .chat-main {
    flex: 1;
    display: flex;
    flex-direction: column;
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .no-chat-selected {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: rgba(255, 255, 255, 0.7);
      text-align: center;
      padding: 2rem;

      i {
        font-size: 3rem;
        margin-bottom: 1rem;
      }

      h2 {
        margin: 0 0 0.5rem;
        color: white;
      }

      p {
        margin: 0;
        color: rgba(255, 255, 255, 0.7);
      }
    }

    .chat-container {
      height: 100%;
      display: flex;
      flex-direction: column;

      .chat-header {
        padding: 1.5rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;

        .chat-user-info {
          display: flex;
          align-items: center;
          gap: 1rem;

          .chat-avatar {
            position: fixed;

            img {
              width: 40px;
              height: 40px;
              border-radius: 50%;
              object-fit: cover;
            }

            .status-indicator {
              position: absolute;
              bottom:auto;
              right: 0;
              width: 12px;
              height: 12px;
              border-radius: 50%;
              border: 2px solid rgba(30, 30, 30, 0.95);

              &.online {
                background-color: #10b981;
              }

              &.offline {
                background-color: #6b7280;
              }

              &.away {
                background-color: #f59e0b;
              }
            }
          }

          h2 {
            margin: 0;
            color: white;
            font-size: 1.1rem;
          }

          .status-text {
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.6);
          }
        }

        .chat-actions {
          display: flex;
          gap: 0.5rem;

          .action-btn {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
            cursor: pointer;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;

            &:hover {
              background: rgba(255, 255, 255, 0.2);
              transform: translateY(-1px);
            }
          }
        }
      }

      .messages-container {
        flex: 1;
        overflow-y: auto;
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        gap: 1rem;

        &::-webkit-scrollbar {
          width: 8px;
        }

        &::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 4px;
        }

        &::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.2);
          border-radius: 4px;

          &:hover {
            background: rgba(255, 255, 255, 0.3);
          }
        }

        .message {
          display: flex;
          align-items: flex-end;
          gap: 0.5rem;
          max-width: 70%;

          &.message-sent {
            align-self: flex-end;
            flex-direction: row-reverse;

            .message-content {
              background: var(--primary);
              color: white;
              border-radius: 1rem 1rem 0 1rem;

              .message-time {
                color: rgba(255, 255, 255, 0.8);
              }
            }

            .message-status {
              color: var(--primary);
              font-size: 0.8rem;
            }
          }

          &:not(.message-sent) .message-content {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-radius: 1rem 1rem 1rem 0;

            .message-time {
              color: rgba(255, 255, 255, 0.6);
            }
          }

          .message-content {
            padding: 0.75rem 1rem;
            position: relative;

            p {
              margin: 0;
              font-size: 0.9rem;
              line-height: 1.5;
            }

            .message-time {
              font-size: 0.7rem;
              margin-top: 0.25rem;
            }
          }
        }
      }

      .message-input {
        padding: 1.5rem;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        gap: 1rem;

        .attach-btn {
          background: rgba(255, 255, 255, 0.1);
          border: none;
          color: white;
          cursor: pointer;
          width: 42px;
          height: 42px;
          border-radius: var(--border-radius);
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s ease;

          &:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-1px);
          }
        }

        input {
          flex: 1;
          padding: 0.75rem 1rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: var(--border-radius);
          font-size: 0.9rem;
          background: rgba(255, 255, 255, 0.1);
          color: white;

          &::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }

          &:focus {
            outline: none;
            border-color: var(--primary);
          }
        }

        .send-btn {
          background: var(--primary);
          border: none;
          color: white;
          cursor: pointer;
          width: 42px;
          height: 42px;
          border-radius: var(--border-radius);
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s ease;

          &:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
          }

          &:disabled {
            background: rgba(255, 255, 255, 0.1);
            cursor: not-allowed;
            transform: none;
          }
        }
      }
    }
  }
}
</style> 