<template>
  <div class="tasks-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Tareas</h1>
      <router-link to="/workspace/tasks/new" class="new-task-btn">
        <i class="fas fa-plus"></i>
        Nueva Tarea
      </router-link>
    </div>

    <div v-if="loading" class="loading">
      Cargando tareas...
    </div>
    <div v-else-if="error" class="error">
      {{ error }}
    </div>
    <div v-else>
      <div class="tasks-filters" data-aos="fade-up" data-aos-delay="100">
        <div class="filter-group">
          <label>Estado</label>
          <select v-model="selectedStatus" class="filter-select">
            <option value="all">Todos</option>
            <option value="pendiente">Pendientes</option>
            <option value="en_progreso">En Progreso</option>
            <option value="completada">Completadas</option>
          </select>
        </div>
        <div class="filter-group">
          <label>Prioridad</label>
          <select v-model="selectedPriority" class="filter-select">
            <option value="all">Todas</option>
            <option value="alta">Alta</option>
            <option value="media">Media</option>
            <option value="baja">Baja</option>
          </select>
        </div>
        <div class="search-group">
          <label>Buscar</label>
          <i class="fas fa-search"></i>
          <input 
            type="text" 
            v-model="searchQuery"
            placeholder="Buscar tareas..."
          >
        </div>
      </div>

      <div class="tasks-list">
        <div 
          v-for="(task, index) in filteredTasks" 
          :key="task.id_tarea" 
          class="task-card"
          :data-aos="index % 2 === 0 ? 'fade-right' : 'fade-left'"
          :data-aos-delay="200 + (index * 10)"
          @click="showTaskDetails(task, $event)"
        >
          <div class="task-header">
            <div class="task-title">
              <h3>{{ task.titulo }}</h3>
            </div>
          </div>

          <p class="task-description">{{ task.descripcion }}</p>

          <div class="task-meta">
            <div class="meta-item">
              <i class="fas fa-project-diagram"></i>
              <span>{{ getProjectName(task.id_proyecto) }}</span>
            </div>
            <div class="meta-item">
              <i class="fas fa-user"></i>
              <span>{{ task.nombre_asignado || 'Sin asignar' }}</span>
            </div>
            <div class="meta-item">
              <i class="fas fa-calendar"></i>
              <span>{{ formatDate(task.fecha_vencimiento) }}</span>
            </div>
          </div>

          <div class="task-tags">
            <span class="tag priority" :class="task.prioridad">{{ task.prioridad }}</span>
            <span class="tag status" :class="task.estado">{{ task.estado }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de detalles de tarea -->
    <div v-if="selectedTask" class="modal" data-aos="fade-up" :style="modalStyle">
      <div class="modal-content">
        <div class="modal-header">
          <h3>Detalles de la Tarea</h3>
          <button class="close-modal" @click="selectedTask = null">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="task-details">
            <div class="detail-group">
              <label>Título</label>
              <h2>{{ selectedTask.titulo }}</h2>
            </div>
            <div class="detail-group">
              <label>Descripción</label>
              <p>{{ selectedTask.descripcion }}</p>
            </div>
            <div class="detail-row">
              <div class="detail-group">
                <label>Estado</label>
                <span class="task-status" :class="selectedTask.estado">
                  {{ getStatusText(selectedTask.estado) }}
                </span>
              </div>
              <div class="detail-group">
                <label>Prioridad</label>
                <span class="task-priority" :class="selectedTask.prioridad">
                  {{ getPriorityText(selectedTask.prioridad) }}
                </span>
              </div>
            </div>
            <div class="detail-row">
              <div class="detail-group">
                <label>Proyecto</label>
                <p>{{ getProjectName(selectedTask.id_proyecto) }}</p>
              </div>
              <div class="detail-group">
                <label>Asignado a</label>
                <div class="assignee-info">
                  <img :src="selectedTask.avatar_asignado ? `data:image/jpeg;base64,${selectedTask.avatar_asignado}` : 'https://via.placeholder.com/40'" :alt="selectedTask.nombre_asignado">
                  <span>{{ selectedTask.nombre_asignado || 'Sin asignar' }}</span>
                </div>
              </div>
            </div>
            <div class="detail-group">
              <label>Fecha de Vencimiento</label>
              <p>{{ formatDate(selectedTask.fecha_vencimiento) }}</p>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="complete-btn" @click="completeTask(selectedTask)">
            <i class="fas fa-check"></i>
            Completar Tarea
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import api from '@/api'
import AOS from 'aos'
import 'aos/dist/aos.css'

export default {
  name: 'TasksView',
  setup() {
    const route = useRoute()
    const tasks = ref([])
    const loading = ref(true)
    const error = ref(null)
    const selectedStatus = ref('all')
    const selectedPriority = ref('all')
    const searchQuery = ref('')
    const selectedProjectId = ref(null)
    const selectedTask = ref(null)
    const projects = ref([])
    const users = ref([])
    const modalPosition = ref({ top: 0, left: 0 })
    const assigneeNames = ref({})

    const fetchTasks = async () => {
      try {
        loading.value = true
        const token = localStorage.getItem('token')
        if (!token) {
          throw new Error('No hay token de autenticación')
        }
        
        // Obtener el proyecto seleccionado del localStorage
        const selectedProject = JSON.parse(localStorage.getItem('selectedProject') || 'null')
        selectedProjectId.value = selectedProject ? selectedProject.id_proyecto : null
        
        console.log('Proyecto seleccionado:', selectedProject)
        console.log('ID del proyecto:', selectedProjectId.value)
        
        // Construir la URL con el filtro de proyecto si existe
        const projectId = selectedProjectId.value || route.params.projectId
        console.log('Consultando tareas para el proyecto:', projectId)
        
        const response = await api.getTasks(projectId)
        console.log('Respuesta de tareas:', response)
        
        // Añadir el rol_id a cada tarea
        tasks.value = response.map(task => ({
          ...task,
          rol_id: selectedProject ? selectedProject.rol_id : null
        }))
        
        console.log('Tareas asignadas:', tasks.value)
      } catch (err) {
        error.value = 'Error al cargar las tareas'
        console.error('Error fetching tasks:', err)
      } finally {
        loading.value = false
      }
    }

    const filteredTasks = computed(() => {
      return tasks.value.filter(task => {
        const matchesStatus = selectedStatus.value === 'all' || task.estado === selectedStatus.value
        const matchesPriority = selectedPriority.value === 'all' || task.prioridad === selectedPriority.value
        const matchesSearch = !searchQuery.value || 
          task.titulo.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
          task.descripcion.toLowerCase().includes(searchQuery.value.toLowerCase())
        return matchesStatus && matchesPriority && matchesSearch
      })
    })

    const formatDate = (dateString) => {
      if (!dateString) return 'Sin fecha límite'
      const date = new Date(dateString)
      return date.toLocaleDateString('es-ES', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      })
    }

    // Observar cambios en el localStorage para detectar cuando cambia el proyecto seleccionado
    const checkSelectedProject = () => {
      const selectedProject = JSON.parse(localStorage.getItem('selectedProject') || 'null')
      const newProjectId = selectedProject ? selectedProject.id_proyecto : null
      
      if (newProjectId !== selectedProjectId.value) {
        selectedProjectId.value = newProjectId
        fetchTasks()
      }
    }

    const loadProjects = async () => {
      try {
        const response = await api.getUserProjects()
        projects.value = response
      } catch (error) {
        console.error('Error al cargar los proyectos:', error)
      }
    }

    const loadUsers = async () => {
      try {
        const response = await api.api.get('/users')
        users.value = response.data
        console.log('Usuarios cargados:', users.value)
      } catch (error) {
        console.error('Error al cargar los usuarios:', error)
      }
    }

    const getStatusText = (status) => {
      const statusTexts = {
        'todo': 'Por Hacer',
        'in-progress': 'En Progreso',
        'review': 'En Revisión',
        'done': 'Completada'
      }
      return statusTexts[status] || status
    }

    const getPriorityText = (priority) => {
      const priorityTexts = {
        'low': 'Baja',
        'medium': 'Media',
        'high': 'Alta',
        'urgent': 'Urgente'
      }
      return priorityTexts[priority] || priority
    }

    const getProjectName = (projectId) => {
      const project = projects.value.find(p => p.id_proyecto === projectId)
      return project ? project.nombre : 'Proyecto Desconocido'
    }

    const getAssigneeName = (userId) => {
      if (!userId) return 'Sin asignar'
      const user = users.value.find(u => u.id_usuario === userId)
      console.log('Buscando usuario:', userId, 'Encontrado:', user)
      return user ? `${user.nombre} ${user.apellido}` : 'Usuario Desconocido'
    }

    const getAssigneeAvatar = (userId) => {
      const user = users.value.find(u => u.id_usuario === userId)
      if (user && user.avatar) {
        return user.avatar.startsWith('data:image') ? user.avatar : `data:image/jpeg;base64,${user.avatar}`
      }
      return 'https://via.placeholder.com/40'
    }

    const editTask = (task) => {
      selectedTask.value = task
    }

    const deleteTask = async (task) => {
      try {
        await api.delete(`/tasks/${task.id_tarea}`)
        await fetchTasks() // Recargamos las tareas después de eliminar
      } catch (error) {
        console.error('Error al eliminar la tarea:', error)
      }
    }

    const showTaskDetails = (task, event) => {
      const rect = event.currentTarget.getBoundingClientRect()
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop
      
      // Calcular la posición del modal basada en la posición del elemento clickeado
      modalPosition.value = {
        top: rect.top + scrollTop + (rect.height / 2), // Posición vertical del elemento + mitad de su altura
        left: window.innerWidth / 2 // Mantenemos el centrado horizontal
      }
      
      selectedTask.value = task
    }

    const modalStyle = computed(() => {
      return {
        position: 'fixed',
        top: `${modalPosition.value.top}px`,
        left: `${modalPosition.value.left}px`,
        transform: 'translate(-50%, -50%)'
      }
    })

    onMounted(async () => {
      AOS.init({
        duration: 800,
        once: true,
        offset: 50,
        disable: 'mobile'
      })
      
      // Primero cargamos los usuarios
      await loadUsers()
      // Luego cargamos los proyectos
      await loadProjects()
      // Finalmente cargamos las tareas
      await fetchTasks()
      
      // Configurar un intervalo para verificar cambios en el proyecto seleccionado
      setInterval(checkSelectedProject, 1000)
    })

    return {
      tasks,
      loading,
      error,
      selectedStatus,
      selectedPriority,
      searchQuery,
      filteredTasks,
      formatDate,
      selectedTask,
      projects,
      users,
      getStatusText,
      getPriorityText,
      getProjectName,
      getAssigneeName,
      getAssigneeAvatar,
      editTask,
      deleteTask,
      showTaskDetails,
      modalStyle,
      assigneeNames
    }
  }
}
</script>

<style lang="scss" scoped>
.tasks-view {
  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .new-task-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: var(--primary);
      color: white;
      text-decoration: none;
      border-radius: var(--border-radius);
      transition: all 0.2s ease;

      &:hover {
        background: var(--primary-dark);
      }

      i {
        font-size: 1.1rem;
      }
    }
  }

  .tasks-filters {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .filter-group {
      flex: 1;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      select {
        appearance: none;
        width: 100%;
        padding: 0.75rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;

        option {
          background: rgb(60, 68, 81);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }

    .search-group {
      flex: 2;
      position: relative;
      display: flex;
      flex-direction: column;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      i {
        position: absolute;
        left: 1rem;
        top: calc(50% + 1rem);
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.7);
      }

      input {
        width: 100%;
        padding: 0.75rem 1rem 0.75rem 2.5rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;

        &::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }
  }

  .tasks-list {
    display: grid;
    gap: 1rem;
  }

  .task-card {
    background: rgba(255, 255, 255, 0.05);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    cursor: pointer;
    transition: all 0.2s ease;

    &:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-2px);
    }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;

      .task-title {
        display: flex;
        align-items: center;
        gap: 1rem;

        h3 {
          margin: 0;
          color: white;
          font-size: 1.1rem;
        }
      }
    }

    .task-description {
      color: rgba(255, 255, 255, 0.8);
      font-size: 0.9rem;
      margin-bottom: 1rem;
    }

    .task-meta {
      display: flex;
      gap: 1rem;
      color: rgba(255, 255, 255, 0.7);
      font-size: 0.8rem;
      margin-bottom: 1rem;

      .meta-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;

        i {
          color: var(--primary);
        }
      }
    }

    .task-tags {
      display: flex;
      gap: 0.5rem;

      .tag {
        padding: 0.25rem 0.5rem;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 500;

        &.priority {
          &.alta {
            background: #fee2e2;
            color: #dc2626;
          }
          &.media {
            background: #fef3c7;
            color: #d97706;
          }
          &.baja {
            background: #dcfce7;
            color: #16a34a;
          }
        }

        &.status {
          &.pendiente {
            background: #f3f4f6;
            color: #6b7280;
          }
          &.en_progreso {
            background: #dbeafe;
            color: #2563eb;
          }
          &.completada {
            background: #dcfce7;
            color: #16a34a;
          }
        }
      }
    }
  }
}

.loading, .error {
  text-align: center;
  padding: 20px;
  color: white;
}

.error {
  color: #f44336;
}

.modal {
  position: fixed;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  width: auto;
  height: auto;

  .modal-content {
    position: relative;
    background: rgba(30, 41, 59, 0.85);
    border-radius: 15px;
    width: 95%;
    max-width: 1000px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    animation: modalFadeIn 0.3s ease;

    .modal-header {
      position: sticky;
      top: 0;
      background: rgba(30, 41, 59, 0.95);
      backdrop-filter: blur(10px);
      z-index: 10;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      padding: 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;

      h3 {
        color: white;
        margin: 0;
        font-size: 1.2rem;
      }

      .close-modal {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.7);
        cursor: pointer;
        padding: 0.5rem;
        border-radius: 50%;
        transition: all 0.2s ease;
        position: relative;
        z-index: 11;

        &:hover {
          background: rgba(255, 255, 255, 0.1);
          color: white;
        }
      }
    }

    .modal-body {
      padding: 1.5rem;

      .task-details {
        .detail-group {
          margin-bottom: 1.5rem;

          label {
            display: block;
            color: white;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
          }

          h2 {
            margin: 0;
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.5rem;
          }

          p {
            margin: 0;
            color: rgba(255, 255, 255, 0.7);
            line-height: 1.5;
          }

          span {
            margin: 0;
            color: rgba(255, 255, 255, 0.7);
            line-height: 1.5;
          }

          .assignee-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: rgba(255, 255, 255, 0.7);

            img {
              width: 32px;
              height: 32px;
              border-radius: 50%;
              object-fit: cover;
            }
          }
        }

        .detail-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1.5rem;
        }
      }
    }

    .modal-footer {
      padding: 1.5rem;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      justify-content: flex-end;

      .complete-btn {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem 1.5rem;
        background: var(--primary);
        border: none;
        border-radius: var(--border-radius);
        color: white;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;

        &:hover {
          background: var(--primary-dark);
          transform: translateY(-1px);
        }

        i {
          font-size: 1rem;
        }
      }
    }
  }
}

@keyframes modalFadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style> 