<template>
  <div class="files-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Archivos</h1>
      <router-link to="/workspace/files/upload" class="upload-btn">
        <i class="fas fa-upload"></i>
        Subir Archivos
      </router-link>
    </div>

    <div class="files-filters" data-aos="fade-up" data-aos-delay="100">
      <div class="filter-group">
        <label>Tipo</label>
        <select v-model="filters.type">
          <option value="">Todos</option>
          <option value="document">Documentos</option>
          <option value="image">Imágenes</option>
          <option value="video">Videos</option>
          <option value="audio">Audio</option>
        </select>
      </div>
      <div class="filter-group">
        <label>Proyecto</label>
        <select v-model="filters.project">
          <option value="">Todos</option>
          <option v-for="project in projects" :key="project.id" :value="project.id">
            {{ project.name }}
          </option>
        </select>
      </div>
      <div class="search-group">
        <label>Buscar</label>
        <i class="fas fa-search"></i>
        <input 
          type="text" 
          v-model="filters.search"
          placeholder="Buscar archivos..."
        >
      </div>
    </div>

    <div class="files-grid">
      <div 
        v-for="(file, index) in filteredFiles" 
        :key="file.id" 
        class="file-card"
        :data-aos="index % 2 === 0 ? 'fade-right' : 'fade-left'"
        :data-aos-delay="200 + (index * 100)"
      >
        <div class="file-icon">
          <i :class="getFileIcon(file.type)"></i>
        </div>
        <div class="file-info">
          <h3>{{ file.name }}</h3>
          <p class="file-meta">
            <span>{{ file.size }}</span>
            <span>•</span>
            <span>{{ file.uploadDate }}</span>
          </p>
          <p class="file-project">{{ getProjectName(file.projectId) }}</p>
        </div>
        <div class="file-actions">
          <button class="action-btn" @click="downloadFile(file)">
            <i class="fas fa-download"></i>
          </button>
          <button class="action-btn" @click="shareFile(file)">
            <i class="fas fa-share-alt"></i>
          </button>
          <button class="action-btn" @click="deleteFile(file)">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AOS from 'aos';
import 'aos/dist/aos.css';

export default {
  name: 'FilesView',
  data() {
    return {
      filters: {
        type: '',
        project: '',
        search: ''
      },
      projects: [
        { id: 1, name: 'Proyecto de Desarrollo Web' },
        { id: 2, name: 'Diseño de UI/UX' },
        { id: 3, name: 'Testing y QA' }
      ],
      files: [
        {
          id: 1,
          name: 'Documento de Requisitos.pdf',
          type: 'document',
          size: '2.5 MB',
          uploadDate: '10/03/2024',
          projectId: 1
        },
        {
          id: 2,
          name: 'Diseño de Interfaz.png',
          type: 'image',
          size: '1.8 MB',
          uploadDate: '12/03/2024',
          projectId: 2
        },
        {
          id: 3,
          name: 'Presentación del Proyecto.pptx',
          type: 'document',
          size: '5.2 MB',
          uploadDate: '15/03/2024',
          projectId: 1
        }
      ]
    }
  },
  mounted() {
    AOS.init({
      duration: 800,
      once: true,
      offset: 50,
      disable: 'mobile'
    });
  },
  beforeUnmount() {
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  },
  computed: {
    filteredFiles() {
      return this.files.filter(file => {
        if (this.filters.type && file.type !== this.filters.type) return false;
        if (this.filters.project && file.projectId !== this.filters.project) return false;
        if (this.filters.search && !file.name.toLowerCase().includes(this.filters.search.toLowerCase())) return false;
        return true;
      });
    }
  },
  methods: {
    getProjectName(projectId) {
      const project = this.projects.find(p => p.id === projectId);
      return project ? project.name : 'Proyecto Desconocido';
    },
    getFileIcon(type) {
      switch (type) {
        case 'document':
          return 'fas fa-file-alt';
        case 'image':
          return 'fas fa-file-image';
        case 'video':
          return 'fas fa-file-video';
        case 'audio':
          return 'fas fa-file-audio';
        default:
          return 'fas fa-file';
      }
    },
    // eslint-disable-next-line no-unused-vars
    downloadFile(file) {
      // Implementar lógica de descarga
    },
    // eslint-disable-next-line no-unused-vars
    shareFile(file) {
      // Implementar lógica de compartir
    },
    // eslint-disable-next-line no-unused-vars
    deleteFile(file) {
      // Implementar lógica de eliminación
    }
  }
}
</script>

<style lang="scss" scoped>
.files-view {
  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .upload-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: var(--primary);
      color: white;
      text-decoration: none;
      border-radius: var(--border-radius);
      transition: all 0.2s ease;

      &:hover {
        background: var(--primary-dark);
      }

      i {
        font-size: 1.1rem;
      }
    }
  }

  .files-filters {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .filter-group {
      flex: 1;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      select {
        appearance: none;
        width: 100%;
        padding: 0.75rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;
        height: 45px;

        option {
        background-color: rgb(60, 68, 81);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }

    .search-group {
      flex: 2;
      position: relative;
      display: flex;
      flex-direction: column;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      i {
        position: absolute;
        left: 1rem;
        top: calc(50% + 1rem);
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.7);
      }

      input {
        width: 100%;
        padding: 0.75rem 1rem 0.75rem 2.5rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;
        height: 45px;

        &::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }
  }

  .files-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 1.5rem;
  }

  .file-card {
    background: rgba(255, 255, 255, 0.05);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: flex-start;
    gap: 1rem;

    .file-icon {
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: var(--border-radius);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--primary);
      font-size: 1.2rem;
    }

    .file-info {
      flex: 1;
      min-width: 0;

      h3 {
        margin: 0 0 0.5rem;
        color: white;
        font-size: 1rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .file-meta {
        color: rgba(255, 255, 255, 0.8);
        font-size: 0.8rem;
        margin: 0 0 0.5rem;
        display: flex;
        gap: 0.5rem;
      }

      .file-project {
        color: var(--primary);
        font-size: 0.8rem;
        margin: 0;
      }
    }

    .file-actions {
      display: flex;
      gap: 0.5rem;

      .action-btn {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.8);
        cursor: pointer;
        padding: 0.25rem;
        transition: color 0.2s ease;

        &:hover {
          color: var(--primary);
        }
      }
    }
  }
}
</style> 