<template>
  <div class="projects-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Proyectos</h1>
      <router-link to="/workspace/projects/new" class="new-project-btn">
        <i class="fas fa-plus"></i>
        Nuevo Proyecto
      </router-link>
    </div>

    <div class="projects-filters" data-aos="fade-up" data-aos-delay="100">
      <div class="filter-group">
        <label>Rol</label>
        <select v-model="filters.rol">
          <option value="">Todos</option>
          <option value="2">Administrador</option>
          <option value="3">Líder</option>
          <option value="4">Miembro</option>
          <option value="5">Observador</option>
        </select>
      </div>
      <div class="search-group">
        <label>Buscar</label>
        <i class="fas fa-search"></i>
        <input 
          type="text" 
          v-model="filters.search"
          placeholder="Buscar proyectos..."
        >
      </div>
    </div>

    <div v-if="loading" class="loading-spinner" data-aos="fade-up">
      Cargando proyectos...
    </div>

    <div v-else-if="filteredProjects.length > 0" class="projects-grid">
      <div 
        v-for="(project, index) in filteredProjects" 
        :key="project.id_proyecto" 
        class="project-card"
        :class="{ 'selected': selectedProject?.id_proyecto === project.id_proyecto }"
        :data-aos="index % 2 === 0 ? 'fade-right' : 'fade-left'"
        :data-aos-delay="200"
        :data-aos-once="true"
        :data-aos-disable="selectedProject?.id_proyecto === project.id_proyecto"
        @click="selectProject(project)"
      >
        <div class="project-header">
          <h3>{{ project.nombre }}</h3>
          <div class="project-actions">
            <button class="action-btn info-btn" @click.stop="showProjectInfo(project)">
              <i class="fas fa-info-circle"></i>
            </button>
            <button v-if="project.rol_id == 2" class="action-btn edit-btn" @click.stop="editProject(project)">
              <i class="fas fa-edit"></i>
            </button>
            <button v-if="project.rol_id == 2" class="action-btn delete-btn" @click.stop="deleteProject(project)">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </div>
        <p class="project-description">{{ truncateDescription(project.descripcion) }}</p>
        <div class="project-stats">
          <div class="stat">
            <i class="fas fa-tasks"></i>
            <span>{{ project.tasksCount || 0 }} tareas</span>
          </div>
          <div class="stat">
            <i class="fas fa-users"></i>
            <span>{{ project.membersCount || 0 }} miembros</span>
          </div>
          <div class="stat">
            <i class="fas fa-calendar"></i>
            <span>{{ formatDate(project.fecha_limite) }}</span>
          </div>
        </div>
        <div class="project-progress">
          <div class="progress-bar">
            <div class="progress-fill" :style="{ width: `${project.progress || 0}%` }"></div>
          </div>
          <span class="progress-text">{{ project.progress || 0 }}% completado</span>
        </div>
      </div>
    </div>

    <div v-else class="no-projects" data-aos="fade-up">
      <p>No hay proyectos disponibles.</p>
      <router-link to="/workspace/projects/new" class="new-project-btn">
        <i class="fas fa-plus"></i>
        Crear un Nuevo Proyecto
      </router-link>
    </div>

    <!-- Modal de Edición -->
    <div v-if="showEditModal" class="modal-overlay" @click.self="closeEditModal">
      <div class="modal edit-modal" ref="editModal">
        <div class="modal-header">
          <h3>Editar Proyecto</h3>
          <button class="close-modal" @click="closeEditModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <!-- Mensaje de error general -->
          <div v-if="errorMessage" class="error-message">
            {{ errorMessage }}
          </div>

          <div class="form-section">
            <h4>Información Básica</h4>
            <div class="form-group" :class="{ 'field-error': hasFieldError('nombre') }">
              <label for="editProjectName">Nombre del Proyecto</label>
              <input 
                type="text" 
                id="editProjectName" 
                v-model="editingProject.nombre"
                placeholder="Ej: Sitio Web Corporativo"
              >
            </div>

            <div class="form-group" :class="{ 'field-error': hasFieldError('descripcion') }">
              <label for="editProjectDescription">Descripción</label>
              <textarea 
                id="editProjectDescription" 
                v-model="editingProject.descripcion"
                rows="4"
                placeholder="Describe el propósito y objetivos del proyecto"
              ></textarea>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label for="editStartDate">Fecha de Inicio</label>
                <input 
                  type="date" 
                  id="editStartDate" 
                  v-model="editingProject.fecha_inicio"
                  disabled
                >
                <small class="form-text">La fecha de inicio no puede ser modificada</small>
              </div>

              <div class="form-group" :class="{ 'field-error': hasFieldError('fecha_limite') }">
                <label for="editEndDate">Fecha de Fin</label>
                <input 
                  type="date" 
                  id="editEndDate" 
                  v-model="editingProject.fecha_limite"
                >
              </div>
            </div>
          </div>

          <div class="form-section">
            <h4>Configuración</h4>
            <div class="form-group" :class="{ 'field-error': hasFieldError('tipo') }">
              <label for="editProjectType">Tipo de Proyecto</label>
              <input 
                type="text" 
                id="editProjectType" 
                v-model="editingProject.tipo"
                placeholder="Ej: Desarrollo Web, Marketing, etc."
                autocomplete="off"
              >
            </div>

            <div class="form-group">
              <label for="editProjectStatus">Estado del Proyecto</label>
              <select id="editProjectStatus" v-model="editingProject.estado">
                <option value="planning">En Planificación</option>
                <option value="active">Activo</option>
                <option value="paused">En Pausa</option>
                <option value="completed">Completado</option>
                <option value="suspended">Suspendido</option>
              </select>
            </div>
          </div>

          <div class="form-section">
            <h4>Equipo</h4>
            <div class="form-group">
              <label>Miembros del Equipo</label>
              <div class="team-members">
                <div 
                  v-for="member in editingProject.miembros" 
                  :key="member.id_usuario"
                  class="team-member"
                >
                  <img :src="member.avatar || 'https://via.placeholder.com/40'" :alt="member.nombre" class="member-avatar">
                  <div class="member-info">
                    <span class="member-name">{{ member.nombre }}</span>
                    <span class="member-role">{{ member.rol_nombre }}</span>
                    <span class="member-function">{{ member.funcion }}</span>
                  </div>
                  <button class="remove-member" @click="removeTeamMember(member)">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <button class="add-member-btn" @click="openMemberModal">
                  <i class="fas fa-plus"></i>
                  Añadir Miembro
                </button>
              </div>
            </div>
          </div>

          <div class="form-actions">
            <button class="cancel-btn" @click="closeEditModal">
              Cancelar
            </button>
            <button class="save-btn" @click="updateProject">
              Guardar Cambios
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Eliminación -->
    <div v-if="showDeleteModal" class="modal-overlay" @click.self="closeDeleteModal">
      <div class="modal delete-modal" ref="deleteModal">
        <div class="modal-header">
          <h3>Eliminar Proyecto</h3>
          <button class="close-modal" @click="closeDeleteModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="delete-confirmation">
            <i class="fas fa-exclamation-triangle"></i>
            <p>¿Estás seguro de que deseas eliminar el proyecto "{{ projectToDelete?.nombre }}"?</p>
            <p class="warning-text">Esta acción no se puede deshacer y eliminará todas las tareas asociadas al proyecto.</p>
          </div>
          <div class="form-actions">
            <button class="cancel-btn" @click="closeDeleteModal">
              Cancelar
            </button>
            <button class="delete-btn" @click="confirmDelete">
              Eliminar Proyecto
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para añadir miembros -->
    <div v-if="showMembersModal" class="modal-overlay" @click.self="closeMemberModal">
      <div class="modal" ref="memberModal">
        <div class="modal-header">
          <h3>Añadir Miembro al Equipo</h3>
          <button class="close-modal" @click="closeMemberModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="role-selection">
            <h4>Seleccionar Rol</h4>
            <div class="role-options">
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="3"
                >
                <span>Líder</span>
              </label>
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="4"
                >
                <span>Miembro</span>
              </label>
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="5"
                >
                <span>Observador</span>
              </label>
            </div>
          </div>

          <div class="form-group">
            <label for="memberFunction">Función en el Proyecto</label>
            <input 
              type="text" 
              id="memberFunction" 
              v-model="memberFunction"
              placeholder="Ej: Desarrollador, Diseñador, etc."
              autocomplete="off"
            >
          </div>

          <div class="form-group">
            <label for="memberEmail">Email del Usuario</label>
            <div class="search-input-group">
              <input 
                type="email" 
                id="memberEmail" 
                v-model="memberSearch"
                placeholder="ejemplo@correo.com"
                @keyup.enter="searchUser"
                autocomplete="off"
              >
              <button class="search-btn" @click="searchUser">
                <i class="fas fa-search"></i>
                Buscar
              </button>
            </div>
          </div>

          <div v-if="searchedUser" class="user-details">
            <div class="user-info">
              <div class="user-avatar-container">
                <img 
                  v-if="searchedUser.avatar" 
                  :src="searchedUser.avatar" 
                  :alt="searchedUser.nombre" 
                  class="user-avatar"
                  @error="handleImageError"
                >
                <div v-else class="user-avatar-placeholder">
                  {{ searchedUser.nombre.charAt(0) }}
                </div>
              </div>
              <div class="user-text">
                <h4>{{ searchedUser.nombre }}</h4>
                <p>{{ searchedUser.email }}</p>
              </div>
            </div>

            <button 
              class="add-member-btn" 
              @click="addTeamMember"
              :disabled="!canAddMember"
            >
              Añadir al Equipo
            </button>
          </div>

          <div v-else-if="searchError" class="search-error">
            {{ searchError }}
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de Información del Proyecto -->
    <div v-if="showInfoModal" class="modal-overlay" @click.self="closeInfoModal">
      <div class="modal info-modal" ref="infoModal">
        <div class="modal-header">
          <h3>Información del Proyecto</h3>
          <button class="close-modal" @click="closeInfoModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="project-info">
            <div class="info-section">
              <h4>Detalles Generales</h4>
              <div class="info-group">
                <label>Nombre</label>
                <p>{{ projectInfo?.nombre }}</p>
              </div>
              <div class="info-group">
                <label>Descripción</label>
                <p>{{ projectInfo?.descripcion }}</p>
              </div>
              <div class="info-group">
                <label>Tipo</label>
                <p>{{ projectInfo?.tipo }}</p>
              </div>
            </div>

            <div class="info-section">
              <h4>Fechas</h4>
              <div class="info-group">
                <label>Fecha de Inicio</label>
                <p>{{ formatDate(projectInfo?.fecha_inicio) }}</p>
              </div>
              <div class="info-group">
                <label>Fecha Límite</label>
                <p>{{ formatDate(projectInfo?.fecha_limite) }}</p>
              </div>
            </div>

            <div class="info-section">
              <h4>Estado</h4>
              <div class="info-group">
                <label>Estado Actual</label>
                <p class="status-badge" :class="projectInfo?.estado">
                  {{ getStatusLabel(projectInfo?.estado) }}
                </p>
              </div>
            </div>

            <div class="info-section">
              <h4>Equipo</h4>
              <div class="team-members-list">
                <div v-for="role in ['Administrador', 'Líder', 'Miembro', 'Observador']" :key="role" class="role-group">
                  <h5>{{ role }}s</h5>
                  <div class="members-grid">
                    <div v-for="member in getMembersByRole(role)" :key="member.id_usuario" class="member-card">
                      <div class="member-avatar">
                        <img 
                          v-if="member.avatar" 
                          :src="member.avatar.startsWith('data:image') ? member.avatar : `data:image/jpeg;base64,${member.avatar}`" 
                          :alt="member.nombre"
                          @error="handleImageError"
                        >
                        <div v-else class="avatar-placeholder">
                          {{ member.nombre.charAt(0) }}
                        </div>
                      </div>
                      <div class="member-info">
                        <span class="member-name">{{ member.nombre }}</span>
                        <span class="member-function">{{ member.funcion }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AOS from 'aos';
import 'aos/dist/aos.css';
import api from '@/api';

export default {
  name: 'ProjectsView',
  data() {
    return {
      filters: {
        rol: '',
        search: ''
      },
      projects: [],
      loading: true,
      showEditModal: false,
      showDeleteModal: false,
      showMembersModal: false,
      editingProject: null,
      projectToDelete: null,
      memberSearch: '',
      searchedUser: null,
      selectedRole: null,
      memberFunction: '',
      searchError: null,
      selectedProject: null,
      error: null,
      errorFields: [],
      errorMessage: '',
      showInfoModal: false,
      projectInfo: null,
    }
  },
  computed: {
    filteredProjects() {
      return this.projects.filter(project => {
        if (this.filters.rol && project.rol_id !== parseInt(this.filters.rol)) return false;
        if (this.filters.search && !project.nombre.toLowerCase().includes(this.filters.search.toLowerCase())) return false;
        return true;
      });
    },
    canAddMember() {
      return this.searchedUser && 
             this.selectedRole && 
             this.memberFunction.trim();
    }
  },
  mounted() {
    this.loadProjects();
    this.$nextTick(() => {
      AOS.init({
        duration: 800,
        once: true,
        offset: 50,
        disable: 'mobile',
        disableMutationObserver: true
      });
      
      // Verificar si hay un proyecto seleccionado en localStorage
      const selectedProjectId = localStorage.getItem('selectedProjectId');
      if (selectedProjectId) {
        // Esperar a que los proyectos se carguen
        this.$watch('projects', (newProjects) => {
          if (newProjects.length > 0) {
            const project = newProjects.find(p => p.id_proyecto === parseInt(selectedProjectId));
            if (project) {
              this.selectProject(project);
              // Limpiar el localStorage después de seleccionar el proyecto
              localStorage.removeItem('selectedProjectId');
            }
          }
        }, { immediate: true });
      }
    });
  },
  watch: {
    selectedProject() {
      // Forzar una actualización de AOS cuando cambia el proyecto seleccionado
      this.$nextTick(() => {
        AOS.refresh();
      });
    },
    'editingProject.nombre'(newValue) {
      if (newValue && this.errorFields.includes('nombre')) {
        this.errorFields = this.errorFields.filter(field => field !== 'nombre');
      }
    },
    'editingProject.descripcion'(newValue) {
      if (newValue && this.errorFields.includes('descripcion')) {
        this.errorFields = this.errorFields.filter(field => field !== 'descripcion');
      }
    },
    'editingProject.tipo'(newValue) {
      if (newValue && this.errorFields.includes('tipo')) {
        this.errorFields = this.errorFields.filter(field => field !== 'tipo');
      }
    },
    'editingProject.fecha_limite'(newValue) {
      if (newValue && this.errorFields.includes('fecha_limite')) {
        this.errorFields = this.errorFields.filter(field => field !== 'fecha_limite');
      }
    }
  },
  beforeUnmount() {
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  },
  methods: {
    async loadProjects() {
      try {
        this.loading = true;
        const response = await api.getUserProjects();
        
        // Obtener la cantidad de miembros para cada proyecto
        const projectsWithMembers = await Promise.all(response.map(async (project) => {
          try {
            // Obtener el conteo de miembros usando el endpoint de conteo
            const membersCount = await api.getProjectMembersCount(project.id_proyecto);
            return {
              ...project,
              membersCount: membersCount.members_count || 0
            };
          } catch (error) {
            console.error(`Error al obtener miembros del proyecto ${project.id_proyecto}:`, error);
            return {
              ...project,
              membersCount: 0
            };
          }
        }));

        this.projects = projectsWithMembers;
        console.log('Proyectos cargados:', this.projects);
      } catch (error) {
        console.error('Error al cargar los proyectos:', error);
        this.error = error.response?.data?.detail || 'Error al cargar los proyectos';
      } finally {
        this.loading = false;
      }
    },
    formatDate(dateString) {
      if (!dateString) return 'Sin fecha límite';
      const date = new Date(dateString);
      return date.toLocaleDateString('es-ES', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    },
    formatDateForInput(dateString) {
      if (!dateString) return '';
      const date = new Date(dateString);
      return date.toISOString().split('T')[0];
    },
    openEditModal(project) {
      this.editingProject = { 
        ...project,
        miembros: project.miembros || [] // Asegurar que miembros esté inicializado
      };
      // Asegurarnos de que las fechas estén en el formato correcto
      if (this.editingProject.fecha_inicio) {
        this.editingProject.fecha_inicio = this.formatDateForInput(this.editingProject.fecha_inicio);
      }
      if (this.editingProject.fecha_limite) {
        this.editingProject.fecha_limite = this.formatDateForInput(this.editingProject.fecha_limite);
      }
      this.showEditModal = true;
      
      // Desplazar la página hacia la posición del modal
      this.$nextTick(() => {
        window.scrollTo({
          top: window.innerHeight / 2.7,
          behavior: 'smooth'
        });
      });
    },
    closeEditModal() {
      this.showEditModal = false;
      this.editingProject = null;
      this.errorFields = [];
      this.errorMessage = '';
    },
    openDeleteModal(project) {
      this.projectToDelete = project;
      this.showDeleteModal = true;
      
      // Desplazar la página hacia la posición del modal
      this.$nextTick(() => {
        // Asegurarse de que el desplazamiento ocurra después de que el modal esté visible
        setTimeout(() => {
          window.scrollTo({
            top: window.innerHeight / 1.3,
            behavior: 'smooth'
          });
        }, 50);
      });
    },
    closeDeleteModal() {
      this.showDeleteModal = false;
      this.projectToDelete = null;
    },
    async confirmDelete() {
      if (!this.projectToDelete) return;
      
      try {
        await api.deleteProject(this.projectToDelete.id_proyecto);
        this.closeDeleteModal();
        this.loadProjects();
      } catch (error) {
        console.error('Error al eliminar el proyecto:', error);
        this.error = error.response?.data?.detail || 'Error al eliminar el proyecto';
      }
    },
    openMemberModal() {
      this.showMembersModal = true;
      this.memberSearch = '';
      this.searchedUser = null;
      this.selectedRole = null;
      this.memberFunction = '';
      this.searchError = null;
      
      // Centrar el modal
      this.$nextTick(() => {
        if (this.$refs.memberModal) {
          this.$refs.memberModal.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    },
    closeMemberModal() {
      this.showMembersModal = false;
      this.memberSearch = '';
      this.searchedUser = null;
      this.selectedRole = null;
      this.memberFunction = '';
      this.searchError = null;
    },
    async searchUser() {
      if (!this.memberSearch) {
        this.searchError = 'Por favor, introduce un email';
        return;
      }

      // Validar formato de email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(this.memberSearch)) {
        this.searchError = 'Por favor, ingresa un correo electrónico válido';
        return;
      }

      try {
        this.searchError = null;
        this.searchedUser = null;
        
        // Añadir estado de carga
        const searchButton = document.querySelector('.search-btn');
        if (searchButton) {
          searchButton.disabled = true;
          searchButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';
        }
        
        const response = await api.searchUserByEmail(this.memberSearch);
        
        if (response && response.id_usuario) {
          // Verificar si el usuario ya es miembro del proyecto
          const existingMember = this.editingProject?.miembros?.find(
            m => m.id_usuario === response.id_usuario
          );
          
          if (existingMember) {
            this.searchError = 'Este usuario ya es miembro del proyecto';
            this.searchedUser = null;
          } else {
            this.searchedUser = {
              id_usuario: response.id_usuario,
              nombre: response.nombre,
              email: response.email,
              avatar: response.avatar ? `data:image/jpeg;base64,${response.avatar}` : null
            };
          }
        } else {
          this.searchError = 'Usuario no encontrado';
          this.searchedUser = null;
        }
      } catch (error) {
        console.error('Error al buscar usuario:', error);
        this.searchError = error.message || 'Error al buscar el usuario';
        this.searchedUser = null;
      } finally {
        // Restaurar el botón de búsqueda
        const searchButton = document.querySelector('.search-btn');
        if (searchButton) {
          searchButton.disabled = false;
          searchButton.innerHTML = '<i class="fas fa-search"></i> Buscar';
        }
      }
    },
    addTeamMember() {
      if (!this.canAddMember) return;

      const newMember = {
        id_usuario: this.searchedUser.id_usuario,
        nombre: this.searchedUser.nombre,
        email: this.searchedUser.email,
        avatar: this.searchedUser.avatar,
        rol_id: this.selectedRole,
        rol_nombre: this.getRoleName(this.selectedRole),
        funcion: this.memberFunction
      };

      // Verificar nuevamente que el usuario no esté ya en el proyecto
      if (!this.editingProject.miembros.find(m => m.id_usuario === newMember.id_usuario)) {
        this.editingProject.miembros.push(newMember);
      }

      this.closeMemberModal();
    },
    removeTeamMember(member) {
      this.editingProject.miembros = this.editingProject.miembros.filter(m => m.id_usuario !== member.id_usuario);
    },
    getRoleName(roleId) {
      const roles = {
        3: 'Líder',
        4: 'Miembro',
        5: 'Observador'
      };
      return roles[roleId] || '';
    },
    handleImageError(e) {
      e.target.style.display = 'none';
      const container = e.target.parentElement;
      const placeholder = document.createElement('div');
      placeholder.className = 'user-avatar-placeholder';
      placeholder.textContent = this.searchedUser.nombre.charAt(0);
      container.appendChild(placeholder);
    },
    selectProject(project) {
      // Si el proyecto ya está seleccionado, lo deseleccionamos
      if (this.selectedProject?.id_proyecto === project.id_proyecto) {
        this.selectedProject = null;
        localStorage.removeItem('selectedProject');
        this.$emit('project-selected', null);
        return;
      }
      
      // Seleccionar el nuevo proyecto
      this.selectedProject = project;
      // Guardar el proyecto seleccionado en localStorage
      localStorage.setItem('selectedProject', JSON.stringify(project));
      // Emitir evento para actualizar el nombre del proyecto en la barra de navegación
      this.$emit('project-selected', project);
    },
    editProject(project) {
      // Llamar al método openEditModal para mostrar el modal de edición
      this.openEditModal(project);
    },
    async deleteProject(project) {
      // Llamar al método openDeleteModal para mostrar el modal de eliminación
      this.openDeleteModal(project);
    },
    async updateProject() {
      try {
        this.errorMessage = '';
        this.errorFields = [];

        // Validar campos requeridos
        const requiredFields = ['nombre', 'descripcion', 'tipo'];
        const missingFields = requiredFields.filter(field => !this.editingProject[field]);
        
        if (missingFields.length > 0) {
          this.errorFields = missingFields;
          this.errorMessage = 'Por favor, completa todos los campos requeridos';
          return;
        }

        const projectData = {
          nombre: this.editingProject.nombre,
          descripcion: this.editingProject.descripcion,
          fecha_inicio: this.editingProject.fecha_inicio,
          fecha_limite: this.editingProject.fecha_limite,
          tipo: this.editingProject.tipo,
          estado: this.editingProject.estado
        };

        await api.updateProject(this.editingProject.id_proyecto, projectData);

        // Intentar obtener el proyecto original para comparar miembros
        try {
          const originalProject = await api.getProject(this.editingProject.id_proyecto);
          const originalMemberIds = originalProject.miembros
            .map(m => m.id_usuario);

          const newMembers = this.editingProject.miembros.filter(member => 
            !originalMemberIds.includes(member.id_usuario)
          );

          for (const member of newMembers) {
            await api.addUserToProject(this.editingProject.id_proyecto, {
              id_usuario: member.id_usuario,
              rol_id: member.rol_id,
              funcion: member.funcion
            });
          }
        } catch (memberError) {
          console.error('Error al actualizar miembros del proyecto:', memberError);
        }

        this.closeEditModal();
        this.loadProjects();
      } catch (error) {
        console.error('Error al actualizar el proyecto:', error);
        this.errorMessage = error.message || 'Error al actualizar el proyecto';
      }
    },
    hasFieldError(fieldName) {
      return this.errorFields.includes(fieldName);
    },
    async showProjectInfo(project) {
      try {
        // Obtener los miembros del proyecto
        const members = await api.getProjectMembers(project.id_proyecto);
        this.projectInfo = {
          ...project,
          miembros: members
        };
        this.showInfoModal = true;
        
        // Centrar el modal
        this.$nextTick(() => {
          window.scrollTo({
            top: window.innerHeight / 1.3,
            behavior: 'smooth'
          });
        });
      } catch (error) {
        console.error('Error al cargar los miembros del proyecto:', error);
        // Mostrar el modal con la información básica del proyecto
        this.projectInfo = project;
        this.showInfoModal = true;
        
        // Centrar el modal incluso si hay error
        this.$nextTick(() => {
          window.scrollTo({
            top: window.innerHeight / 1.3,
            behavior: 'smooth'
          });
        });
      }
    },
    closeInfoModal() {
      this.showInfoModal = false;
      this.projectInfo = null;
    },
    getStatusLabel(status) {
      const statusMap = {
        'planning': 'En Planificación',
        'active': 'Activo',
        'paused': 'En Pausa',
        'completed': 'Completado',
        'suspended': 'Suspendido'
      };
      return statusMap[status] || status;
    },
    getMembersByRole(role) {
      if (!this.projectInfo?.miembros) return [];
      const roleMap = {
        'Administrador': 2,
        'Líder': 3,
        'Miembro': 4,
        'Observador': 5
      };
      return this.projectInfo.miembros.filter(member => member.rol_id === roleMap[role]);
    },
    truncateDescription(description) {
      if (!description) return '';
      const maxLength = 100;
      if (description.length <= maxLength) return description;
      return description.substring(0, maxLength) + '...';
    },
  }
}
</script>

<style lang="scss" scoped>
@keyframes modalFadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.projects-view {
  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }

    .new-project-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: var(--primary);
      color: white;
      text-decoration: none;
      border-radius: var(--border-radius);
      transition: all 0.2s ease;

      &:hover {
        background: var(--primary-dark);
      }

      i {
        font-size: 1.1rem;
      }
    }
  }

  .projects-filters {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .filter-group {
      flex: 1;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      select {
        appearance: none;
        width: 100%;
        padding: 0.75rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: rgb(255, 255, 255);
        height: 45px;

        option {
        background-color: rgb(60, 68, 81);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }

    .search-group {
      flex: 2;
      position: relative;
      display: flex;
      flex-direction: column;

      label {
        display: block;
        margin-bottom: 0.5rem;
        color: white;
        font-weight: 500;
      }

      i {
        position: absolute;
        left: 1rem;
        top: calc(50% + 1rem);
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.7);
      }

      input {
        width: 100%;
        padding: 0.75rem 1rem 0.75rem 2.5rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
        background: rgba(255, 255, 255, 0.1);
        color: white;
        height: 45px;

        &::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }

        &:focus {
          outline: none;
          border-color: var(--primary);
        }
      }
    }
  }

  .projects-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
  }

  .project-card {
    background: rgba(255, 255, 255, 0.05);
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    height: 100%;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px solid transparent;

    &.selected {
      border-color: var(--primary);
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-5px);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);

      .project-header h3 {
        color: var(--primary);
      }

      .project-stats .stat i {
        color: var(--primary);
      }

      .project-progress .progress-fill {
        background: var(--primary);
      }
    }

    &:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .project-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;

      h3 {
        margin: 0;
        color: white;
        font-size: 1.1rem;
      }

      .project-actions {
        display: flex;
        gap: 0.5rem;

        .action-btn {
          padding: 0.5rem;
          border: none;
          border-radius: var(--border-radius);
          font-size: 0.9rem;
          cursor: pointer;
          transition: all 0.2s ease;

          &.edit-btn {
            background: rgba(255, 255, 255, 0.1);
            color: white;

            &:hover {
              background: rgba(255, 255, 255, 0.2);
            }
          }

          &.delete-btn {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;

            &:hover {
              background: rgba(244, 67, 54, 0.3);
            }
          }
        }
      }
    }

    .project-description {
      color: rgba(255, 255, 255, 0.8);
      font-size: 0.9rem;
      margin-bottom: 1rem;
      flex-grow: 1;
    }

    .project-stats {
      display: flex;
      gap: 1rem;
      margin-bottom: 1.5rem;

      .stat {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: rgba(255, 255, 255, 0.9);
        font-size: 0.9rem;

        i {
          color: var(--primary);
        }
      }
    }

    .project-progress {
      .progress-bar {
        height: 6px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 3px;
        overflow: hidden;
        margin-bottom: 0.5rem;

        .progress-fill {
          height: 100%;
          background: var(--primary);
          transition: width 0.3s ease;
        }
      }

      .progress-text {
        font-size: 0.8rem;
        color: rgba(255, 255, 255, 0.9);
      }
    }
  }

  .loading-spinner {
    text-align: center;
    padding: 2rem;
    color: white;
    font-size: 1.2rem;
  }

  .no-projects {
    text-align: center;
    padding: 3rem;
    color: white;
    
    p {
      margin-bottom: 1.5rem;
      font-size: 1.2rem;
    }
    
    .new-project-btn {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: var(--primary);
      color: white;
      text-decoration: none;
      border-radius: var(--border-radius);
      transition: all 0.2s ease;
      
      &:hover {
        background: var(--primary-dark);
      }
      
      i {
        font-size: 1.1rem;
      }
    }
  }

  .modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    backdrop-filter: blur(5px);
    overflow-y: auto;
    padding: 2rem 0;
  }

  .modal {
    background: rgba(30, 41, 59, 0.85);
    border-radius: 15px;
    width: 90%;
    max-width: 500px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    position: relative;
    margin: auto;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalFadeIn 0.3s ease;
  }

  .edit-modal {
    max-width: 700px;
    width: 95%;
    max-height: none;
    overflow-y: visible;
  }

  .modal-header {
    position: sticky;
    top: 0;
    background: rgba(30, 41, 59, 0.95);
    backdrop-filter: blur(10px);
    z-index: 10;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;

    h3 {
      color: white;
      margin: 0;
      font-size: 1.2rem;
    }

    .close-modal {
      background: none;
      border: none;
      color: rgba(255, 255, 255, 0.7);
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 50%;
      transition: all 0.2s ease;
      position: relative;
      z-index: 11;

      &:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }
    }
  }

  .modal-body {
      padding: 1.5rem;

      .role-selection {
        margin-bottom: 1.5rem;

        h4 {
          color: white;
          margin: 0 0 1rem;
          font-size: 1rem;
        }

        .role-options {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;

          .role-option {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            cursor: pointer;
            color: white;
            padding: 0.5rem;
            border-radius: var(--border-radius);
            transition: all 0.2s ease;
            background: rgba(255, 255, 255, 0.05);

            &:hover {
              background: rgba(255, 255, 255, 0.1);
            }

            input[type="radio"] {
              margin: 0;
              accent-color: var(--primary);
            }
          }
        }
      }

      .form-group {
        margin-bottom: 1.5rem;
        
        label {
          color: white;
          display: block;
          margin-bottom: 0.5rem;
        }

        input {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: var(--border-radius);
          background: rgba(255, 255, 255, 0.1);
          color: white;
          transition: all 0.2s ease;

          &:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.1);
          }

          &::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }
        }
      }

      .search-input-group {
        display: flex;
        gap: 0.5rem;

        input {
          flex: 1;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.5);
          color: white;
          transition: all 0.2s ease;

          &:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.1);
          }

          &::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }
        }

        .search-btn {
          white-space: nowrap;
          background: var(--primary);
          color: white;
          border: none;
          padding: 0.75rem 1rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover {
            background: var(--primary-dark);
          }
        }
      }

      .user-details {
        margin-top: 1.5rem;
        padding: 1rem;
        background: rgba(255, 255, 255, 0.05);
        border-radius: var(--border-radius);

        .user-info {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 1rem;

          .user-avatar-container {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            overflow: hidden;
            position: relative;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;

            .user-avatar {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }

            .user-avatar-placeholder {
              width: 100%;
              height: 100%;
              display: flex;
              justify-content: center;
              align-items: center;
              font-size: 1.5rem;
              font-weight: bold;
              color: white;
              background: var(--primary);
            }
          }

          .user-text {
            h4 {
              color: white;
              margin: 0;
            }

            p {
              color: rgba(255, 255, 255, 0.7);
              margin: 0.25rem 0 0;
            }
          }
        }

        .add-member-btn {
          width: 100%;
          padding: 0.75rem;
          background: var(--primary);
          color: white;
          border: none;
          border-radius: var(--border-radius);
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover:not(:disabled) {
            background: var(--primary-dark);
          }

          &:disabled {
            opacity: 0.5;
            cursor: not-allowed;
          }
        }
      }

      .search-error {
        color: #ef4444;
        margin-top: 1rem;
        text-align: center;
        padding: 0.5rem;
        background: rgba(239, 68, 68, 0.1);
        border-radius: var(--border-radius);
        font-size: 0.9rem;
      }

      .error-message {
        background-color: rgba(239, 68, 68, 0.2);
        color: #ef4444;
        border-left: 3px solid #ef4444;
        padding: 0.75rem 1rem;
        margin: 1rem 0;
        border-radius: var(--border-radius);
        font-size: 0.9rem;
      }

      .field-error {
        input, textarea, select {
          border-color: #ef4444 !important;
          background-color: rgba(239, 68, 68, 0.05) !important;
        }

        label {
          color: #ef4444 !important;
        }
      }
    }

  .form-section {
    margin-bottom: 2rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);

    &:last-child {
      border-bottom: none;
    }

    h4 {
      color: white;
      font-size: 1.2rem;
      margin: 0 0 1.5rem;
    }
  }

  .form-group {
    margin-bottom: 1.5rem;

    label {
      display: block;
      margin-bottom: 0.5rem;
      color: rgba(255, 255, 255, 0.9);
      font-weight: 500;
    }

    input, textarea{
      width: 100%;
      padding: 0.75rem;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      color: white;
      font-size: 0.95rem;
      transition: all 0.2s ease;

      &:focus {
        outline: none;
        border-color: var(--primary);
        background: rgba(255, 255, 255, 0.1);
      }

      &::placeholder {
        color: rgba(255, 255, 255, 0.5);
      }

      &:disabled {
        opacity: 0.7;
        cursor: not-allowed;
      }
    }

    select {
      appearance: none;
      width: 100%;
      padding: 0.75rem;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--border-radius);
      font-size: 1rem;
      background: rgba(255, 255, 255, 0.1);
      color: white;
      font-family: inherit;

      option{
        background: rgb(60, 68, 81);
      }

      &:focus {
        outline: none;
        border-color: var(--primary);
      }

      &::placeholder {
        color: rgba(255, 255, 255, 0.5);
        font-family: inherit;
      }
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    .form-text {
      display: block;
      margin-top: 0.5rem;
      font-size: 0.8rem;
      color: rgba(255, 255, 255, 0.6);
    }

    .team-members {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;

    .team-member {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem;
      background: rgba(255, 255, 255, 0.05);
      border-radius: var(--border-radius);

      .member-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        object-fit: cover;
      }

      .member-info {
        display: flex;
        flex-direction: column;

        .member-name {
          font-size: 0.9rem;
          color: white;
        }

        .member-role {
          font-size: 0.8rem;
          color: rgba(255, 255, 255, 0.7);
        }

        .member-function {
          font-size: 0.8rem;
          color: rgba(255, 255, 255, 0.7);
        }
      }

      .remove-member {
        background: none;
        border: none;
        color: rgba(255, 255, 255, 0.7);
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 50%;
        transition: all 0.2s ease;

        &:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ef4444;
        }
      }
    }

    .add-member-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      background: none;
      border: 1px dashed rgba(255, 255, 255, 0.2);
      border-radius: var(--border-radius);
      color: rgba(255, 255, 255, 0.7);
      cursor: pointer;
      transition: all 0.2s ease;

      &:hover {
        border-color: var(--primary);
        color: var(--primary);
      }
    }
  }
  }

  .form-row {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;

    .form-group {
      flex: 1;
      margin-bottom: 0;
    }
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    margin-top: 2rem;

    button {
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .cancel-btn {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: white;

      &:hover {
        background: rgba(255, 255, 255, 0.2);
      }
    }

    .save-btn {
      background: var(--primary);
      border: none;
      color: white;

      &:hover {
        background: var(--primary-dark);
      }

      &:disabled {
        opacity: 0.7;
        cursor: not-allowed;
      }
    }
  }

  .delete-modal {
    max-width: 500px;
  }

  .delete-confirmation {
    text-align: center;
    padding: 1rem 0;

    i {
      font-size: 3rem;
      color: #ef4444;
      margin-bottom: 1.5rem;
    }

    p {
      margin: 0 0 1rem;
      font-size: 1.1rem;
      color: white;
    }

    .warning-text {
      color: #ef4444;
      font-weight: 500;
    }
  }

  .delete-btn {
    background: #ef4444;
    border: none;
    color: white;

    &:hover {
      background: #dc2626;
    }
  }

  .action-btn {
    &.info-btn {
      background: rgba(255, 255, 255, 0.1);
      color: white;

      &:hover {
        background: rgba(255, 255, 255, 0.2);
      }
    }
  }

  .info-modal {
    max-width: 800px;
    width: 95%;
    max-height: 90vh;
    overflow-y: auto;

    &::-webkit-scrollbar {
      width: 8px;
    }

    &::-webkit-scrollbar-track {
      background: rgba(0, 0, 0, 0.1);
      border-radius: 4px;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 4px;

      &:hover {
        background: rgba(255, 255, 255, 0.3);
      }
    }

    .modal-body {
      padding: 1.5rem;
    }
  }

  .project-info {
    .info-section {
      margin-bottom: 2rem;
      padding-bottom: 1.5rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);

      &:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
      }

      h4 {
        color: white;
        font-size: 1.2rem;
        margin: 0 0 1.5rem;
      }

      .info-group {
        margin-bottom: 1rem;

        &:last-child {
          margin-bottom: 0;
        }

        label {
          display: block;
          color: rgba(255, 255, 255, 0.7);
          font-size: 0.9rem;
          margin-bottom: 0.5rem;
        }

        p {
          color: white;
          margin: 0;
          font-size: 1rem;
          line-height: 1.5;
        }
      }
    }

    .status-badge {
      display: inline-block;
      padding: 0.5rem 1rem;
      border-radius: var(--border-radius);
      font-size: 0.9rem;
      font-weight: 500;

      &.planning {
        background: rgba(59, 130, 246, 0.2);
        color: #3b82f6;
      }

      &.active {
        background: rgba(34, 197, 94, 0.2);
        color: #22c55e;
      }

      &.paused {
        background: rgba(234, 179, 8, 0.2);
        color: #eab308;
      }

      &.completed {
        background: rgba(168, 85, 247, 0.2);
        color: #a855f7;
      }

      &.suspended {
        background: rgba(239, 68, 68, 0.2);
        color: #ef4444;
      }
    }

    .team-members-list {
      .role-group {
        margin-bottom: 1.5rem;

        &:last-child {
          margin-bottom: 0;
        }

        h5 {
          color: rgba(255, 255, 255, 0.7);
          font-size: 1rem;
          margin: 0 0 1rem;
        }

        .members-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
          gap: 1rem;
        }

        .member-card {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.75rem;
          background: rgba(255, 255, 255, 0.05);
          border-radius: var(--border-radius);
          transition: all 0.2s ease;

          &:hover {
            background: rgba(255, 255, 255, 0.1);
          }

          .member-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
            background: rgba(255, 255, 255, 0.1);

            img {
              width: 100%;
              height: 100%;
              object-fit: cover;
            }

            .avatar-placeholder {
              width: 100%;
              height: 100%;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 1.2rem;
              font-weight: bold;
              color: white;
              background: var(--primary);
            }
          }

          .member-info {
            display: flex;
            flex-direction: column;

            .member-name {
              color: white;
              font-size: 0.9rem;
              font-weight: 500;
            }

            .member-function {
              color: rgba(255, 255, 255, 0.7);
              font-size: 0.8rem;
            }
          }
        }
      }
    }
  }
}
</style>