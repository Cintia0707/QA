<template>
  <div class="language-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Configuración de Idioma</h1>
    </div>

    <div class="view-content" data-aos="fade-up" data-aos-delay="100">
      <div class="language-container">
        <div class="language-section" data-aos="fade-up" data-aos-delay="200">
          <h2>Idioma de la Interfaz</h2>
          <p class="section-description">
            Selecciona el idioma en el que deseas ver la interfaz de WellTasker
          </p>

          <div class="language-list">
            <div 
              v-for="language in languages" 
              :key="language.code"
              class="language-item"
              :class="{ active: currentLanguage === language.code }"
              @click="selectLanguage(language.code)"
            >
              <div class="language-info">
                <img :src="language.flag" :alt="language.name" class="language-flag">
                <div class="language-details">
                  <h3>{{ language.name }}</h3>
                  <p>{{ language.nativeName }}</p>
                </div>
              </div>
              <div class="language-status">
                <i v-if="currentLanguage === language.code" class="fas fa-check"></i>
              </div>
            </div>
          </div>
        </div>

        <div class="language-section" data-aos="fade-up" data-aos-delay="300">
          <h2>Formato de Fecha y Hora</h2>
          <p class="section-description">
            Personaliza cómo se muestran las fechas y horas en la aplicación
          </p>

          <div class="format-settings">
            <div class="setting-group">
              <label for="dateFormat">Formato de fecha</label>
              <select id="dateFormat" v-model="dateFormat">
                <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                <option value="YYYY-MM-DD">YYYY-MM-DD</option>
              </select>
            </div>

            <div class="setting-group">
              <label for="timeFormat">Formato de hora</label>
              <select id="timeFormat" v-model="timeFormat">
                <option value="24h">24 horas</option>
                <option value="12h">12 horas</option>
              </select>
            </div>

            <div class="setting-group">
              <label for="timezone">Zona horaria</label>
              <select id="timezone" v-model="timezone">
                <option value="UTC">UTC</option>
                <option value="America/Mexico_City">Ciudad de México</option>
                <option value="America/New_York">Nueva York</option>
                <option value="Europe/Madrid">Madrid</option>
              </select>
            </div>
          </div>
        </div>

        <div class="language-section">
          <h2>Idioma de Contenido</h2>
          <p class="section-description">
            Configura el idioma predeterminado para el contenido que creas
          </p>

          <div class="content-language">
            <div class="setting-group">
              <label for="contentLanguage">Idioma predeterminado</label>
              <select id="contentLanguage" v-model="contentLanguage">
                <option value="es">Español</option>
                <option value="en">English</option>
                <option value="fr">Français</option>
                <option value="de">Deutsch</option>
              </select>
            </div>
          </div>
        </div>

        <div class="actions">
          <button class="cancel-btn" @click="$router.push('/workspace/settings')">
            Cancelar
          </button>
          <button class="save-btn" @click="saveSettings">
            Guardar Cambios
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LanguageView',
  data() {
    return {
      currentLanguage: 'es',
      dateFormat: 'DD/MM/YYYY',
      timeFormat: '24h',
      timezone: 'America/Mexico_City',
      contentLanguage: 'es',
      languages: [
        {
          code: 'es',
          name: 'Español',
          nativeName: 'Español',
          flag: 'https://via.placeholder.com/40'
        },
        {
          code: 'en',
          name: 'English',
          nativeName: 'English',
          flag: 'https://via.placeholder.com/40'
        },
        {
          code: 'fr',
          name: 'Français',
          nativeName: 'Français',
          flag: 'https://via.placeholder.com/40'
        },
        {
          code: 'de',
          name: 'Deutsch',
          nativeName: 'Deutsch',
          flag: 'https://via.placeholder.com/40'
        }
      ]
    }
  },
  methods: {
    selectLanguage(code) {
      this.currentLanguage = code
    },
    saveSettings() {
      // Implementar lógica de guardado
      console.log('Guardando configuración de idioma:', {
        language: this.currentLanguage,
        dateFormat: this.dateFormat,
        timeFormat: this.timeFormat,
        timezone: this.timezone,
        contentLanguage: this.contentLanguage
      })
      this.$router.push('/workspace/settings')
    }
  }
}
</script>

<style lang="scss" scoped>
.language-view {
  padding: 2rem;
  min-height: 100vh;

  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
      font-weight: 600;
    }
  }

  .language-container {
    background: rgba(255, 255, 255, 0.1);
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .language-section {
      margin-bottom: 2.5rem;
      animation: fadeIn 0.6s ease-out;

      h2 {
        color: white;
        font-size: 1.2rem;
        margin-bottom: 1rem;
        font-weight: 500;
      }

      .section-description {
        color: rgba(255, 255, 255, 0.7);
        margin-bottom: 1.5rem;
        font-size: 0.95rem;
        line-height: 1.5;
      }
    }

    .language-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 1rem;

      .language-item {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: var(--border-radius);
        padding: 1rem;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        justify-content: space-between;
        align-items: center;

        &:hover {
          background: rgba(255, 255, 255, 0.08);
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        &.active {
          background: rgba(var(--primary-rgb), 0.15);
          border-color: var(--primary);

          .language-status i {
            color: var(--primary);
          }
        }

        .language-info {
          display: flex;
          align-items: center;
          gap: 1rem;

          .language-flag {
            width: 36px;
            height: 36px;
            border-radius: var(--border-radius);
            object-fit: cover;
            border: 2px solid rgba(255, 255, 255, 0.1);
          }

          .language-details {
            h3 {
              color: white;
              margin: 0 0 0.25rem 0;
              font-size: 1rem;
              font-weight: 500;
            }

            p {
              color: rgba(255, 255, 255, 0.6);
              margin: 0;
              font-size: 0.9rem;
            }
          }
        }

        .language-status {
          i {
            font-size: 1.1rem;
            color: var(--primary);
          }
        }
      }
    }

    .format-settings, .content-language {
      .setting-group {
        margin-bottom: 1.5rem;
        max-width: 400px;

        label {
          display: block;
          color: white;
          margin-bottom: 0.5rem;
          font-weight: 500;
          font-size: 0.95rem;
        }

        select {
          appearance: none;
          width: 100%;
          padding: 0.75rem;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: var(--border-radius);
          font-size: 0.9rem;
          background: rgba(255, 255, 255, 0.1);
          color: white;
          height: 45px;
          
          option {
          background-color: rgb(60, 68, 81);
          }

          &:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(var(--primary-rgb), 0.25);
          }
        }
      }
    }

    .actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;
      padding-top: 1.5rem;
      border-top: 1px solid rgba(255, 255, 255, 0.1);

      button {
        padding: 0.75rem 1.5rem;
        border-radius: var(--border-radius);
        font-size: 0.95rem;
        font-weight: 500;
        transition: all 0.2s ease;
        cursor: pointer;

        &.cancel-btn {
          background: rgba(255, 255, 255, 0.1);
          color: white;
          border: 1px solid rgba(255, 255, 255, 0.1);

          &:hover {
            background: rgba(255, 255, 255, 0.15);
          }
        }

        &.save-btn {
          background: var(--primary);
          color: white;
          border: none;

          &:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
          }
        }
      }
    }
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(5px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>