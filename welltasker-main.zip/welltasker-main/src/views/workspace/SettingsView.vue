<template>
  <div class="settings-view">
    <div class="view-header" data-aos="fade-down">
      <h1>Configuración</h1>
    </div>

    <div class="settings-container" data-aos="fade-up" data-aos-delay="100">
      <!-- Perfil -->
      <div class="settings-section">
        <h2>Perfil</h2>
        <div class="profile-info">
          <div class="avatar-upload">
            <img :src="userProfile.avatar" alt="Avatar" class="avatar">
            <button class="change-avatar-btn">
              <i class="fas fa-camera"></i>
            </button>
          </div>
          <div class="profile-form">
            <div class="form-group">
              <label for="name">Nombre</label>
              <input type="text" id="name" v-model="userProfile.name">
            </div>
            <div class="form-group">
              <label for="email">Correo electrónico</label>
              <input type="email" id="email" v-model="userProfile.email">
            </div>
            <div class="form-group">
              <label for="bio">Biografía</label>
              <textarea id="bio" v-model="userProfile.bio" rows="3"></textarea>
            </div>
            <button class="save-btn">Guardar Cambios</button>
          </div>
        </div>
      </div>

      <!-- Notificaciones -->
      <div class="settings-section" data-aos="fade-up">
        <h2>Notificaciones</h2>
        <div class="notifications-settings">
          <div class="setting-item" data-aos="fade-right" data-aos-delay="100">
            <div class="setting-info">
              <h3>Notificaciones por correo</h3>
              <p>Recibir notificaciones importantes por correo electrónico</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="notifications.email">
              <span class="slider"></span>
            </label>
          </div>
          <div class="setting-item" data-aos="fade-right" data-aos-delay="200">
            <div class="setting-info">
              <h3>Notificaciones push</h3>
              <p>Recibir notificaciones en el navegador</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="notifications.push">
              <span class="slider"></span>
            </label>
          </div>
          <div class="setting-item" data-aos="fade-right" data-aos-delay="300">
            <div class="setting-info">
              <h3>Notificaciones de tareas</h3>
              <p>Recibir notificaciones sobre actualizaciones de tareas</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="notifications.tasks">
              <span class="slider"></span>
            </label>
          </div>
          <div class="setting-item" data-aos="fade-right" data-aos-delay="400">
            <div class="setting-info">
              <h3>Notificaciones de proyectos</h3>
              <p>Recibir notificaciones sobre actualizaciones de proyectos</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="notifications.projects">
              <span class="slider"></span>
            </label>
          </div>
        </div>
      </div>

      <!-- Preferencias -->
      <div class="settings-section" data-aos="fade-up">
        <h2>Preferencias</h2>
        <div class="preferences-settings">
          <div class="setting-item" data-aos="fade-right" data-aos-delay="100">
            <div class="setting-info">
              <h3>Tema oscuro</h3>
              <p>Activar el tema oscuro de la aplicación</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="preferences.darkMode">
              <span class="slider"></span>
            </label>
          </div>
          <div class="setting-item" data-aos="fade-right" data-aos-delay="200">
            <div class="setting-info">
              <h3>Vista compacta</h3>
              <p>Mostrar más contenido en la misma pantalla</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="preferences.compactView">
              <span class="slider"></span>
            </label>
          </div>
          <div class="setting-item" data-aos="fade-right" data-aos-delay="300">
            <div class="setting-info">
              <h3>Ordenar tareas por fecha</h3>
              <p>Mostrar las tareas ordenadas por fecha de vencimiento</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="preferences.sortByDate">
              <span class="slider"></span>
            </label>
          </div>
        </div>
      </div>

      <!-- Seguridad -->
      <div class="settings-section" data-aos="fade-up">
        <h2>Seguridad</h2>
        <div class="security-settings">
          <div class="setting-item" data-aos="fade-right" data-aos-delay="100">
            <div class="setting-info">
              <h3>Autenticación de dos factores</h3>
              <p>Añadir una capa extra de seguridad a tu cuenta</p>
            </div>
            <label class="switch">
              <input type="checkbox" v-model="security.twoFactor">
              <span class="slider"></span>
            </label>
          </div>
          <button class="change-password-btn" data-aos="fade-right" data-aos-delay="400">Cambiar Contraseña</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AOS from 'aos';
import 'aos/dist/aos.css';

export default {
  name: 'SettingsView',
  data() {
    return {
      userProfile: {
        name: 'Juan Pérez',
        email: 'juan.perez@example.com',
        bio: 'Desarrollador Full Stack',
        avatar: 'https://via.placeholder.com/150'
      },
      notifications: {
        email: true,
        push: true,
        tasks: true,
        projects: true
      },
      preferences: {
        darkMode: false,
        compactView: false,
        sortByDate: true
      },
      security: {
        twoFactor: false
      }
    }
  },
  mounted() {
    AOS.init({
      duration: 800,
      once: true,
      offset: 50,
      disable: 'mobile'
    });
  },
  beforeUnmount() {
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  }
}
</script>

<style lang="scss" scoped>
.settings-view {
  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;

    h1 {
      color: white;
      font-size: 1.8rem;
      margin: 0;
    }
  }

  .settings-container {
    background: rgba(255, 255, 255, 0.1);
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

    .settings-section {
      margin-bottom: 2rem;

      h2 {
        color: white;
        font-size: 1.2rem;
        margin-bottom: 1.5rem;
      }

      .profile-info {
        display: flex;
        gap: 2rem;

        .avatar-upload {
          position: relative;

          .avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255, 255, 255, 0.1);
          }

          .change-avatar-btn {
            position: absolute;
            bottom: 0;
            right: 0;
            background: var(--primary);
            color: white;
            border: none;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.2s ease;

            &:hover {
              background: var(--primary-dark);
            }
          }
        }

        .profile-form {
          flex: 1;

          .form-group {
            margin-bottom: 1.5rem;

            label {
              display: block;
              margin-bottom: 0.5rem;
              color: white;
              font-weight: 500;
            }

            input,
            textarea {
              width: 100%;
              padding: 0.75rem;
              border: 1px solid rgba(255, 255, 255, 0.1);
              border-radius: var(--border-radius);
              font-size: 1rem;
              background: rgba(255, 255, 255, 0.1);
              color: white;

              &:focus {
                outline: none;
                border-color: var(--primary);
              }

              &::placeholder {
                color: rgba(255, 255, 255, 0.5);
              }
            }
          }

          .save-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: all 0.2s ease;

            &:hover {
              background: var(--primary-dark);
            }
          }
        }
      }

      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);

        &:last-child {
          border-bottom: none;
        }

        .setting-info {
          h3 {
            margin: 0 0 0.25rem;
            color: white;
            font-size: 1rem;
          }

          p {
            margin: 0;
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
          }
        }
      }
    }
  }

  .switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 24px;

    input {
      opacity: 0;
      width: 0;
      height: 0;

      &:checked + .slider {
        background-color: var(--primary);
      }

      &:checked + .slider:before {
        transform: translateX(26px);
      }
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: .4s;
      border-radius: 24px;

      &:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
    }
  }

  .change-password-btn {
    background: none;
    border: 1px solid #ddd;
    color: var(--dark);
    padding: 0.75rem 1.5rem;
    border-radius: var(--border-radius);
    cursor: pointer;
    transition: all 0.2s ease;
    margin-top: 1rem;

    &:hover {
      background: #f5f5f5;
      border-color: var(--primary);
      color: var(--primary);
    }
  }
}
</style> 