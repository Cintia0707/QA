<template>
    <div class="home-view" ref="homeView">
      <!-- Barra de navegación -->
      <nav class="navbar">
        <div class="navbar-container">
          <div class="navbar-brand" data-aos="fade-right">
            <img src="@/assets/images/logo.png" alt="WellTasker" class="navbar-logo">
          </div>
          <div class="navbar-menu" data-aos="fade-left">
            <div v-if="selectedProject" class="selected-project">
              <i class="fas fa-project-diagram"></i>
              <span>{{ selectedProject.nombre }}</span>
            </div>
          </div>
          <div class="navbar-menu" data-aos="fade-left">
            <router-link to="/auth" class="nav-link">Iniciar Sesión</router-link>
            <router-link to="/auth?mode=register" class="nav-link">Registrarse</router-link>
          </div>
        </div>
      </nav>
  
      <!-- Hero Section -->
      <section class="hero">
        <div class="container">
          <h1 data-aos="fade-up">Transforma la gestión de tus proyectos</h1>
          <p class="subtitle" data-aos="fade-up" data-aos-delay="200">La plataforma que une equipos, optimiza procesos y maximiza resultados. Comienza a trabajar de manera más inteligente hoy.</p>
          <div class="cta-buttons" data-aos="fade-up" data-aos-delay="400">
            <AppButton @click="goToAuth">Comenzar Gratis</AppButton>
            <AppButton variant="outline" @click="scrollToFeatures">Conoce más</AppButton>
          </div>
        </div>
      </section>
  
      <!-- Features Section -->
      <section class="features" ref="features">
        <div class="container">
          <h2 data-aos="fade-up">Por qué elegir WellTasker</h2>
          <div class="features-grid">
            <AppFeatureCard 
              v-for="(feature, index) in features" 
              :key="index"
              :title="feature.title"
              :description="feature.description"
              :data-aos="'fade-up'"
              :data-aos-delay="index * 200"
            >
              <template #icon>
                <i :class="feature.icon"></i>
              </template>
            </AppFeatureCard>
          </div>
        </div>
      </section>

      <!-- Examples Section -->
      <section class="examples">
        <div class="container">
          <div class="example-item">
            <div class="example-content" data-aos="fade-right">
              <h2>Gestión de Proyectos</h2>
              <p>Organiza tus proyectos de manera eficiente con nuestra plataforma. Crea, asigna y supervisa el progreso de cada proyecto en tiempo real. Mantén a tu equipo alineado y enfocado en los objetivos.</p>
            </div>
            <div class="example-image" data-aos="fade-left">
              <img src="@/assets/images/ProjectsExample.png" alt="Ejemplo de gestión de proyectos">
            </div>
          </div>

          <div class="example-item reverse">
            <div class="example-content" data-aos="fade-left">
              <h2>Gestión de Tareas</h2>
              <p>Divide tus proyectos en tareas manejables. Asigna responsabilidades, establece fechas límite y realiza seguimiento del progreso. Mantén todo organizado y asegúrate de que nada se pierda.</p>
            </div>
            <div class="example-image" data-aos="fade-right">
              <img src="@/assets/images/TasksExample.png" alt="Ejemplo de gestión de tareas">
            </div>
          </div>

          <div class="example-item">
            <div class="example-content" data-aos="fade-right">
              <h2>Gestión de Archivos</h2>
              <p>Almacena y organiza todos tus archivos en un solo lugar. Comparte documentos, imágenes y recursos con tu equipo de manera segura y accesible. Mantén todo centralizado y fácil de encontrar.</p>
            </div>
            <div class="example-image" data-aos="fade-left">
              <img src="@/assets/images/FilesExample.png" alt="Ejemplo de gestión de archivos">
            </div>
          </div>
        </div>
      </section>

      <!-- Sección de Integraciones -->
      <section class="integrations-section">
        <div class="container">
          <h2 data-aos="fade-up">Integraciones</h2>
          <p class="section-subtitle" data-aos="fade-up" data-aos-delay="100">
            Conecta WellTasker con tus herramientas favoritas
          </p>

          <div class="integrations-container" data-aos="fade-up" data-aos-delay="200">
            <button class="carousel-btn prev" @click="prevSlide">
              <i class="fas fa-chevron-left"></i>
            </button>
            
            <div class="integrations-carousel" ref="carousel">
              <div class="carousel-container">
                <div class="integration-card">
                  <img src="@/assets/images/integrations/slack-logo.png" alt="Slack">
                  <h3>Slack</h3>
                  <p>Notificaciones y actualizaciones en tiempo real</p>
                  <button class="integration-btn">Conectar</button>
                </div>

                <div class="integration-card">
                  <img src="@/assets/images/integrations/google-drive-logo.png" alt="Google Drive">
                  <h3>Google Drive</h3>
                  <p>Acceso directo a documentos y archivos</p>
                  <button class="integration-btn">Conectar</button>
                </div>

                <div class="integration-card">
                  <img src="@/assets/images/integrations/github-logo.png" alt="GitHub">
                  <h3>GitHub</h3>
                  <p>Vincula tareas con commits y pull requests</p>
                  <button class="integration-btn">Conectar</button>
                </div>
              </div>

              <div class="carousel-container">
                <div class="integration-card">
                  <img src="@/assets/images/integrations/trello-logo.png" alt="Trello">
                  <h3>Trello</h3>
                  <p>Sincroniza tus tableros y tarjetas</p>
                  <button class="integration-btn">Conectar</button>
                </div>

                <div class="integration-card">
                  <img src="@/assets/images/integrations/zoom-logo.png" alt="Zoom">
                  <h3>Zoom</h3>
                  <p>Programa reuniones directamente</p>
                  <button class="integration-btn">Conectar</button>
                </div>

                <div class="integration-card">
                  <img src="@/assets/images/integrations/jira-logo.png" alt="Jira">
                  <h3>Jira</h3>
                  <p>Integra tickets y sprints</p>
                  <button class="integration-btn">Conectar</button>
                </div>
              </div>
            </div>

            <button class="carousel-btn next" @click="nextSlide">
              <i class="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </section>

      <!-- Footer Section -->
      <footer class="footer" data-aos="fade-up">
        <div class="container">
          <p>WellTasker &copy; {{ currentYear }} - Gestor colaborativo de proyectos</p>
        </div>
      </footer>
    </div>
  </template>
  
  <script>
  import AppButton from '@/components/ui/AppButton.vue';
  import AppFeatureCard from '@/components/ui/AppFeatureCard.vue';
  import AOS from 'aos';
  import 'aos/dist/aos.css';
  import api from '@/api';
  
  export default {
    name: 'HomeView',
    components: {
      AppButton,
      AppFeatureCard
    },
    data() {
      return {
        currentYear: new Date().getFullYear(),
        currentSlide: 0,
        totalSlides: 1, // Total de contenedores - 1
        userProfile: null,
        selectedProject: null,
        features: [
          {
            title: 'Colaboración en tiempo real',
            description: 'Trabaja simultáneamente con tu equipo en proyectos compartidos',
            icon: 'fas fa-users'
          },
          {
            title: 'Gestión de tareas',
            description: 'Organiza y prioriza tus tareas de manera eficiente',
            icon: 'fas fa-tasks'
          },
          {
            title: 'Integraciones',
            description: 'Conecta con tus herramientas favoritas',
            icon: 'fas fa-plug'
          }
        ]
      }
    },
    mounted() {
      this.loadUserProfile();
      window.addEventListener('scroll', this.handleScroll);
      AOS.init({
        duration: 1000,
        once: true,
        offset: 100,
        disable: 'mobile'
      });
    },
    beforeUnmount() {
      window.removeEventListener('scroll', this.handleScroll);
      if (document) {
        const elements = document.querySelectorAll('[data-aos]');
        elements.forEach(el => {
          if (el) {
            el.removeAttribute('data-aos');
            el.removeAttribute('data-aos-delay');
            el.removeAttribute('data-aos-duration');
          }
        });
      }
    },
    methods: {
      goToAuth(mode) {
        this.$nextTick(() => {
          this.$router.push({ path: '/auth', query: { mode } });
        });
      },
      scrollToFeatures() {
        if (this.$refs.features) {
          this.$refs.features.scrollIntoView({ behavior: 'smooth' });
        }
      },
      handleScroll() {
        if (this.$refs.homeView) {
          const scrolled = window.pageYOffset;
          this.$refs.homeView.style.backgroundPosition = `center ${scrolled * 0.5}px`;
        }
      },
      nextSlide() {
        if (this.currentSlide < this.totalSlides) {
          this.currentSlide++;
          this.$refs.carousel.style.transform = `translateX(-${this.currentSlide * 50}%)`;
        }
      },
      prevSlide() {
        if (this.currentSlide > 0) {
          this.currentSlide--;
          this.$refs.carousel.style.transform = `translateX(-${this.currentSlide * 50}%)`;
        }
      },
      async loadUserProfile() {
        try {
          const response = await api.getUserProfile();
          this.userProfile = response.data;
        } catch (error) {
          console.error('Error al cargar el perfil del usuario:', error);
        }
      },
      handleAvatarError(e) {
        e.target.style.display = 'none';
        const container = e.target.parentElement;
        const placeholder = document.createElement('div');
        placeholder.className = 'avatar-placeholder';
        placeholder.textContent = this.userProfile.nombre.charAt(0);
        container.appendChild(placeholder);
      },
      handleProjectSelected(project) {
        this.selectedProject = project;
      }
    }
  }
  </script>
  
  <style lang="scss" scoped>
  @import '/src/styles/views/_home.scss';

  .navbar {
    background: rgba(0, 0, 0, 0.50);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;

    .navbar-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0.25rem 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .navbar-brand {
      .navbar-logo {
        height: 60px;
        width: auto;
        margin: -10px 0;
      }
    }

    .navbar-menu {
      display: flex;
      gap: 1.5rem;
      align-items: center;

      .selected-project {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        color: white;
        font-weight: 500;

        i {
          color: var(--primary);
        }
      }

      .nav-link {
        color: white;
        text-decoration: none;
        font-weight: 500;
        transition: color 0.2s ease;

        &:hover {
          color: var(--primary);
        }

        &.router-link-active {
          color: var(--primary);
        }
      }
    }
  }

  .hero {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 6rem 2rem;
    color: white;

    .container {
      max-width: 800px;
      margin: 0 auto;
    }

    h1 {
      font-size: 3.5rem;
      font-weight: 700;
      margin-bottom: 1.5rem;
      line-height: 1.2;
    }

    .subtitle {
      font-size: 1.25rem;
      margin-bottom: 2.5rem;
      line-height: 1.6;
      color: rgba(255, 255, 255, 0.9);
    }

    .cta-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
      align-items: center;
    }
  }

  .examples {
    padding: 6rem 2rem;
    background: rgba(0, 0, 0, 0.3);

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .example-item {
      display: flex;
      align-items: center;
      gap: 4rem;
      margin-bottom: 6rem;
      color: white;

      &:last-child {
        margin-bottom: 0;
      }

      &.reverse {
        flex-direction: row-reverse;
      }

      .example-content {
        flex: 1;

        h2 {
          font-size: 2.5rem;
          margin-bottom: 1.5rem;
          color: var(--primary);
        }

        p {
          font-size: 1.1rem;
          line-height: 1.6;
          color: rgba(255, 255, 255, 0.9);
        }
      }

      .example-image {
        flex: 1;
        position: relative;
        padding: 1rem;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);

        &::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          border: 2px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;
          pointer-events: none;
        }

        &::after {
          content: '';
          position: absolute;
          top: 8px;
          left: 8px;
          right: 8px;
          bottom: 8px;
          border: 1px solid rgba(255, 255, 255, 0.05);
          border-radius: 8px;
          pointer-events: none;
        }

        img {
          width: 100%;
          height: auto;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          transition: transform 0.3s ease;

          &:hover {
            transform: scale(1.02);
          }
        }
      }
    }
  }

  @media (max-width: 768px) {
    .examples {
      .example-item {
        flex-direction: column;
        gap: 2rem;

        &.reverse {
          flex-direction: column;
        }
      }
    }
  }

  .integrations-section {
    padding: 6rem 0;
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.8) 0%, rgba(0, 0, 0, 0.6) 100%);
    backdrop-filter: blur(10px);

    h2 {
      text-align: center;
      color: white;
      font-size: 2.5rem;
      margin-bottom: 1rem;
    }

    .section-subtitle {
      text-align: center;
      color: rgba(255, 255, 255, 0.8);
      font-size: 1.2rem;
      margin-bottom: 3rem;
    }

    .integrations-container {
      position: relative;
      width: 100%;
      overflow: hidden;
      padding: 0 4rem;
    }

    .integrations-carousel {
      display: flex;
      transition: transform 0.5s ease;
      width: 200%;
      position: relative;
      transform: translateX(0);
    }

    .carousel-container {
      width: 50%;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 2rem;
      padding: 1rem;
      box-sizing: border-box;
      flex-shrink: 0;
    }

    .carousel-btn {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      z-index: 2;

      &:hover {
        background: rgba(255, 255, 255, 0.2);
        border-color: var(--primary);
      }

      &.prev {
        left: 0;
      }

      &.next {
        right: 0;
      }

      i {
        font-size: 1.2rem;
      }
    }

    .integration-card {
      width: 100%;
      background: rgba(255, 255, 255, 0.05);
      border-radius: var(--border-radius);
      padding: 2rem;
      text-align: center;
      transition: transform 0.3s ease;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-sizing: border-box;

      &:hover {
        transform: translateY(-5px);
        background: rgba(255, 255, 255, 0.1);
      }

      img {
        width: 80px;
        height: 80px;
        margin-bottom: 1.5rem;
        object-fit: contain;
        background: rgba(255, 255, 255, 0.1);
        padding: 1rem;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;

        &:hover {
          transform: scale(1.05);
          background: rgba(255, 255, 255, 0.15);
          border-color: var(--primary);
        }
      }

      h3 {
        color: white;
        font-size: 1.2rem;
        margin-bottom: 0.5rem;
      }

      p {
        color: rgba(255, 255, 255, 0.8);
        font-size: 0.9rem;
        margin-bottom: 1.5rem;
      }

      .integration-btn {
        background: var(--primary);
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: var(--border-radius);
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: 500;

        &:hover {
          background: var(--primary-dark);
          transform: translateY(-2px);
        }
      }
    }
  }

  @media (max-width: 1024px) {
    .integrations-section {
      .carousel-container {
        grid-template-columns: repeat(2, 1fr);
      }
    }
  }

  @media (max-width: 768px) {
    .integrations-section {
      .carousel-container {
        grid-template-columns: 1fr;
      }
    }
  }

  .nav-right {
    display: flex;
    align-items: center;
    gap: 2rem;
  }

  .selected-project {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1rem;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    color: white;
    font-weight: 500;

    i {
      color: var(--primary);
    }
  }
  </style>