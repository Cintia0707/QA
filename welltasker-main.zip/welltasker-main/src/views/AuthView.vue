<template>
  <div class="auth-view" ref="authView">
    <div class="auth-header">
      <img src="@/assets/images/logo.png" alt="WellTasker" class="auth-logo" data-aos="fade-right">
      <button class="back-button" @click="goBack" data-aos="fade-left">
        <i class="fas fa-chevron-left"></i>
      </button>
    </div>

    <AuthForm 
      :initial-mode="$route.query.mode || 'login'"
      @auth-success="handleAuthSuccess"
      data-aos="fade-up"
      data-aos-delay="200"
    />

    <footer class="footer" data-aos="fade-up">
      <div class="container">
        <p>WellTasker &copy; {{ currentYear }} - Gestor colaborativo de proyectos</p>
      </div>
    </footer>
  </div>
</template>

<script>
import AuthForm from '@/components/auth/AuthForm.vue'
import AOS from 'aos';
import 'aos/dist/aos.css';

export default {
  name: 'AuthView',
  components: { AuthForm },
  data() {
    return {
      currentYear: new Date().getFullYear()
    }
  },
  computed: {
    initialMode() {
      // Obtener el modo de los query params
      return this.$route.query.mode || 'login'
    }
  },
  mounted() {
    window.addEventListener('scroll', this.handleScroll);
    AOS.init({
      duration: 1000,
      once: true,
      offset: 100,
      disable: 'mobile'
    });
  },
  beforeUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  },
  methods: {
    handleAuthSuccess() {
      // Redirigir siempre a LimboView después de un inicio de sesión/registro exitoso
      this.$router.push({ name: 'Limbo' }); 
    },
    handleScroll() {
      if (this.$refs.authView) {
        const scrolled = window.pageYOffset;
        this.$refs.authView.style.backgroundPosition = `center ${scrolled * 0.5}px`;
      }
    },
    goBack() {
      this.$router.push('/');
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/auth/_form';

.auth-view {
  background-image: url('@/assets/images/AuthBackground.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  position: relative;
  overflow-x: hidden;
  overflow-y: hidden;
  padding: 2rem;
  padding-bottom: 0;
  min-height: 100vh;
  display: flex;
  flex-direction: column;

  &::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.7) 0%, rgba(0, 0, 0, 0.5) 100%);
    z-index: 1;
    pointer-events: none;
  }

  .auth-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    position: relative;
    z-index: 2;
    flex-shrink: 0;

    .auth-logo {
      height: 100px;
      width: auto;
    }

    .back-button {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s ease;
      backdrop-filter: blur(5px);

      i {
        font-size: 1.5rem;
        color: white;
        opacity: 0.9;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
      }

      &:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: translateX(-3px);

        i {
          opacity: 1;
        }
      }
    }
  }

  .footer {
    position: relative;
    padding: 2rem 0;
    background: rgba(0, 0, 0, 0.50);
    z-index: 2;
    margin-top: 4rem;
    margin-left: -2rem;
    margin-right: -2rem;
    flex-shrink: 0;
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 var(--space-md);
      text-align: center;
      color: white;
    }
  }
}

.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter, .fade-leave-to {
  opacity: 0;
}
</style>