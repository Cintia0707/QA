<template>
  <div class="limbo-view">
    <div class="limbo-header">
      <img src="@/assets/images/logo.png" alt="WellTasker" class="limbo-logo" data-aos="fade-right">
      
      <!-- Nuevo componente de perfil de usuario -->
      <div class="user-profile" data-aos="fade-down">
        <div class="profile-container">
          <div class="avatar-container">
            <img 
              v-if="userProfile?.avatar" 
              :src="`data:image/jpeg;base64,${userProfile.avatar}`" 
              :alt="userProfile?.nombre" 
              class="user-avatar"
              @error="handleAvatarError"
            >
            <div v-else class="avatar-placeholder">
              <i class="fas fa-user"></i>
            </div>
          </div>
          <span class="user-name">{{ userProfile?.nombre || 'Usuario' }}</span>
        </div>
      </div>
      
      <button class="back-button" @click="goBack" data-aos="fade-left">
        <i class="fas fa-chevron-left"></i>
      </button>
    </div>
    <div class="limbo-container">
      <div class="title-carousel" data-aos="fade-down">
        <button class="carousel-btn prev" @click="prevTitle">
          <i class="fas fa-chevron-left"></i>
        </button>
        <h1 class="title">{{ titles[currentTitleIndex] }}</h1>
        <button class="carousel-btn next" @click="nextTitle">
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div v-if="loading" class="loading-spinner" data-aos="fade-up">Cargando...</div>
      <div v-else-if="filteredProjects.length > 0" class="projects-grid">
        <div 
          v-for="(project, index) in filteredProjects" 
          :key="project.id_proyecto" 
          class="project-card"
          :data-aos="index % 2 === 0 ? 'fade-up-right' : 'fade-up-left'"
          :data-aos-delay="100 + (index * 100)"
          data-aos-duration="800"
          data-aos-once="false"
        >
          <h2>{{ project.nombre }}</h2>
          <p>{{ project.descripcion }}</p>
          <button @click="goToProject(project.id_proyecto)">Abrir Proyecto</button>
        </div>
      </div>
      <div v-else class="no-projects" data-aos="fade-up">
        <p>No hay proyectos en esta categoría.</p>
      </div>
    </div>
    <button @click="showCreateProjectModal = true" class="create-project-btn">Crear un Nuevo Proyecto</button>

    <!-- Modal de Creación de Proyecto -->
    <div v-if="showCreateProjectModal" class="modal-overlay" @click.self="closeCreateProjectModal">
      <div class="modal" ref="createProjectModal">
        <div class="modal-header">
          <h3>Nuevo Proyecto</h3>
          <button class="close-modal" @click="closeCreateProjectModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <!-- Mensaje de error general -->
          <div v-if="errorMessage" class="error-message">
            {{ errorMessage }}
          </div>
          
          <div class="form-section">
            <h4>Información Básica</h4>
            <div class="form-group" :class="{ 'field-error': hasFieldError('nombre') }">
              <label for="projectName">Nombre del Proyecto</label>
              <input 
                type="text" 
                id="projectName" 
                v-model="newProject.nombre"
                placeholder="Ej: Sitio Web Corporativo"
                autocomplete="off"
              >
            </div>

            <div class="form-group" :class="{ 'field-error': hasFieldError('descripcion') }">
              <label for="projectDescription">Descripción</label>
              <textarea 
                id="projectDescription" 
                v-model="newProject.descripcion"
                rows="4"
                placeholder="Describe el propósito y objetivos del proyecto"
                autocomplete="off"
              ></textarea>
            </div>

            <div class="form-row">
              <div class="form-group" :class="{ 'field-error': hasFieldError('fecha_inicio') }">
                <label for="startDate">Fecha de Inicio</label>
                <input 
                  type="date" 
                  id="startDate" 
                  v-model="newProject.fecha_inicio"
                >
              </div>

              <div class="form-group" :class="{ 'field-error': hasFieldError('fecha_limite') }">
                <label for="endDate">Fecha de Fin</label>
                <input 
                  type="date" 
                  id="endDate" 
                  v-model="newProject.fecha_limite"
                >
              </div>
            </div>
          </div>

          <div class="form-section">
            <h4>Configuración</h4>
            <div class="form-group" :class="{ 'field-error': hasFieldError('tipo') }">
              <label for="projectType">Tipo de Proyecto</label>
              <input 
                type="text" 
                id="projectType" 
                v-model="newProject.tipo"
                placeholder="Ej: Desarrollo Web, Marketing, etc."
                autocomplete="off"
              >
            </div>

            <div class="form-group" :class="{ 'field-error': hasFieldError('estado') }">
              <label for="projectStatus">Estado Inicial</label>
              <select id="projectStatus" v-model="newProject.estado">
                <option value="planning">En Planificación</option>
                <option value="active">Activo</option>
              </select>
            </div>
          </div>

          <div class="form-section">
            <h4>Equipo</h4>
            <div class="form-group">
              <label>Miembros del Equipo</label>
              <div class="team-members">
                <div 
                  v-for="member in newProject.miembros" 
                  :key="member.id_usuario"
                  class="team-member"
                >
                  <img :src="member.avatar || 'https://via.placeholder.com/40'" :alt="member.nombre" class="member-avatar">
                  <div class="member-info">
                    <span class="member-name">{{ member.nombre }}</span>
                    <span class="member-role">{{ member.rol_nombre }}</span>
                    <span class="member-function">{{ member.funcion }}</span>
                  </div>
                  <button class="remove-member" @click="removeTeamMember(member)">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <button class="add-member-btn" @click="showMembersModal = true; centerModal()">
                  <i class="fas fa-plus"></i>
                  Añadir Miembro
                </button>
              </div>
            </div>
          </div>

          <div class="form-actions">
            <button class="cancel-btn" @click="closeCreateProjectModal">
              Cancelar
            </button>
            <button class="create-btn" @click="createProject" :disabled="isSubmitting || !isFormValid">
              {{ isSubmitting ? 'Creando proyecto...' : 'Crear Proyecto' }}
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para añadir miembros -->
    <div v-if="showMembersModal" class="modal-overlay" @click.self="closeMemberModal">
      <div class="modal" ref="memberModal">
        <div class="modal-header">
          <h3>Añadir Miembro al Equipo</h3>
          <button class="close-modal" @click="closeMemberModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="role-selection">
            <h4>Seleccionar Rol</h4>
            <div class="role-options">
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="3"
                >
                <span>Líder</span>
              </label>
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="4"
                >
                <span>Miembro</span>
              </label>
              <label class="role-option">
                <input 
                  type="radio" 
                  v-model="selectedRole" 
                  :value="5"
                >
                <span>Observador</span>
              </label>
            </div>
          </div>

          <div class="form-group">
            <label for="memberFunction">Función en el Proyecto</label>
            <input 
              type="text" 
              id="memberFunction" 
              v-model="memberFunction"
              placeholder="Ej: Desarrollador, Diseñador, etc."
              autocomplete="off"
            >
          </div>

          <div class="form-group">
            <label for="memberEmail">Email del Usuario</label>
            <div class="search-input-group">
              <input 
                type="email" 
                id="memberEmail" 
                v-model="memberSearch"
                placeholder="ejemplo@correo.com"
                @keyup.enter="searchUser"
              >
              <button class="search-btn" @click="searchUser">
                <i class="fas fa-search"></i>
                Buscar
              </button>
            </div>
          </div>

          <div v-if="searchedUser" class="user-details">
            <div class="user-info">
              <div class="user-avatar-container">
                <img 
                  v-if="searchedUser.avatar" 
                  :src="searchedUser.avatar" 
                  :alt="searchedUser.nombre" 
                  class="user-avatar"
                  @error="handleImageError"
                >
                <div v-else class="user-avatar-placeholder">
                  {{ searchedUser.nombre.charAt(0) }}
                </div>
              </div>
              <div class="user-text">
                <h4>{{ searchedUser.nombre }}</h4>
                <p>{{ searchedUser.email }}</p>
              </div>
            </div>

            <button 
              class="add-member-btn" 
              @click="addTeamMember"
              :disabled="!canAddMember"
            >
              Añadir al Equipo
            </button>
          </div>

          <div v-else-if="searchError" class="search-error">
            {{ searchError }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed } from 'vue';
import { useRouter } from 'vue-router';
import api from '@/api';
import AOS from 'aos';
import 'aos/dist/aos.css';

const router = useRouter();
const allProjects = ref([]); // Almacenar todos los proyectos
const loading = ref(true);
const currentTitleIndex = ref(0);
const showCreateProjectModal = ref(false);
const showMembersModal = ref(false);
const memberSearch = ref('');
const searchedUser = ref(null);
const selectedRole = ref(null);
const memberFunction = ref('');
const searchError = ref(null);
const userProfile = ref(null); // Nueva referencia para el perfil del usuario
const errorMessage = ref('');
const errorFields = ref([]);
const isSubmitting = ref(false);

const titles = [
  'Tus Proyectos',
  'Líder',
  'Miembro',
  'Observador'
];

const roleIds = {
  'Tus Proyectos': 2, // Administrador de Proyecto
  'Líder': 3,        // Líder de Proyecto
  'Miembro': 4,      // Miembro del equipo
  'Observador': 5    // Observador
};

// Filtrar proyectos según el rol actual
const filteredProjects = computed(() => {
  const currentRole = roleIds[titles[currentTitleIndex.value]];
  return allProjects.value.filter(project => project.rol_id === currentRole);
});

// Función para cargar todos los proyectos
const loadAllProjects = async () => {
  try {
    loading.value = true;
    const response = await api.getUserProjects();
    allProjects.value = response; // La respuesta ya está en el formato correcto
    console.log('Todos los proyectos cargados:', allProjects.value);
  } catch (error) {
    console.error('Error al cargar los proyectos:', error);
  } finally {
    loading.value = false;
  }
};

const handleScroll = () => {
};

onMounted(() => {
  window.addEventListener('scroll', handleScroll);
  AOS.init({
    duration: 1000,
    once: true,
    offset: 100,
    disable: 'mobile'
  });
});

onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll);
  if (document) {
    const elements = document.querySelectorAll('[data-aos]');
    elements.forEach(el => {
      if (el) {
        el.removeAttribute('data-aos');
        el.removeAttribute('data-aos-delay');
        el.removeAttribute('data-aos-duration');
      }
    });
  }
});

const goBack = () => {
  router.push('/auth');
};

onMounted(async () => {
  try {
    // Cargar el perfil del usuario
    await loadUserProfile();
    
    // Cargar todos los proyectos al inicio
    await loadAllProjects();
    
    // Inicializar AOS
    AOS.init({
      duration: 800,
      once: false,
      offset: 50,
      disable: 'mobile'
    });
  } catch (error) {
    console.error('Error al cargar los datos:', error);
    if (error.response && (error.response.status === 401 || error.response.status === 403)) {
      console.warn('Token inválido o expirado. Redirigiendo a login.');
      localStorage.removeItem('token');
      router.push({ name: 'auth', query: { sessionExpired: 'true' } });
    }
  }
});

const goToProject = (projectId) => {
  // Navegar a la vista del proyecto específico (WorkspaceView?)
  // IMPORTANTE: WorkspaceView necesita saber qué proyecto mostrar.
  // Opción 1 (Temporal): Guardar ID en localStorage y leerlo en WorkspaceView
  console.log(`Guardando selectedProjectId: ${projectId}`);
  localStorage.setItem('selectedProjectId', projectId);
  router.push('/workspace'); // Navegar a la ruta base del workspace
  // Opción 2 (Mejor): Usar state management (Pinia/Vuex) para setear el proyecto activo.
  // Opción 3: Modificar la ruta '/workspace' a '/workspace/:projectId' y ajustar WorkspaceView.
};

const newProject = ref({
  nombre: '',
  descripcion: '',
  fecha_inicio: '',
  fecha_limite: '',
  tipo: '',
  estado: 'planning',
  miembros: []
});

const isFormValid = computed(() => {
  return newProject.value.nombre && 
         newProject.value.descripcion && 
         newProject.value.fecha_inicio && 
         newProject.value.fecha_limite && 
         newProject.value.tipo && 
         newProject.value.estado;
});

const canAddMember = computed(() => {
  return searchedUser.value && 
         selectedRole.value && 
         memberFunction.value.trim();
});

const closeCreateProjectModal = () => {
  showCreateProjectModal.value = false;
  newProject.value = {
    nombre: '',
    descripcion: '',
    fecha_inicio: '',
    fecha_limite: '',
    tipo: '',
    estado: 'planning',
    miembros: []
  };
};

const closeMemberModal = () => {
  showMembersModal.value = false;
  memberSearch.value = '';
  searchedUser.value = null;
  selectedRole.value = null;
  memberFunction.value = '';
  searchError.value = null;
};

const centerModal = () => {
  setTimeout(() => {
    if (document.querySelector('.modal')) {
      document.querySelector('.modal').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, 100);
};

const searchUser = async () => {
  if (!memberSearch.value) {
    searchError.value = 'Por favor, introduce un email';
    return;
  }

  try {
    searchError.value = null;
    const response = await api.searchUserByEmail(memberSearch.value);
    
    if (response.data) {
      let avatarUrl = null;
      if (response.data.avatar) {
        try {
          avatarUrl = `data:image/jpeg;base64,${response.data.avatar}`;
        } catch (e) {
          console.error('Error al procesar el avatar:', e);
          avatarUrl = null;
        }
      }
      
      searchedUser.value = {
        id_usuario: response.data.id_usuario,
        nombre: response.data.nombre,
        email: response.data.email,
        avatar: avatarUrl
      };
    } else {
      searchError.value = 'Usuario no encontrado';
      searchedUser.value = null;
    }
  } catch (error) {
    console.error('Error al buscar usuario:', error);
    searchError.value = error.response?.data?.error || 'Error al buscar el usuario';
    searchedUser.value = null;
  }
};

const addTeamMember = () => {
  if (!canAddMember.value) return;

  const newMember = {
    id_usuario: searchedUser.value.id_usuario,
    nombre: searchedUser.value.nombre,
    email: searchedUser.value.email,
    avatar: searchedUser.value.avatar,
    rol_id: selectedRole.value,
    rol_nombre: getRoleName(selectedRole.value),
    funcion: memberFunction.value
  };

  if (!newProject.value.miembros.find(m => m.id_usuario === newMember.id_usuario)) {
    newProject.value.miembros.push(newMember);
  }

  closeMemberModal();
};

const removeTeamMember = (member) => {
  newProject.value.miembros = newProject.value.miembros.filter(m => m.id_usuario !== member.id_usuario);
};

const getRoleName = (roleId) => {
  const roles = {
    3: 'Líder',
    4: 'Miembro',
    5: 'Observador'
  };
  return roles[roleId] || '';
};

const handleImageError = (e) => {
  e.target.style.display = 'none';
  const container = e.target.parentElement;
  const placeholder = document.createElement('div');
  placeholder.className = 'user-avatar-placeholder';
  placeholder.textContent = searchedUser.value.nombre.charAt(0);
  container.appendChild(placeholder);
};

const createProject = async () => {
  try {
    // Limpiar errores previos
    clearErrors();
    isSubmitting.value = true;

    // Validar campos requeridos
    if (!newProject.value.nombre) {
      setFieldError('nombre', 'El nombre del proyecto es requerido');
      return;
    }

    if (!newProject.value.descripcion) {
      setFieldError('descripcion', 'La descripción del proyecto es requerida');
      return;
    }

    if (!newProject.value.fecha_inicio) {
      setFieldError('fecha_inicio', 'La fecha de inicio es requerida');
      return;
    }

    if (!newProject.value.fecha_limite) {
      setFieldError('fecha_limite', 'La fecha límite es requerida');
      return;
    }

    if (!newProject.value.tipo) {
      setFieldError('tipo', 'El tipo de proyecto es requerido');
      return;
    }

    // Validar que la fecha límite sea posterior a la fecha de inicio
    const startDate = new Date(newProject.value.fecha_inicio);
    const endDate = new Date(newProject.value.fecha_limite);
    
    if (endDate < startDate) {
      setFieldError('fecha_limite', 'La fecha límite debe ser posterior a la fecha de inicio');
      return;
    }

    // Crear el proyecto
    const projectResponse = await api.createProject({
      nombre: newProject.value.nombre,
      descripcion: newProject.value.descripcion,
      fecha_inicio: newProject.value.fecha_inicio,
      fecha_limite: newProject.value.fecha_limite,
      tipo: newProject.value.tipo,
      estado: newProject.value.estado
    });

    const projectId = projectResponse.data.id_proyecto;

    // Obtener el ID del usuario actual
    const userProfile = await api.getProfile();
    const currentUserId = userProfile.data.id_usuario;

    await api.addUserToProject(projectId, {
      id_usuario: currentUserId,
      id_rol: 2,
      funcion: 'Creador del Proyecto'
    });

    for (const member of newProject.value.miembros) {
      await api.addUserToProject(projectId, {
        id_usuario: member.id_usuario,
        id_rol: member.rol_id,
        funcion: member.funcion
      });
    }

    closeCreateProjectModal();
    await loadAllProjects();
  } catch (error) {
    console.error('Error al crear el proyecto:', error);
    
    // Manejar errores específicos de la API
    if (error.response) {
      const { data, status } = error.response;
      
      if (status === 400) {
        errorMessage.value = data.error || 'Error en los datos del proyecto';
      } else if (status === 401) {
        errorMessage.value = 'Sesión expirada. Por favor, inicia sesión nuevamente.';
        // Redirigir al login
        router.push('/auth');
      } else {
        errorMessage.value = data.error || 'Error al crear el proyecto';
      }
    } else if (error.request) {
      errorMessage.value = 'No se pudo conectar con el servidor. Verifica tu conexión a internet.';
    } else {
      errorMessage.value = error.message || 'Error desconocido';
    }
  } finally {
    isSubmitting.value = false;
  }
};

const nextTitle = () => {
  currentTitleIndex.value = (currentTitleIndex.value + 1) % titles.length;
  console.log('Cambiando a título:', titles[currentTitleIndex.value]);
  // No es necesario cargar proyectos, solo actualizar el índice
  setTimeout(() => {
    AOS.refresh(); // Refrescar AOS después de que Vue haya actualizado el DOM
  }, 50);
};

const prevTitle = () => {
  currentTitleIndex.value = (currentTitleIndex.value - 1 + titles.length) % titles.length;
  console.log('Cambiando a título:', titles[currentTitleIndex.value]);
  // No es necesario cargar proyectos, solo actualizar el índice
  setTimeout(() => {
    AOS.refresh(); // Refrescar AOS después de que Vue haya actualizado el DOM
  }, 50);
};

// Función para cargar el perfil del usuario
const loadUserProfile = async () => {
  try {
    const response = await api.getProfile();
    console.log('Respuesta del perfil:', response); // Para depuración
    
    if (response) {
      userProfile.value = {
        ...response,
        avatar: response.avatar ? response.avatar : null
      };
      console.log('Perfil de usuario cargado:', userProfile.value);
    } else {
      console.error('La respuesta de la API está vacía');
      userProfile.value = {
        nombre: 'Usuario',
        avatar: null
      };
    }
  } catch (error) {
    console.error('Error al cargar el perfil de usuario:', error);
    userProfile.value = {
      nombre: 'Usuario',
      avatar: null
    };
  }
};

// Función para manejar errores en la carga de la imagen de perfil
const handleAvatarError = (e) => {
  e.target.style.display = 'none';
  const container = e.target.parentElement;
  const placeholder = document.createElement('div');
  placeholder.className = 'avatar-placeholder';
  placeholder.innerHTML = '<i class="fas fa-user"></i>';
  container.appendChild(placeholder);
};

// Método para verificar si un campo tiene error
const hasFieldError = (fieldName) => {
  return errorFields.value.includes(fieldName);
};

// Método para manejar errores en campos específicos
const setFieldError = (fieldName, message) => {
  errorMessage.value = message;
  errorFields.value = [fieldName];
};

// Método para limpiar todos los errores
const clearErrors = () => {
  errorMessage.value = '';
  errorFields.value = [];
};
</script>

<style scoped>
.limbo-view {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
  background-image: url('@/assets/images/LimboBackground.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-attachment: fixed; /* Mantener el fondo fijo */
  padding: 2rem;
  box-sizing: border-box; 
  position: relative; /* Para el pseudo-elemento */
  overflow: hidden; /* Evitar scroll en el contenedor principal */
}

/* Añadir un pseudo-elemento para mantener la proporción del fondo */
.limbo-view::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: url('@/assets/images/LimboBackground.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  z-index: -1;
  transform: scale(1.1); /* Evitar bordes blancos al hacer scroll */
}

.limbo-container {
  background-color: rgba(0, 0, 0, 0.5);
  padding: 2rem 3rem;
  border-radius: 15px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(8px); 
  -webkit-backdrop-filter: blur(8px); 
  text-align: center;
  width: 90%; 
  max-width: 1200px; /* Limitar el ancho máximo */
  margin: 0 auto; /* Centrar horizontalmente */
  position: relative; /* Para mantener el contenido por encima del pseudo-elemento */
  z-index: 1; /* Asegurar que esté por encima del fondo */
}

.title-carousel {
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 2rem;
  position: relative;
}

.carousel-btn {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  backdrop-filter: blur(5px);
}

.carousel-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: scale(1.1);
}

.carousel-btn i {
  font-size: 1.2rem;
  color: white;
}

.title {
  margin: 0;
  transition: all 0.3s ease;
}

.loading-spinner {
  font-size: 1.5rem;
  color: #555;
}

.projects-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* Exactamente 3 columnas */
  gap: 1.5rem;
  margin-top: 1.5rem;
  width: 100%;
  max-width: 1200px;
  margin-left: auto;
  margin-right: auto;
}

.project-card {
  background-color: rgba(255, 255, 255, 0.1);
  padding: 1.5rem;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 250px; /* Altura fija */
  width: 100%; /* Ancho fijo */
  margin: 0; /* Eliminar márgenes automáticos */
  opacity: 0; /* Inicialmente invisible para la animación */
  transform: translateY(20px); /* Inicialmente desplazado hacia abajo */
  transition: opacity 0.3s ease, transform 0.3s ease;
}

.project-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

.project-card h2 {
  color: white; 
  margin-top: 0;
  margin-bottom: 0.5rem;
  font-size: 1.4rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-height: 1.8em; /* Altura fija para el título */
}

.project-card p {
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 1rem;
  overflow: hidden;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  text-overflow: ellipsis;
  flex-grow: 1; /* Ocupar espacio disponible */
  max-height: 4.5em; /* Altura fija para la descripción */
}

.project-card button {
  margin-top: auto; /* Empujar el botón al fondo */
  background: var(--primary);
  color: white;
  border: none;
  padding: 0.8rem 1.5rem;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  font-size: 1rem;
  width: 100%;
  height: 40px; /* Altura fija para el botón */
}

.project-card button:hover {
  background: var(--primary-dark);
}

.project-card[data-aos] {
  opacity: 1;
  transform: translateY(0);
}

.no-projects {
  margin-top: 2rem;
}

.no-projects p {
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 1.5rem;
}

.limbo-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  margin-bottom: 2rem;
  position: relative;
  z-index: 2;
  flex-shrink: 0;

  .limbo-logo {
    height: 100px;
    width: auto;
  }

  /* Nuevo estilo para el perfil de usuario */
  .user-profile {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    
    .profile-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
    }
    
    .avatar-container {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      overflow: hidden;
      background: rgba(255, 255, 255, 0.1);
      border: 2px solid rgba(255, 255, 255, 0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
      
      &:hover {
        transform: scale(1.05);
        border-color: var(--primary);
      }
      
      .user-avatar {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
      
      .avatar-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #4a5568; /* Color gris oscuro */
        
        i {
          font-size: 1.8rem;
          color: rgba(255, 255, 255, 0.7);
        }
      }
    }
    
    .user-name {
      color: white;
      font-size: 1.1rem;
      font-weight: 500;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
      max-width: 150px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  .back-button {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    backdrop-filter: blur(5px);

    i {
      font-size: 1.5rem;
      color: white;
      opacity: 0.9;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }

    &:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateX(-3px);

      i {
        opacity: 1;
      }
    }
  }
}

.create-project-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: var(--primary);
  color: white;
  text-decoration: none;
  border-radius: var(--border-radius);
  border-color: var(--primary);
  transition: all 0.2s ease;
  margin-top: 2rem;

    &:hover {
      background: var(--primary-dark);
    }
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(5px);
}

.modal {
  background: rgba(30, 41, 59, 0.85);
  border-radius: 15px;
  width: 90%;
  max-width: 800px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);

  /* Estilos personalizados para el scroll */
  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 4px;
    transition: all 0.2s ease;

    &:hover {
      background: rgba(255, 255, 255, 0.3);
    }
  }

  /* Para Firefox */
  scrollbar-width: thin;
  scrollbar-color: rgba(255, 255, 255, 0.2) rgba(255, 255, 255, 0.05);
  
  .error-message {
    background-color: rgba(239, 68, 68, 0.2);
    color: #ef4444;
    border-left: 3px solid #ef4444;
    padding: 0.75rem 1rem;
    margin: 1rem 0;
    border-radius: 0.25rem;
    font-size: 0.9rem;
    text-align: left;
  }

  .field-error {
    input, textarea, select {
      border-color: #ef4444 !important;
      background-color: rgba(239, 68, 68, 0.05) !important;
    }

    label {
      color: #ef4444 !important;
    }
  }
}

.modal-header {
  padding: 1.5rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(30, 41, 59, 0.95);
  position: sticky;
  top: 0;
  z-index: 1;
}

.modal-header h3 {
  color: white;
  margin: 0;
  font-size: 1.2rem;
}

.close-modal {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 50%;
  transition: all 0.2s ease;
}

.close-modal:hover {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.modal-body {
  padding: 1.5rem;
}

.form-section {
  margin-bottom: 2rem;
}

.form-section h4 {
  color: white;
  font-size: 1.1rem;
  margin: 0 0 1rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: white;
}

.form-group input,
.form-group textarea,
.form-group select {
  appearance: none;
  width: 100%;
  padding: 0.75rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.05);
  color: white;
  font-size: 1rem;
  
  option {
    background-color: rgb(60, 68, 81);
  }
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  outline: none;
  border-color: var(--primary);
  background: rgba(255, 255, 255, 0.1);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.team-members {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.team-member {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
}

.member-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
}

.member-info {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.member-name {
  color: white;
  font-size: 0.9rem;
}

.member-role,
.member-function {
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.8rem;
}

.remove-member {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  padding: 0.25rem;
  border-radius: 50%;
  transition: all 0.2s ease;
}

.remove-member:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #ef4444;
}

.add-member-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  background: none;
  border: 1px dashed rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: all 0.2s ease;
}

.add-member-btn:hover {
  border-color: var(--primary);
  color: var(--primary);
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 2rem;
}

.cancel-btn,
.create-btn {
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
}

.cancel-btn {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

.cancel-btn:hover {
  background: rgba(255, 255, 255, 0.2);
}

.create-btn {
  background: var(--primary);
  border: none;
  color: white;
}

.create-btn:hover:not(:disabled) {
  background: var(--primary-dark);
}

.create-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.role-selection {
  margin-bottom: 1.5rem;
}

.role-options {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.role-option {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;
  color: white;
  padding: 0.5rem;
  border-radius: 8px;
  transition: all 0.2s ease;
  background: rgba(255, 255, 255, 0.05);
}

.role-option:hover {
  background: rgba(255, 255, 255, 0.1);
}

.search-input-group {
  display: flex;
  gap: 0.5rem;
}

.search-btn {
  white-space: nowrap;
  background: var(--primary);
  color: white;
  border: none;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.search-btn:hover {
  background: var(--primary-dark);
}

.user-details {
  margin-top: 1.5rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.user-avatar-container {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  overflow: hidden;
  position: relative;
  background: rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: center;
  align-items: center;
}

.user-avatar {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.user-avatar-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.5rem;
  font-weight: bold;
  color: white;
  background: var(--primary);
}

.user-text h4 {
  color: white;
  margin: 0;
}

.user-text p {
  color: rgba(255, 255, 255, 0.7);
  margin: 0.25rem 0 0;
}

.search-error {
  color: #ef4444;
  margin-top: 1rem;
  text-align: center;
  padding: 0.5rem;
  background: rgba(239, 68, 68, 0.1);
  border-radius: 8px;
  }
</style> 