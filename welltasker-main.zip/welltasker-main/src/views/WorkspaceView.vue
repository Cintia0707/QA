<template>
  <div class="workspace-layout">
    <Sidebar 
      :class="{ active: isSidebarOpen }"
      @toggle-sidebar="toggleSidebar"
      data-aos="fade-right"
    />
    
    <header class="workspace-header" data-aos="fade-left">
      <button class="toggle-sidebar-mobile" @click="toggleSidebar">
        <i class="fas fa-bars"></i>
      </button>
      <div class="selected-project" v-if="selectedProject">
        <i class="fas fa-project-diagram"></i>
        <span class="project-name">{{ selectedProject.nombre }}</span>
        <button class="close-project-btn" @click="clearSelectedProject">
          <i class="fas fa-times"></i>
        </button>
      </div>
      <div class="header-actions">
        <button class="notification-btn">
          <i class="fas fa-bell"></i>
          <span class="notification-badge">3</span>
        </button>
        <div class="user-menu">
          <div class="user-avatar">
            <img 
              v-if="userProfile?.avatar" 
              :src="userProfile.avatar.startsWith('data:image') ? userProfile.avatar : `data:image/jpeg;base64,${userProfile.avatar}`" 
              :alt="userProfile?.nombre" 
              class="user-avatar-img"
              @error="handleAvatarError"
            >
            <i v-else class="fas fa-user-circle"></i>
          </div>
          <span class="user-name">{{ userProfile?.nombre || 'Usuario' }}</span>
        </div>
      </div>
    </header>
    
    <div class="workspace-content">
      <main class="workspace-main" data-aos="fade-up" data-aos-delay="200">
        <router-view @project-selected="handleProjectSelected"></router-view>
      </main>
    </div>
  </div>
</template>

<script>
import Sidebar from '@/components/layout/Sidebar.vue'
import AOS from 'aos';
import 'aos/dist/aos.css';
import api from '@/api';
import { ref, onMounted } from 'vue';

export default {
  name: 'WorkspaceView',
  components: {
    Sidebar
  },
  setup() {
    const isSidebarOpen = ref(true);
    const userProfile = ref(null);
    const selectedProject = ref(null);

    const clearSelectedProject = () => {
      selectedProject.value = null;
      localStorage.removeItem('selectedProject');
    };

    onMounted(async () => {
      try {
        const response = await api.getProfile();
        console.log('Respuesta del perfil en Workspace:', response);
        
        if (response) {
          const avatar = response.avatar;
          const formattedAvatar = avatar && !avatar.startsWith('data:image') 
            ? `data:image/jpeg;base64,${avatar}`
            : avatar;

          userProfile.value = {
            ...response,
            avatar: formattedAvatar
          };
          console.log('Perfil de usuario cargado en Workspace:', userProfile.value);
        } else {
          console.error('La respuesta de la API está vacía');
          userProfile.value = {
            nombre: 'Usuario',
            avatar: null
          };
        }
      } catch (error) {
        console.error('Error al cargar el perfil de usuario:', error);
        userProfile.value = {
          nombre: 'Usuario',
          avatar: null
        };
      }
    });

    const handleAvatarError = (e) => {
      e.target.style.display = 'none';
      const container = e.target.parentElement;
      const placeholder = document.createElement('i');
      placeholder.className = 'fas fa-user-circle';
      container.appendChild(placeholder);
    };

    const toggleSidebar = () => {
      isSidebarOpen.value = !isSidebarOpen.value;
    };

    const handleProjectSelected = (project) => {
      selectedProject.value = project;
      console.log('Proyecto seleccionado en WorkspaceView:', project);
    };

    return {
      isSidebarOpen,
      userProfile,
      selectedProject,
      toggleSidebar,
      handleAvatarError,
      handleProjectSelected,
      clearSelectedProject
    };
  },
  mounted() {
    AOS.init({
      duration: 800,
      once: true,
      offset: 50,
      disable: 'mobile'
    });
  },
  beforeUnmount() {
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  }
}
</script>

<style lang="scss" scoped>
.workspace-layout {
  display: flex;
  min-height: 100vh;
  background: var(--light);
  background-image: url('@/assets/images/WorkspaceBackground.png');
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  background-repeat: no-repeat;
}

.workspace-content {
  flex: 1;
  margin-left: 280px;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  transition: margin-left 0.3s ease;
  background: rgba(0, 0, 0, 0);
  backdrop-filter: blur(10px);

  @media (max-width: 768px) {
    margin-left: 0;
  }
}

.workspace-header {
  height: 60px;
  background: rgba(0, 0, 0, 0);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.0);
  display: flex;
  align-items: center;
  padding: 0 1rem;
  position: fixed;
  top: 0;
  right: 0;
  left: 280px;
  z-index: 100;

  @media (max-width: 768px) {
    left: 0;
  }

  .selected-project {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-right: auto;
    padding: 0.5rem 1rem;
    background: rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius);
    transition: all 0.2s ease;

    i {
      color: var(--primary);
      font-size: 1.1rem;
    }

    .project-name {
      color: white;
      font-weight: 500;
      font-size: 1.1rem;
    }

    &:hover {
      background: rgba(255, 255, 255, 0.15);
    }

    .close-project-btn {
      background: none;
      border: none;
      color: rgba(255, 255, 255, 0.7);
      cursor: pointer;
      padding: 0.25rem;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;

      &:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }
    }
  }

  .toggle-sidebar-mobile {
    display: none;
    background: none;
    border: none;
    font-size: 1.2rem;
    color: white;
    cursor: pointer;
    padding: 0.5rem;
    margin-right: 1rem;

    @media (max-width: 768px) {
      display: block;
    }
  }

  .header-actions {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    margin-left: auto;

    .notification-btn {
      position: relative;
      background: none;
      border: none;
      font-size: 1.2rem;
      color: white;
      cursor: pointer;
      padding: 0.5rem;

      .notification-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        background: var(--primary);
        color: white;
        font-size: 0.7rem;
        padding: 0.2rem 0.4rem;
        border-radius: 10px;
      }
    }

    .user-menu {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 8px;
      transition: all 0.2s ease;

      &:hover {
        background: rgba(255, 255, 255, 0.1);
      }

      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        overflow: hidden;
        background: rgba(255, 255, 255, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;

        .user-avatar-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        i {
          font-size: 2rem;
          color: rgba(255, 255, 255, 0.8);
        }
      }

      .user-name {
        font-weight: 500;
        color: white;
      }
    }
  }
}

.workspace-main {
  background: rgba(0, 0, 0, 0.50);
  backdrop-filter: blur(10px);
  flex: 1;
  padding: 2rem;
  overflow-y: auto;
  margin-top: 60px;
  border-radius: var(--border-radius);
  margin: 80px 2rem 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  color: white;

  h1, h2, h3, h4, h5, h6 {
    color: white;
  }

  p, span {
    color: rgba(255, 255, 255, 0.8);
  }

  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.1);
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 4px;

    &:hover {
      background: rgba(255, 255, 255, 0.3);
    }
  }
}

.workspace-sidebar {
    width: 250px;
    background: rgba(0, 0, 0, 0.50);
    padding: 1.5rem;
    border-right: 1px solid rgba(255, 255, 255, 0.1);
    height: 100vh;
    overflow-y: auto;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;

    &::-webkit-scrollbar {
      width: 8px;
    }

    &::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 4px;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 4px;

      &:hover {
        background: rgba(255, 255, 255, 0.3);
      }
    }
}
</style>