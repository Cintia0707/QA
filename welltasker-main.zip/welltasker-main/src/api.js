import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  withCredentials: true
});

// Interceptor para añadir token a las requests
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Interceptor para manejar errores
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response) {
      // El servidor respondió con un código de error
      const errorMessage = error.response.data?.detail || 'Error en la operación';
      console.error('Error de respuesta:', error.response.data);
      return Promise.reject({
        message: errorMessage,
        status: error.response.status,
        data: error.response.data
      });
    } else if (error.request) {
      // La petición fue hecha pero no se recibió respuesta
      console.error('Error de red:', error.request);
      return Promise.reject({
        message: 'No se pudo conectar con el servidor',
        status: 0
      });
    } else {
      // Algo ocurrió al configurar la petición
      console.error('Error:', error.message);
      return Promise.reject({
        message: 'Error al procesar la petición',
        status: 0
      });
    }
  }
);

export default {
  // Auth methods
  async register(userData) {
    try {
      const response = await api.post('/auth/register', userData);
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async login(credentials) {
    try {
      const response = await api.post('/auth/login', {
        email: credentials.email,
        contrasena: credentials.contrasena
      });
      const { access_token } = response.data;
      localStorage.setItem('token', access_token);
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async getProfile() {
    try {
      const response = await api.get('/auth/me');
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },
  
  // Alias para mantener compatibilidad con el código existente
  getUserProfile() {
    return this.getProfile();
  },

  // Project methods
  async getUserProjects(rol_id) {
    try {
      const response = await api.get(`/projects${rol_id ? `?rol_id=${rol_id}` : ''}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async getProject(projectId) {
    try {
      const response = await api.get(`/projects/${projectId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async createProject(projectData) {
    const response = await api.post('/projects/', projectData);
    return response.data;
  },

  async updateProject(projectId, projectData) {
    try {
      const response = await api.put(`/projects/${projectId}`, projectData);
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async deleteProject(projectId) {
    try {
      const response = await api.delete(`/projects/${projectId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async addUserToProject(projectId, userData) {
    const response = await api.post(`/projects/${projectId}/users`, userData);
    return response.data;
  },

  async searchUserByEmail(email) {
    try {
      const response = await api.get(`/users/search`, {
        params: { email },
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      return response.data;
    } catch (error) {
      throw error.response?.data || error;
    }
  },

  async getProjectMembers(projectId) {
    try {
      console.log('Obteniendo miembros del proyecto:', projectId);
      const response = await api.get(`/projects/${projectId}/members`);
      console.log('Respuesta de miembros del proyecto:', response.data);
      return response.data;
    } catch (error) {
      console.error('Error al obtener miembros del proyecto:', error);
      throw error;
    }
  },

  async getProjectMembersCount(projectId) {
    const response = await api.get(`/projects/${projectId}/members/count`); // Usa `api` directamente
    return response.data;
  },

  // Métodos para tareas
  async getTasks(projectId = null) {
    try {
      const url = projectId ? `/tasks?project_id=${projectId}` : '/tasks'
      console.log('Consultando tareas con URL:', url)
      const response = await api.get(url)
      console.log('Respuesta del servidor:', response)
      return response.data
    } catch (error) {
      console.error('Error en getTasks:', error)
      throw error
    }
  },

  async createTask(taskData) {
    try {
      const response = await api.post('/tasks', taskData)
      return response.data
    } catch (error) {
      console.error('Error en createTask:', error)
      throw error
    }
  },

  async updateTask(taskId, taskData) {
    try {
      const response = await api.put(`/tasks/${taskId}`, taskData)
      return response.data
    } catch (error) {
      console.error('Error en updateTask:', error)
      throw error
    }
  },

  async deleteTask(taskId) {
    try {
      const response = await api.delete(`/tasks/${taskId}`)
      return response.data
    } catch (error) {
      console.error('Error en deleteTask:', error)
      throw error
    }
  },
};