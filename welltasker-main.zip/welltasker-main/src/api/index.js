import axios from 'axios';

const api = {
  api: axios.create({
    baseURL: 'http://localhost:8000',
    headers: {
      'Content-Type': 'application/json'
    }
  }),

  // Interceptor para añadir el token a las peticiones
  init() {
    this.api.interceptors.request.use(config => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });
  },

  // Proyectos
  async getUserProjects() {
    try {
      console.log('Obteniendo proyectos del usuario...');
      const response = await this.api.get('/projects');
      console.log('Respuesta de proyectos:', response.data);
      return response.data;
    } catch (error) {
      console.error('Error al obtener proyectos:', error.response?.data || error.message);
      throw new Error(error.response?.data?.detail || 'Error al obtener los proyectos');
    }
  },

  async getProject(projectId) {
    const response = await this.api.get(`/projects/${projectId}`);
    return response.data;
  },

  async getProjectMembers(projectId) {
    try {
      console.log('Obteniendo miembros del proyecto:', projectId);
      const response = await this.api.get(`/projects/${projectId}/members`);
      console.log('Respuesta de miembros del proyecto:', response.data);
      return response.data;
    } catch (error) {
      console.error('Error al obtener miembros del proyecto:', error);
      throw error;
    }
  },

  async getProjectMembersCount(projectId) {
    try {
      const response = await this.api.get(`/projects/${projectId}/members/count`);
      return response.data.members_count || 0;
    } catch (error) {
      console.error(`Error al obtener el conteo de miembros del proyecto ${projectId}:`, error);
      if (!error.response) {
        console.error('Error de red:', error);
        return 0;
      }
      if (error.response.status >= 500) {
        console.error('Error del servidor:', error.response.data);
        return 0;
      }
      return 0;
    }
  },

  // Usuarios
  async getUserById(userId) {
    try {
      const response = await this.api.get(`/users/${userId}`);
      return response.data;
    } catch (error) {
      console.error(`Error al obtener usuario ${userId}:`, error);
      return null;
    }
  },

  async getAllUsers() {
    try {
      console.log('Obteniendo todos los usuarios...');
      const response = await this.api.get('/users');
      console.log('Respuesta de usuarios:', response.data);
      return response.data;
    } catch (error) {
      console.error('Error al obtener usuarios:', error.response?.data || error.message);
      throw new Error(error.response?.data?.detail || 'Error al obtener la lista de usuarios');
    }
  },

  async searchUserByEmail(email) {
    if (!email) {
      throw new Error('El email es requerido para la búsqueda');
    }
    try {
      const response = await this.api.get(`/users/search?email=${email}`);
      return response.data;
    } catch (error) {
      console.error('Error al buscar usuario:', error);
      throw error;
    }
  },

  // Tareas
  async getTasks(projectId) {
    try {
      const response = await this.api.get(`/tasks?project_id=${projectId}`);
      return response.data;
    } catch (error) {
      console.error('Error al obtener tareas:', error);
      return [];
    }
  },

  async createTask(taskData) {
    try {
      const response = await this.api.post('/tasks', taskData);
      return response.data;
    } catch (error) {
      console.error('Error al crear tarea:', error);
      throw error;
    }
  }
};

// Inicializar los interceptores
api.init();

// Exportar el objeto api
export default api; 