<template>
  <div id="app">
    <!-- Contenedor principal donde se renderizan las vistas -->
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<script setup>
import { onMounted, onBeforeUnmount } from 'vue';

// Función para manejar el cierre de la página
const handleBeforeUnload = (event) => {
  // Solo limpiar si es un cierre real de la página, no un refresh
  if (event.type === 'beforeunload' && !event.currentTarget.performance.navigation.type) {
    localStorage.removeItem('token');
    sessionStorage.clear();
  }
};

// Función para manejar la visibilidad de la página
const handleVisibilityChange = () => {
  // Solo limpiar cuando la página se cierra completamente
  if (document.visibilityState === 'hidden' && !document.hidden) {
    localStorage.removeItem('token');
    sessionStorage.clear();
  }
};

onMounted(() => {
  // Agregar los event listeners
  window.addEventListener('beforeunload', handleBeforeUnload);
  document.addEventListener('visibilitychange', handleVisibilityChange);
});

onBeforeUnmount(() => {
  // Remover los event listeners
  window.removeEventListener('beforeunload', handleBeforeUnload);
  document.removeEventListener('visibilitychange', handleVisibilityChange);
});
</script>

<style lang="scss">
#app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  position: relative;

  .main-content {
    flex: 1;
    position: relative;
    z-index: 1;
  }
}
</style>