<template>
  <aside class="sidebar">
    <div class="sidebar-header">
      <img src="@/assets/images/logo.png" alt="WellTasker" class="sidebar-logo">
      <button class="toggle-sidebar" @click="toggleSidebar">
        <i class="fas fa-bars"></i>
      </button>
    </div>

    <nav class="sidebar-nav">
      <!-- Proyectos -->
      <div class="nav-section">
        <h3>Proyectos</h3>
        <ul>
          <li>
            <router-link to="/workspace/projects">
              <i class="fas fa-project-diagram"></i>
              <span>Mis Proyectos</span>
            </router-link>
          </li>
          <li>
            <router-link to="/workspace/projects/new">
              <i class="fas fa-plus-circle"></i>
              <span>Nuevo Proyecto</span>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- Tareas -->
      <div class="nav-section">
        <h3>Tareas</h3>
        <ul>
          <li>
            <router-link to="/workspace/tasks">
              <i class="fas fa-tasks"></i>
              <span>Mis Tareas</span>
            </router-link>
          </li>
          <li>
            <router-link to="/workspace/tasks/new">
              <i class="fas fa-plus"></i>
              <span>Nueva Tarea</span>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- Archivos -->
      <div class="nav-section">
        <h3>Archivos</h3>
        <ul>
          <li>
            <router-link to="/workspace/files">
              <i class="fas fa-folder"></i>
              <span>Mis Archivos</span>
            </router-link>
          </li>
          <li>
            <router-link to="/workspace/files/upload">
              <i class="fas fa-upload"></i>
              <span>Subir Archivos</span>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- Comunicación -->
      <div class="nav-section">
        <h3>Comunicación</h3>
        <ul>
          <li>
            <router-link to="/workspace/chat">
              <i class="fas fa-comments"></i>
              <span>Chat</span>
            </router-link>
          </li>
          <li>
            <router-link to="/workspace/video-calls">
              <i class="fas fa-video"></i>
              <span>Videollamadas</span>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- Informes -->
      <div class="nav-section">
        <h3>Informes</h3>
        <ul>
          <li>
            <router-link to="/workspace/reports">
              <i class="fas fa-chart-bar"></i>
              <span>Informes</span>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- Configuración -->
      <div class="nav-section">
        <h3>Configuración</h3>
        <ul>
          <li>
            <router-link to="/workspace/settings">
              <i class="fas fa-cog"></i>
              <span>Configuración</span>
            </router-link>
          </li>
          <li>
            <router-link to="/workspace/language">
              <i class="fas fa-globe"></i>
              <span>Idioma</span>
            </router-link>
          </li>
          <li>
            <a href="#" @click.prevent="logout">
              <i class="fas fa-sign-out-alt"></i>
              <span>Cerrar Sesión</span>
            </a>
          </li>
        </ul>
      </div>
    </nav>
  </aside>
</template>

<script>
export default {
  name: 'AppSidebar',
  methods: {
    toggleSidebar() {
      this.$emit('toggle-sidebar')
    },
    logout() {
      this.$store.dispatch('auth/logout')
      this.$router.push('/')
    }
  }
}
</script>

<style lang="scss" scoped>
.sidebar {
  width: 280px;
  height: 100vh;
  background: rgba(0, 0, 0, 0.50);
  color: white;
  position: fixed;
  left: 0;
  top: 0;
  overflow-y: auto;
  transition: all 0.3s ease;
  z-index: 1000;
  backdrop-filter: blur(10px);

  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 4px;

    &:hover {
      background: rgba(255, 255, 255, 0.3);
    }
  }

  .sidebar-header {
    padding: 1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);

    .sidebar-logo {
      height: 40px;
      width: auto;
    }

    .toggle-sidebar {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      font-size: 1.2rem;
      padding: 0.5rem;
      display: none;

      @media (max-width: 768px) {
        display: block;
      }
    }
  }

  .sidebar-nav {
    padding: 1rem 0;

    .nav-section {
      margin-bottom: 1.5rem;

      h3 {
        padding: 0 1rem;
        font-size: 0.8rem;
        text-transform: uppercase;
        color: rgba(255, 255, 255, 0.5);
        margin-bottom: 0.5rem;
      }

      ul {
        list-style: none;
        padding: 0;
        margin: 0;

        li {
          a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: white;
            text-decoration: none;
            transition: all 0.2s ease;

            i {
              width: 20px;
              margin-right: 0.75rem;
              font-size: 1.1rem;
            }

            &:hover {
              background: rgba(255, 255, 255, 0.1);
            }

            &.router-link-active {
              background: var(--primary);
            }
          }
        }
      }
    }
  }

  @media (max-width: 768px) {
    transform: translateX(-100%);

    &.active {
      transform: translateX(0);
    }
  }
}
</style> 