<template>
  <div class="login-form">
    <h2 class="auth-title">Iniciar Sesión</h2>
    
    <div v-if="errorMessage" class="error-message">
      {{ errorMessage }}
    </div>
    
    <form @submit.prevent="handleSubmit" autocomplete="off">
      <div class="form-group" :class="{ 'field-error': hasFieldError('email') }">
        <label for="email">Correo electrónico</label>
        <input 
          type="email" 
          id="email" 
          v-model.trim="formData.email" 
          placeholder="Tu correo electrónico"
          :disabled="isSubmitting"
          @input="clearFieldError('email')"
          autocomplete="off"
        >
        <span v-if="hasFieldError('email')" class="field-error-message">Campo requerido</span>
      </div>
      
      <div class="form-group" :class="{ 'field-error': hasFieldError('contrasena') }">
        <label for="contrasena">Contraseña</label>
        <input 
          type="password" 
          id="contrasena" 
          v-model.trim="formData.contrasena" 
          placeholder="Tu contraseña"
          :disabled="isSubmitting"
          @input="clearFieldError('contrasena')"
          autocomplete="new-password"
        >
        <span v-if="hasFieldError('contrasena')" class="field-error-message">Campo requerido</span>
      </div>
      
      <AppButton type="submit" class="submit-button" :disabled="isSubmitting">
        {{ isSubmitting ? 'Iniciando sesión...' : 'Iniciar Sesión' }}
      </AppButton>
    </form>
  </div>
</template>

<script>
import AppButton from '@/components/ui/AppButton.vue'

export default {
  name: 'LoginForm',
  components: {
    AppButton
  },
  props: {
    errorMessage: {
      type: String,
      default: ''
    },
    errorFields: {
      type: Array,
      default: () => []
    },
    isSubmitting: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      formData: {
        email: '',
        contrasena: ''
      },
      validationErrors: []
    }
  },
  methods: {
    hasFieldError(fieldName) {
      return this.validationErrors.includes(fieldName);
    },
    clearFieldError(fieldName) {
      this.validationErrors = this.validationErrors.filter(error => error !== fieldName);
      this.$emit('clear-error', fieldName);
    },
    validateForm() {
      this.validationErrors = [];
      
      if (!this.formData.email.trim()) {
        this.validationErrors.push('email');
      }
      
      if (!this.formData.contrasena.trim()) {
        this.validationErrors.push('contrasena');
      }
      
      return this.validationErrors.length === 0;
    },
    handleSubmit() {
      if (this.validateForm()) {
        this.$emit('submit', this.formData);
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/auth/_form';

.error-message {
  background-color: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  border-left: 3px solid #ef4444;
  padding: 0.75rem 1rem;
  margin: 1rem 0;
  border-radius: 0.25rem;
  font-size: 0.9rem;
  text-align: left;
}

.field-error {
  input, textarea, select {
    border-color: #ef4444 !important;
    background-color: rgba(239, 68, 68, 0.05) !important;
  }

  label {
    color: #ef4444 !important;
  }
}

.field-error-message {
  color: #ef4444;
  font-size: 0.8rem;
  margin-top: 0.25rem;
  display: block;
}

.submit-button {
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
}
</style>