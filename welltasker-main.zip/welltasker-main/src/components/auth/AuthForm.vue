<template>
  <div class="auth-form">
    <transition name="fade" mode="out-in">
      <component 
        :is="currentFormComponent" 
        @submit="handleSubmit"
        @clear-error="clearFieldError"
        @update:errorFields="errorFields = $event"
        @update:errorMessage="errorMessage = $event"
        :key="currentMode"
        ref="formComponent"
        :error-fields="errorFields"
        :error-message="errorMessage"
      />
    </transition>
    
    <div class="auth-switch">
      <p style="color: white;" v-if="currentMode === 'login'">
        ¿No tienes cuenta? 
        <button @click="switchForm('register')">Regístrate</button>
      </p>
      <p style="color: white;" v-else>
        ¿Ya tienes cuenta? 
        <button @click="switchForm('login')">Inicia sesión</button>
      </p>
    </div>

    <!-- Modal de Éxito -->
    <div v-if="showSuccessModal" class="modal-overlay" @click.self="closeSuccessModal">
      <div class="modal success-modal">
        <div class="modal-header">
          <h3>¡Registro Exitoso!</h3>
          <button class="close-modal" @click="closeSuccessModal">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="success-content">
            <i class="fas fa-check-circle"></i>
            <p>Tu cuenta ha sido creada con éxito.</p>
            <p>Ahora puedes iniciar sesión con tus credenciales.</p>
          </div>
          <div class="modal-actions">
            <button class="accept-btn" @click="handleAccept">
              Aceptar
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import LoginForm from './LoginForm.vue'
import RegisterForm from './RegisterForm.vue'
import AOS from 'aos'
import api from '@/api'

export default {
  name: 'AuthForm',
  components: {
    LoginForm,
    RegisterForm
  },
  props: {
    initialMode: {
      type: String,
      default: 'login'
    }
  },
  data() {
    return {
      currentMode: this.initialMode,
      errorMessage: '',
      errorFields: [],
      isSubmitting: false,
      showSuccessModal: false
    }
  },
  computed: {
    currentFormComponent() {
      return this.currentMode === 'login' ? 'LoginForm' : 'RegisterForm'
    }
  },
  mounted() {
    // Inicializar AOS
    AOS.init({
      duration: 500,
      once: false,
      offset: 50
    });
  },
  beforeUnmount() {
    // Limpiar AOS
    if (document) {
      const elements = document.querySelectorAll('[data-aos]');
      elements.forEach(el => {
        if (el) {
          el.removeAttribute('data-aos');
          el.removeAttribute('data-aos-delay');
          el.removeAttribute('data-aos-duration');
        }
      });
    }
  },
  methods: {
    switchForm(newMode) {
      // Primero actualizar el modo
      this.currentMode = newMode;
      // Resetear errores al cambiar de formulario
      this.errorMessage = '';
      this.errorFields = [];
      
      // Esperar al siguiente ciclo de renderizado
      this.$nextTick(() => {
        // Refrescar AOS después de que el componente se haya actualizado
        AOS.refresh();
        
        // Actualizar la URL
        this.$router.push({ query: { ...this.$route.query, mode: newMode } });
      });
    },
    clearFieldError(fieldName) {
      // Remover el campo de la lista de errores
      this.errorFields = this.errorFields.filter(field => field !== fieldName);
      
      // Si no hay más campos con error, limpiar el mensaje de error
      if (this.errorFields.length === 0) {
        this.errorMessage = '';
      }
    },
    async handleSubmit(formData) {
      try {
        // Resetear errores previos
        this.errorMessage = '';
        this.errorFields = [];
        this.isSubmitting = true;

        // Verificar que formData no sea un evento
        if (formData instanceof Event) {
          return;
        }

        // Manejar errores específicos del formulario de registro
        if (formData.passwordMismatch) {
          this.errorFields = ['contrasena', 'confirmContrasena'];
          this.errorMessage = formData.message;
          return;
        }

        if (formData.avatarError) {
          this.errorMessage = formData.message;
          return;
        }

        // Usar la API configurada
        const action = this.currentMode === 'login' ? 'login' : 'register';

        try {
          const response = await api[action](formData);
          
          if (this.currentMode === 'login') {
            // Para login, verificamos el token
            if (response && response.access_token) {
              this.$emit('auth-success');
            } else {
              console.error('Respuesta inesperada de la API:', response);
              this.errorMessage = 'Respuesta inesperada del servidor.';
            }
          } else {
            // Para registro, mostramos el modal de éxito
            this.showSuccessModal = true;
          }
        } catch (apiError) {
          console.error('Error de API:', apiError);
          
          // Manejar errores específicos de la API
          if (apiError.response) {
            const { status, data } = apiError.response;
            
            switch (status) {
              case 400:
                if (data && data.detail) {
                  if (Array.isArray(data.detail)) {
                    // Manejar errores de validación de FastAPI
                    data.detail.forEach(error => {
                      if (error.loc && error.loc[1]) {
                        const field = error.loc[1];
                        this.errorFields.push(field);
                      }
                    });
                    this.errorMessage = data.detail[0].msg;
                  } else if (typeof data.detail === 'string') {
                    this.errorMessage = data.detail;
                  }
                }
                break;
                
              case 401:
                this.errorFields = ['email', 'contrasena'];
                // Usar el mensaje de error del backend si está disponible
                this.errorMessage = data?.detail || 'Credenciales incorrectas';
                break;
                
              case 422:
                // Error de validación de FastAPI
                if (data.detail) {
                  data.detail.forEach(error => {
                    if (error.loc && error.loc[1]) {
                      const field = error.loc[1];
                      this.errorFields.push(field);
                    }
                  });
                  this.errorMessage = data.detail[0].msg;
                }
                break;
                
              case 429:
                this.errorMessage = 'Demasiados intentos. Por favor, intenta más tarde.';
                break;
                
              default:
                this.errorMessage = data?.detail || 'Error en la autenticación';
            }
          } else if (apiError.request) {
            this.errorMessage = 'No se pudo conectar con el servidor. Verifica tu conexión a internet.';
          } else {
            // Si el error viene directamente del backend (sin response)
            this.errorMessage = apiError.detail || apiError.message || 'Error desconocido';
          }
        }
      } catch (error) {
        console.error('Error general:', error);
        this.errorMessage = error.detail || error.message || 'Ocurrió un error inesperado';
      } finally {
        this.isSubmitting = false;
      }
    },
    closeSuccessModal() {
      this.showSuccessModal = false;
    },
    handleAccept() {
      this.closeSuccessModal();
      this.switchForm('login');
    }
  }
}
</script>

<style lang="scss" scoped>
.auth-form {
  width: 100%;
  max-width: 400px;
  margin: 0 auto;
  padding: 2rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 1rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 2;
  flex: 1;
  display: flex;
  flex-direction: column;

  .auth-switch {
    margin-top: 1.5rem;
    text-align: center;
    font-size: 0.9rem;
    flex-shrink: 0;
    
    button {
      background: none;
      border: none;
      color: var(--primary);
      cursor: pointer;
      font-weight: 500;
      padding: 0;
      
      &:hover {
        text-decoration: underline;
      }
    }
  }

  .error-message {
    background-color: rgba(239, 68, 68, 0.2);
    color: #ef4444;
    border-left: 3px solid #ef4444;
    padding: 0.75rem 1rem;
    margin: 1rem 0;
    border-radius: 0.25rem;
    font-size: 0.9rem;
    text-align: left;
  }

  .field-error {
    input, textarea, select {
      border-color: #ef4444 !important;
      background-color: rgba(239, 68, 68, 0.05) !important;
    }

    label {
      color: #ef4444 !important;
    }
  }
}

// Transiciones
.fade-enter-active,
.fade-leave-active {
  transition: all 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(20px);
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(5px);
}

.modal {
  background: rgba(30, 41, 59, 0.95);
  border-radius: 15px;
  width: 90%;
  max-width: 400px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  animation: modalFadeIn 0.3s ease;

  .modal-header {
    padding: 1.5rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;

    h3 {
      color: white;
      margin: 0;
      font-size: 1.2rem;
    }

    .close-modal {
      background: none;
      border: none;
      color: rgba(255, 255, 255, 0.7);
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 50%;
      transition: all 0.2s ease;

      &:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }
    }
  }

  .modal-body {
    padding: 1.5rem;

    .success-content {
      text-align: center;
      margin-bottom: 1.5rem;

      i {
        font-size: 3rem;
        color: #10B981;
        margin-bottom: 1rem;
      }

      p {
        color: white;
        margin: 0.5rem 0;
        font-size: 1rem;

        &:first-of-type {
          font-size: 1.1rem;
          font-weight: 500;
        }
      }
    }

    .modal-actions {
      display: flex;
      justify-content: center;
      gap: 1rem;

      .accept-btn {
        padding: 0.75rem 2rem;
        background: var(--primary);
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;

        &:hover {
          background: var(--primary-dark);
        }
      }
    }
  }
}

@keyframes modalFadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>