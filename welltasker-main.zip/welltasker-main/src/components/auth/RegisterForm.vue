<template>
  <div class="register-form">
    <h2 class="auth-title">Registro</h2>
    
    <div v-if="errorMessage" class="error-message">
      {{ errorMessage }}
    </div>
    
    <form @submit.prevent="handleSubmit" autocomplete="off">
      <div class="form-group" :class="{ 'field-error': hasFieldError('nombre') }">
        <label for="nombre">Nombre completo</label>
        <input 
          type="text" 
          id="nombre" 
          v-model.trim="formData.nombre" 
          placeholder="Tu nombre completo"
          :disabled="isSubmitting"
          @input="clearFieldError('nombre')"
          pattern="[A-Za-zÁáÉéÍíÓóÚúÑñ\s]+"
          title="Solo se permiten letras y espacios"
          autocomplete="off"
        >
        <span v-if="hasFieldError('nombre')" class="field-error-message">Campo requerido</span>
      </div>
      
      <div class="form-group" :class="{ 'field-error': hasFieldError('email') }">
        <label for="email">Correo electrónico</label>
        <input 
          type="email" 
          id="email" 
          v-model.trim="formData.email" 
          placeholder="Tu correo electrónico"
          :disabled="isSubmitting"
          @input="clearFieldError('email')"
          autocomplete="off"
        >
        <span v-if="hasFieldError('email')" class="field-error-message">Campo requerido</span>
      </div>
      
      <div class="form-group" :class="{ 'field-error': hasFieldError('contrasena') }">
        <label for="contrasena">Contraseña</label>
        <input 
          type="password" 
          id="contrasena" 
          v-model.trim="formData.contrasena" 
          placeholder="Tu contraseña"
          :disabled="isSubmitting"
          @input="validatePasswords"
          minlength="6"
          pattern="^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,}$"
          title="La contraseña debe tener al menos 6 caracteres, incluyendo una mayúscula, un número y un carácter especial"
          autocomplete="new-password"
        >
        <span v-if="hasFieldError('contrasena')" class="field-error-message">Campo requerido</span>
      </div>
      
      <div class="form-group" :class="{ 'field-error': hasFieldError('confirmContrasena') }">
        <label for="confirmContrasena">Confirmar contraseña</label>
        <input 
          type="password" 
          id="confirmContrasena" 
          v-model.trim="formData.confirmContrasena" 
          placeholder="Confirma tu contraseña"
          :disabled="isSubmitting"
          @input="validatePasswords"
          autocomplete="new-password"
        >
        <span v-if="hasFieldError('confirmContrasena')" class="field-error-message">Campo requerido</span>
        <div v-if="passwordMismatch" class="password-mismatch">
          Las contraseñas no coinciden
        </div>
      </div>
      
      <div class="form-group">
        <label for="avatar">Avatar (opcional)</label>
        <div class="avatar-upload">
          <input 
            type="file" 
            id="avatar" 
            accept="image/*"
            @change="handleAvatarChange"
            :disabled="isSubmitting"
            class="avatar-input"
          >
          <div class="avatar-preview" v-if="avatarPreview">
            <img :src="avatarPreview" alt="Avatar preview">
          </div>
        </div>
      </div>
      
      <AppButton type="submit" class="submit-button" :disabled="isSubmitting">
        {{ isSubmitting ? 'Creando cuenta...' : 'Registrarse' }}
      </AppButton>
    </form>
  </div>
</template>

<script>
import AppButton from '@/components/ui/AppButton.vue'

export default {
  name: 'RegisterForm',
  components: {
    AppButton
  },
  props: {
    errorMessage: {
      type: String,
      default: ''
    },
    errorFields: {
      type: Array,
      default: () => []
    },
    isSubmitting: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      formData: {
        nombre: '',
        email: '',
        contrasena: '',
        confirmContrasena: '',
        avatar: null
      },
      avatarPreview: null,
      passwordMismatch: false,
      validationErrors: []
    }
  },
  methods: {
    hasFieldError(fieldName) {
      return this.validationErrors.includes(fieldName);
    },
    clearFieldError(fieldName) {
      this.validationErrors = this.validationErrors.filter(error => error !== fieldName);
      this.$emit('clear-error', fieldName);
      if (fieldName === 'contrasena' || fieldName === 'confirmContrasena') {
        this.validatePasswords();
      }
    },
    validatePasswords() {
      if (this.formData.contrasena && this.formData.confirmContrasena) {
        this.passwordMismatch = this.formData.contrasena !== this.formData.confirmContrasena;
        if (this.passwordMismatch) {
          this.validationErrors = [...this.validationErrors, 'contrasena', 'confirmContrasena'];
          this.$emit('update:errorMessage', 'Las contraseñas no coinciden');
        } else {
          this.passwordMismatch = false;
          this.validationErrors = this.validationErrors.filter(field => 
            field !== 'contrasena' && field !== 'confirmContrasena'
          );
          if (this.validationErrors.length === 0) {
            this.$emit('update:errorMessage', '');
          }
        }
      }
    },
    validateForm() {
      this.validationErrors = [];
      
      if (!this.formData.nombre.trim()) {
        this.validationErrors.push('nombre');
      }
      
      if (!this.formData.email.trim()) {
        this.validationErrors.push('email');
      }
      
      if (!this.formData.contrasena.trim()) {
        this.validationErrors.push('contrasena');
      }
      
      if (!this.formData.confirmContrasena.trim()) {
        this.validationErrors.push('confirmContrasena');
      }
      
      return this.validationErrors.length === 0;
    },
    async handleAvatarChange(event) {
      const file = event.target.files[0];
      if (file) {
        if (file.size > 10 * 1024 * 1024) {
          this.$emit('submit', { 
            avatarError: true, 
            message: 'El avatar es demasiado grande. Por favor, selecciona una imagen más pequeña.' 
          });
          event.target.value = '';
          return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
          this.formData.avatar = e.target.result;
          this.avatarPreview = e.target.result;
        };
        reader.readAsDataURL(file);
      }
    },
    handleSubmit() {
      if (this.passwordMismatch) {
        this.$emit('submit', { 
          passwordMismatch: true,
          message: 'Las contraseñas no coinciden'
        });
        return;
      }

      if (this.validateForm()) {
        const userData = { ...this.formData };
        delete userData.confirmContrasena;
        this.$emit('submit', userData);
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/auth/_form';

.error-message {
  background-color: rgba(239, 68, 68, 0.2);
  color: #ef4444;
  border-left: 3px solid #ef4444;
  padding: 0.75rem 1rem;
  margin: 1rem 0;
  border-radius: 0.25rem;
  font-size: 0.9rem;
  text-align: left;
}

.field-error-message {
  color: #ef4444;
  font-size: 0.8rem;
  margin-top: 0.25rem;
  display: block;
}

.password-mismatch {
  color: #ef4444;
  font-size: 0.8rem;
  margin-top: 0.25rem;
}

.field-error {
  input, textarea, select {
    border-color: #ef4444 !important;
    background-color: rgba(239, 68, 68, 0.05) !important;
  }

  label {
    color: #ef4444 !important;
  }
}

.avatar-upload {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;

  .avatar-input {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    cursor: pointer;

    &::-webkit-file-upload-button {
      background: rgba(255, 255, 255, 0);
      color: white;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      margin-right: 1rem;
      transition: all 0.3s ease;
      
      &:hover {
        backdrop-filter: blur(5px);
      }
    }
  }

  .avatar-preview {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    overflow: hidden;
    border: 2px solid var(--primary-color);

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}

.submit-button {
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
}
</style>
