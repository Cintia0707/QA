<template>
    <button 
      :class="['app-button', variant]"
      @click="$emit('click')"
    >
      <slot></slot>
    </button>
  </template>
  
  <script>
  export default {
    name: 'AppButton',
    props: {
      variant: {
        type: String,
        default: 'primary', // 'primary' | 'secondary' | 'outline'
        validator: value => ['primary', 'secondary', 'outline'].includes(value)
      }
    }
  }
  </script>
  
  <style scoped>
  .app-button {
    padding: 0.75rem 1.5rem;
    border-radius: var(--border-radius);
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    border: none;
    
    &.primary {
      background-color: var(--primary);
      color: white;
      
      &:hover {
        background-color: var(--primary-dark);
      }
    }
    
    &.secondary {
      background-color: var(--secondary);
      color: white;
    }
    
    &.outline {
      background-color: transparent;
      border: 2px solid var(--primary);
      color: var(--primary);
    }
  }
  </style>