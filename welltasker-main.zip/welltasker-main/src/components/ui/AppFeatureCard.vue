<template>
    <div class="feature-card">
      <div class="icon">
        <slot name="icon"></slot>
      </div>
      <h3>{{ title }}</h3>
      <p>{{ description }}</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AppFeatureCard',
    props: {
      title: {
        type: String,
        required: true
      },
      description: {
        type: String,
        required: true
      }
    }
  }
  </script>
  
  <style scoped>
  .feature-card {
    color: white;
    background: rgba(0, 0, 0, 0.7);
    border-radius: var(--border-radius);
    padding: var(--space-lg);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    text-align: center;

    .icon {
      font-size: 2rem;
      margin-bottom: var(--space-md);
      color: var(--primary);
    }
    
    h3 {
      margin-bottom: var(--space-sm);
    }
  }
  </style>