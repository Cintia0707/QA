-- Asumiendo que el usuario con id_usuario = 1 ya existe
-- Asumiendo que el rol con id_rol = 1 (Administrador de Proyecto) ya existe

-- Insertar Proyectos de Ejemplo
INSERT INTO Proyecto (nombre, descripcion, fecha_inicio, id_creador)
VALUES
    ('Proyecto Alpha', 'Descripción detallada del Proyecto Alpha centrado en desarrollo web.', '2024-01-15', 1),
    ('Proyecto Beta', 'Iniciativa de marketing digital para el lanzamiento de nuevo producto.', '2024-02-01', 1),
    ('Proyecto Gamma', 'Investigación y desarrollo para la próxima generación de software.', '2024-03-10', 1)
RETURNING id_proyecto;

-- Nota: Los IDs de proyecto devueltos por el comando anterior serán usados a continuación.
-- Supongamos que los IDs devueltos son 1, 2, y 3 respectivamente para Alpha, Beta y Gamma.

-- Asociar el usuario 1 a los proyectos con el rol de Administrador de Proyecto (id_rol = 1)
INSERT INTO UsuarioProyecto (id_usuario, id_proyecto, rol_id)
VALUES
    (1, 1, 1), -- Usuario 1 asociado al Proyecto Alpha (ID 1)
    (1, 2, 1), -- Usuario 1 asociado al Proyecto Beta (ID 2)
    (1, 3, 1); -- Usuario 1 asociado al Proyecto Gamma (ID 3)

-- Puedes ajustar los id_proyecto (segundo valor en cada tupla) si los IDs 
-- devueltos por la primera inserción son diferentes.

INSERT INTO Proyecto (nombre, descripcion, fecha_inicio, id_creador)
VALUES
 ('Proyecto Alpha', 'Descripción detallada del Proyecto Alpha centrado en desarrollo web.', '2024-01-15', 1),
    ('Proyecto Beta', 'Iniciativa de marketing digital para el lanzamiento de nuevo producto.', '2024-02-01', 1),
    ('Proyecto Gamma', 'Investigación y desarrollo para la próxima generación de software.', '2024-03-10', 1),
    ('Proyecto Delta', 'Optimización de procesos internos.', '2024-04-01', 1),
    ('Proyecto Epsilon', 'Desarrollo de una aplicación móvil.', '2024-04-15', 1),
    ('Proyecto Zeta', 'Campaña de branding para nueva marca.', '2024-05-01', 1),
    ('Proyecto Eta', 'Automatización de tareas administrativas.', '2024-05-15', 1),
    ('Proyecto Theta', 'Análisis de mercado para expansión internacional.', '2024-06-01', 1),
    ('Proyecto Iota', 'Implementación de inteligencia artificial.', '2024-06-15', 1),
    ('Proyecto Kappa', 'Mejora de la interfaz de usuario.', '2024-07-01', 1),
    ('Proyecto Lambda', 'Pruebas de rendimiento del sistema.', '2024-07-15', 1),
    ('Proyecto Mu', 'Diseño de nuevos prototipos de producto.', '2024-08-01', 1),
    ('Proyecto Nu', 'Capacitación del equipo de ventas.', '2024-08-15', 1)
RETURNING id_proyecto;

INSERT INTO UsuarioProyecto (id_usuario, id_proyecto, rol_id)
VALUES
    (1, 1, 1), -- Usuario 1 asociado al Proyecto Alpha (ID 1)
    (1, 2, 1), -- Usuario 1 asociado al Proyecto Beta (ID 2)
    (1, 3, 1), -- Usuario 1 asociado al Proyecto Gamma (ID 3)
    (1, 4, 2), -- Usuario 1 asociado al Proyecto Delta (ID 4) con rol_id = 2
    (1, 5, 3), -- Usuario 1 asociado al Proyecto Epsilon (ID 5) con rol_id = 3
    (1, 6, 4), -- Usuario 1 asociado al Proyecto Zeta (ID 6) con rol_id = 4
    (1, 7, 5), -- Usuario 1 asociado al Proyecto Eta (ID 7) con rol_id = 5
    (1, 8, 2), -- Usuario 1 asociado al Proyecto Theta (ID 8) con rol_id = 2
    (1, 9, 3), -- Usuario 1 asociado al Proyecto Iota (ID 9) con rol_id = 3
    (1, 10, 4), -- Usuario 1 asociado al Proyecto Kappa (ID 10) con rol_id = 4
    (1, 11, 5), -- Usuario 1 asociado al Proyecto Lambda (ID 11) con rol_id = 5
    (1, 12, 2), -- Usuario 1 asociado al Proyecto Mu (ID 12) con rol_id = 2
    (1, 13, 3); -- Usuario 1 asociado al Proyecto Nu (ID 13) con rol_id = 3