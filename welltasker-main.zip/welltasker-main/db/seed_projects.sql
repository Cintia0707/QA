-- Asumiendo que el usuario con id_usuario = 1 ya existe
-- Asumiendo que el rol con id_rol = 1 (Administrador de Proyecto) ya existe

-- Insertar Proyectos de Ejemplo
INSERT INTO Proyecto (nombre, descripcion, fecha_inicio, id_creador)
VALUES
    ('Proyecto Alpha', 'Descripción detallada del Proyecto Alpha centrado en desarrollo web.', '2024-01-15', 1),
    ('Proyecto Beta', 'Iniciativa de marketing digital para el lanzamiento de nuevo producto.', '2024-02-01', 1),
    ('Proyecto Gamma', 'Investigación y desarrollo para la próxima generación de software.', '2024-03-10', 1)
RETURNING id_proyecto;

-- Nota: Los IDs de proyecto devueltos por el comando anterior serán usados a continuación.
-- Supongamos que los IDs devueltos son 1, 2, y 3 respectivamente para Alpha, Beta y Gamma.

-- Asociar el usuario 1 a los proyectos con el rol de Administrador de Proyecto (id_rol = 1)
INSERT INTO UsuarioProyecto (id_usuario, id_proyecto, rol_id)
VALUES
    (1, 1, 1), -- Usuario 1 asociado al Proyecto Alpha (ID 1)
    (1, 2, 1), -- Usuario 1 asociado al Proyecto Beta (ID 2)
    (1, 3, 1); -- Usuario 1 asociado al Proyecto Gamma (ID 3)

-- Puedes ajustar los id_proyecto (segundo valor en cada tupla) si los IDs 
-- devueltos por la primera inserción son diferentes. 