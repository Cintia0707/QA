-- Crear tabla Usuario
CREATE TABLE Usuario (
    id_usuario SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_ultima_edicion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    avatar bytea -- Opcional
);

-- Crear tabla Proyecto
CREATE TABLE Proyecto (
    id_proyecto SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE NOT NULL,
    fecha_limite DATE,
    estado VARCHAR(50) NOT NULL DEFAULT 'activo', -- Valores posibles: activo, completado, cancelado
    id_creador INT NOT NULL,
    FOREIGN KEY (id_creador) REFERENCES Usuario(id_usuario) ON DELETE CASCADE
);

-- Crear tabla Tarea
CREATE TABLE Tarea (
    id_tarea SERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_vencimiento DATE,
    prioridad VARCHAR(50) NOT NULL DEFAULT 'media', -- Valores posibles: alta, media, baja
    estado VARCHAR(50) NOT NULL DEFAULT 'pendiente', -- Valores posibles: pendiente, en_progreso, completada
    id_proyecto INT NOT NULL,
    id_asignado INT NOT NULL,
    FOREIGN KEY (id_proyecto) REFERENCES Proyecto(id_proyecto) ON DELETE CASCADE,
    FOREIGN KEY (id_asignado) REFERENCES Usuario(id_usuario) ON DELETE SET NULL
);

-- Crear tabla Archivo
CREATE TABLE Archivo (
    id_archivo SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    tipo_archivo VARCHAR(50) NOT NULL,
    tamano_bytes BIGINT NOT NULL,
    url_almacenamiento VARCHAR(255) NOT NULL,
    fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    id_subido_por INT NOT NULL,
    id_proyecto INT NOT NULL,
    id_tarea INT,
    FOREIGN KEY (id_subido_por) REFERENCES Usuario(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_proyecto) REFERENCES Proyecto(id_proyecto) ON DELETE CASCADE,
    FOREIGN KEY (id_tarea) REFERENCES Tarea(id_tarea) ON DELETE SET NULL
);

-- Crear tabla Rol
CREATE TABLE Rol (
    id_rol SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    permisos JSONB
);

-- Crear tabla Mensaje
CREATE TABLE Mensaje (
    id_mensaje SERIAL PRIMARY KEY,
    contenido TEXT NOT NULL,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    id_remitente INT NOT NULL,
    id_proyecto INT,
    id_destinatario INT,
    FOREIGN KEY (id_remitente) REFERENCES Usuario(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_proyecto) REFERENCES Proyecto(id_proyecto) ON DELETE SET NULL,
    FOREIGN KEY (id_destinatario) REFERENCES Usuario(id_usuario) ON DELETE SET NULL
);

-- Crear tabla Informe
CREATE TABLE Informe (
    id_informe SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    tipo VARCHAR(50) NOT NULL, -- Valores posibles: mensual, trimestral, personalizado
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    parametros JSONB,
    id_proyecto INT NOT NULL,
    id_usuario_creador INT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_proyecto) REFERENCES Proyecto(id_proyecto) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario_creador) REFERENCES Usuario(id_usuario) ON DELETE CASCADE
);

-- Crear tabla Notificacion
CREATE TABLE Notificacion (
    id_notificacion SERIAL PRIMARY KEY,
    mensaje TEXT NOT NULL,
    tipo VARCHAR(50) NOT NULL, -- Valores posibles: asignacion_tarea, mensaje, alerta
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    leida BOOLEAN DEFAULT FALSE,
    id_usuario_destino INT NOT NULL,
    FOREIGN KEY (id_usuario_destino) REFERENCES Usuario(id_usuario) ON DELETE CASCADE
);

-- Crear tabla HistorialCambios
CREATE TABLE HistorialCambios (
    id_cambio SERIAL PRIMARY KEY,
    tipo_entidad VARCHAR(50) NOT NULL, -- Valores posibles: Tarea, Proyecto, Archivo
    id_entidad INT NOT NULL,
    accion VARCHAR(50) NOT NULL, -- Valores posibles: crear, editar, eliminar
    fecha_cambio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    id_usuario INT NOT NULL,
    detalles JSONB,
    FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario) ON DELETE CASCADE
);

-- Crear tabla intermedia UsuarioProyecto (relación muchos a muchos)
CREATE TABLE UsuarioProyecto (
    id_usuario INT NOT NULL,
    id_proyecto INT NOT NULL,
    rol_id INT NOT NULL,
    PRIMARY KEY (id_usuario, id_proyecto),
    FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_proyecto) REFERENCES Proyecto(id_proyecto) ON DELETE CASCADE,
    FOREIGN KEY (rol_id) REFERENCES Rol(id_rol) ON DELETE CASCADE
);

	-- Añadir columna funcion a UsuarioProyecto
ALTER TABLE UsuarioProyecto
ADD COLUMN funcion VARCHAR(100);

-- Añadir columna tipo a Proyecto
ALTER TABLE Proyecto
ADD COLUMN tipo VARCHAR(100);