
INSERT INTO Tarea (titulo, descripcion, fecha_creacion, fecha_vencimiento, prioridad, estado, id_proyecto, id_asignado)
VALUES
    ('Configuración del entorno', 'Preparar el entorno de desarrollo para el proyecto.', '2024-04-10', null, 'alta', 'completada', 1, 1),
    ('Diseño de interfaz', 'Crear prototipos de la interfaz de usuario.', '2024-04-15', null, 'media', 'en_progreso', 16, 1),
    ('Pruebas unitarias', 'Escribir pruebas unitarias para el módulo principal.', '2024-04-20', null, 'baja', 'pendiente', 3, 1),
    ('Optimización de base de datos', 'Mejorar consultas SQL para mejorar el rendimiento.', '2024-04-25', null, 'alta', 'pendiente', 4, 1),
    ('Documentación técnica', 'Redactar documentación técnica del sistema.', '2024-05-01', null, 'media', 'completada', 5, 1),
    ('Integración de API', 'Conectar la aplicación con servicios externos.', '2024-05-10', null, 'alta', 'en_progreso', 6, 1),
    ('Revisión de código', 'Realizar revisión de código con el equipo.', '2024-05-15', null, 'media', 'pendiente', 7, 1),
    ('Capacitación del equipo', 'Capacitar al equipo en nuevas herramientas.', '2024-05-20', null, 'baja', 'completada', 8, 1),
    ('Despliegue en producción', 'Llevar la aplicación a producción.', '2024-06-01', null, 'alta', 'en_progreso', 9, 1),
    ('Corrección de errores', 'Resolver bugs reportados por los usuarios.', '2024-06-10', null, 'media', 'pendiente', 10, 1),
    ('Análisis de datos', 'Analizar datos recopilados durante las pruebas.', '2024-06-15', null, 'baja', 'completada', 11, 1),
    ('Implementación de seguridad', 'Añadir capas de seguridad al sistema.', '2024-06-20', null, 'alta', 'pendiente', 12, 1),
    ('Migración de datos', 'Migrar datos desde el sistema antiguo.', '2024-07-01', null, 'media', 'en_progreso', 13, 1),
    ('Generación de informes', 'Generar informes mensuales para el cliente.', '2024-07-10', null, 'baja', 'pendiente', 1, 1),
    ('Planificación estratégica', 'Definir estrategias para el próximo trimestre.', '2024-07-15', null, 'alta', 'completada', 16, 1);