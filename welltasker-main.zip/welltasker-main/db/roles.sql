-- Insertar roles predefinidos con sus permisos
INSERT INTO Rol (nombre, permisos) VALUES
(
    'Administrador del Sistema',
    '{
        "proyectos": {
            "crear": true,
            "editar": true,
            "eliminar": true,
            "ver_todos": true
        },
        "usuarios": {
            "crear": true,
            "editar": true,
            "eliminar": true,
            "ver_todos": true
        },
        "roles": {
            "asignar": true,
            "crear": true,
            "editar": true,
            "eliminar": true
        },
        "tareas": {
            "crear": true,
            "editar": true,
            "eliminar": true,
            "ver_todas": true
        },
        "archivos": {
            "subir": true,
            "eliminar": true,
            "ver_todos": true
        },
        "informes": {
            "crear": true,
            "ver_todos": true
        }
    }'::jsonb
),
(
    'Administrador de Proyecto',
    '{
        "proyectos": {
            "editar": true,
            "ver_propios": true
        },
        "usuarios": {
            "invitar": true,
            "remover": true
        },
        "roles": {
            "asignar": true
        },
        "tareas": {
            "crear": true,
            "editar": true,
            "eliminar": true,
            "ver_todas": true
        },
        "archivos": {
            "subir": true,
            "eliminar": true,
            "ver_todos": true
        },
        "informes": {
            "crear": true,
            "ver_propios": true
        }
    }'::jsonb
),
(
    'Líder de Equipo',
    '{
        "proyectos": {
            "ver_propios": true
        },
        "tareas": {
            "crear": true,
            "editar": true,
            "asignar": true,
            "ver_asignadas": true
        },
        "archivos": {
            "subir": true,
            "ver_propios": true
        },
        "informes": {
            "crear": true,
            "ver_propios": true
        }
    }'::jsonb
),
(
    'Miembro del Equipo',
    '{
        "proyectos": {
            "ver_propios": true
        },
        "tareas": {
            "editar_propias": true,
            "ver_asignadas": true
        },
        "archivos": {
            "subir": true,
            "ver_propios": true
        }
    }'::jsonb
),
(
    'Observador',
    '{
        "proyectos": {
            "ver_propios": true
        },
        "tareas": {
            "ver_asignadas": true
        },
        "archivos": {
            "ver_propios": true
        }
    }'::jsonb
); 