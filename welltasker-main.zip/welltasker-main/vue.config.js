const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    host: 'localhost',
    port: 8080,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        logLevel: 'debug',
        onProxyReq: function(proxyReq, req, res) {
          proxyReq.setHeader('Content-Type', 'application/json');
        }
      }
    },
    client: {
      webSocketURL: 'ws://localhost:8080/ws'
    }
  }
})
