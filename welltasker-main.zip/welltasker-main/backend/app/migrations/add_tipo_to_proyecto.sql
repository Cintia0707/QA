-- Añadir columna tipo a la tabla proyecto
ALTER TABLE proyecto ADD COLUMN tipo VARCHAR(50);
 
-- Actualizar registros existentes
UPDATE proyecto SET tipo = 'proyecto' WHERE tipo IS NULL; 