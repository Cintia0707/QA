from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from ..database import get_db
from ..models.project import Proyecto
from ..models.user import Usuario
from ..models.user_project import UsuarioProyecto
from ..schemas.project import ProyectoCreate, ProyectoResponse
from ..middleware.auth import get_current_user

router = APIRouter(
    prefix="/projects",
    tags=["projects"]
)

@router.get("/", response_model=List[ProyectoResponse])
async def get_user_projects(
    rol_id: Optional[int] = Query(None, description="Filtrar por rol específico"),
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Obtener todos los proyectos donde el usuario es miembro
        query = db.query(Proyecto).join(
            UsuarioProyecto,
            Proyecto.id_proyecto == UsuarioProyecto.id_proyecto
        ).filter(UsuarioProyecto.id_usuario == current_user.id_usuario)
        
        if rol_id is not None:
            query = query.filter(UsuarioProyecto.rol_id == rol_id)
            
        proyectos = query.all()
        
        # Obtener el rol del usuario en cada proyecto
        proyectos_con_rol = []
        for proyecto in proyectos:
            usuario_proyecto = db.query(UsuarioProyecto).filter(
                UsuarioProyecto.id_proyecto == proyecto.id_proyecto,
                UsuarioProyecto.id_usuario == current_user.id_usuario
            ).first()
            
            proyecto_dict = {
                "id_proyecto": proyecto.id_proyecto,
                "nombre": proyecto.nombre,
                "descripcion": proyecto.descripcion,
                "fecha_inicio": proyecto.fecha_inicio,
                "fecha_limite": proyecto.fecha_limite,
                "estado": proyecto.estado,
                "id_creador": proyecto.id_creador,
                "rol_id": usuario_proyecto.rol_id if usuario_proyecto else None
            }
            proyectos_con_rol.append(proyecto_dict)
            
        return proyectos_con_rol
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/", response_model=ProyectoResponse)
async def create_project(
    project: ProyectoCreate,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        # Crear el proyecto
        db_project = Proyecto(
            nombre=project.nombre,
            descripcion=project.descripcion,
            fecha_inicio=project.fecha_inicio,
            fecha_limite=project.fecha_limite,
            estado=project.estado,
            tipo=project.tipo,
            id_creador=current_user.id_usuario
        )
        
        db.add(db_project)
        db.flush()  # Para obtener el ID del proyecto antes de hacer commit
        
        # Añadir al creador como administrador
        db_member = UsuarioProyecto(
            id_usuario=current_user.id_usuario,
            id_proyecto=db_project.id_proyecto,
            rol_id=2,  # Administrador
            funcion='Creador del Proyecto'
        )
        
        db.add(db_member)
        db.commit()
        db.refresh(db_project)
        
        # Devolver el proyecto con el rol del usuario
        return {
            **db_project.__dict__,
            "rol_id": 2  # El creador siempre es administrador
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/{project_id}", response_model=ProyectoResponse)
async def update_project(
    project_id: int,
    project: ProyectoCreate,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == project_id).first()
        if not proyecto:
            raise HTTPException(status_code=404, detail="Proyecto no encontrado")
        
        # Verificar que el usuario tiene permisos (es el creador o tiene rol de administrador)
        usuario_proyecto = db.query(UsuarioProyecto).filter(
            UsuarioProyecto.id_proyecto == project_id,
            UsuarioProyecto.id_usuario == current_user.id_usuario
        ).first()
        
        if not usuario_proyecto or (usuario_proyecto.rol_id != 1 and proyecto.id_creador != current_user.id_usuario):
            raise HTTPException(status_code=403, detail="No tienes permisos para editar este proyecto")
        
        # Actualizar el proyecto
        proyecto.nombre = project.nombre
        proyecto.descripcion = project.descripcion
        proyecto.fecha_inicio = project.fecha_inicio
        proyecto.fecha_limite = project.fecha_limite
        proyecto.estado = project.estado
        
        db.commit()
        db.refresh(proyecto)
        
        # Devolver el proyecto actualizado con el rol del usuario
        return {
            **proyecto.__dict__,
            "rol_id": usuario_proyecto.rol_id
        }
    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{project_id}")
async def delete_project(
    project_id: int,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == project_id).first()
        if not proyecto:
            raise HTTPException(status_code=404, detail="Proyecto no encontrado")
        
        # Verificar que el usuario es el creador del proyecto
        if proyecto.id_creador != current_user.id_usuario:
            raise HTTPException(status_code=403, detail="Solo el creador puede eliminar el proyecto")
        
        # Eliminar todas las relaciones de usuarios con el proyecto
        db.query(UsuarioProyecto).filter(UsuarioProyecto.id_proyecto == project_id).delete()
        
        # Eliminar el proyecto
        db.delete(proyecto)
        db.commit()
        
        return {"message": "Proyecto eliminado exitosamente"}
    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{project_id}/users")
async def add_user_to_project(
    project_id: int,
    user_data: dict,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == project_id).first()
        if not proyecto:
            raise HTTPException(status_code=404, detail="Proyecto no encontrado")
        
        # Verificar que el usuario tiene permisos (es el creador o tiene rol de administrador)
        usuario_proyecto = db.query(UsuarioProyecto).filter(
            UsuarioProyecto.id_proyecto == project_id,
            UsuarioProyecto.id_usuario == current_user.id_usuario
        ).first()
        
        if not usuario_proyecto or (usuario_proyecto.rol_id != 1 and proyecto.id_creador != current_user.id_usuario):
            raise HTTPException(status_code=403, detail="No tienes permisos para añadir usuarios al proyecto")
        
        # Verificar que el usuario a añadir existe
        usuario = db.query(Usuario).filter(Usuario.id_usuario == user_data["id_usuario"]).first()
        if not usuario:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        
        # Verificar que el usuario no es ya miembro del proyecto
        existing_member = db.query(UsuarioProyecto).filter(
            UsuarioProyecto.id_proyecto == project_id,
            UsuarioProyecto.id_usuario == user_data["id_usuario"]
        ).first()
        
        if existing_member:
            raise HTTPException(status_code=400, detail="El usuario ya es miembro del proyecto")
        
        # Añadir el usuario al proyecto con solo los datos necesarios
        nuevo_miembro = UsuarioProyecto(
            id_usuario=user_data["id_usuario"],
            id_proyecto=project_id,
            rol_id=user_data["rol_id"],
            funcion=user_data.get("funcion", "")  # Hacemos la función opcional
        )
        
        db.add(nuevo_miembro)
        db.commit()
        
        return {
            "message": "Usuario añadido al proyecto exitosamente",
            "id_usuario": user_data["id_usuario"],
            "id_proyecto": project_id,
            "rol_id": user_data["rol_id"]
        }
    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_id}/members")
async def get_project_members(
    project_id: int,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == project_id).first()
        if not proyecto:
            return {"total_miembros": 0, "miembros": []}
        
        # Verificar que el usuario es miembro del proyecto
        usuario_proyecto = db.query(UsuarioProyecto).filter(
            UsuarioProyecto.id_proyecto == project_id,
            UsuarioProyecto.id_usuario == current_user.id_usuario
        ).first()
        
        if not usuario_proyecto:
            return {"total_miembros": 0, "miembros": []}
        
        # Obtener todos los miembros del proyecto con sus roles
        miembros = db.query(
            Usuario,
            UsuarioProyecto.rol_id,
            UsuarioProyecto.funcion
        ).join(
            UsuarioProyecto,
            Usuario.id_usuario == UsuarioProyecto.id_usuario
        ).filter(
            UsuarioProyecto.id_proyecto == project_id
        ).all()
        
        # Formatear la respuesta
        miembros_formateados = []
        for usuario, rol_id, funcion in miembros:
            miembros_formateados.append({
                "id_usuario": usuario.id_usuario,
                "nombre": usuario.nombre,
                "email": usuario.email,
                "rol_id": rol_id,
                "funcion": funcion
            })
        
        return {
            "total_miembros": len(miembros_formateados),
            "miembros": miembros_formateados
        }
        
    except Exception as e:
        print(f"Error en get_project_members: {str(e)}")
        return {"total_miembros": 0, "miembros": []}

@router.get("/{project_id}/members/count")
async def get_project_members_count(
    project_id: int,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == project_id).first()
        if not proyecto:
            raise HTTPException(status_code=404, detail="Proyecto no encontrado")
        
        # Verificar que el usuario es miembro del proyecto
        usuario_proyecto = db.query(UsuarioProyecto).filter(
            UsuarioProyecto.id_proyecto == project_id,
            UsuarioProyecto.id_usuario == current_user.id_usuario
        ).first()
        
        if not usuario_proyecto:
            raise HTTPException(status_code=403, detail="No tienes acceso a este proyecto")
        
        # Consulta simple para contar miembros
        count = db.query(func.count(UsuarioProyecto.id_usuario)).filter(
            UsuarioProyecto.id_proyecto == project_id
        ).scalar()
        
        return {"members_count": count or 0}
        
    except Exception as e:
        print(f"Error en get_project_members_count: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e)) 