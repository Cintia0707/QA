from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from jose import jwt
from passlib.context import CryptContext
import base64

from ..database import get_db
from ..models.user import Usuario
from ..schemas.user import UsuarioCreate, UsuarioResponse, Token, UsuarioLogin
from ..config import settings

router = APIRouter(prefix="/auth", tags=["auth"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)

@router.post("/register", response_model=UsuarioResponse)
async def register(user: UsuarioCreate, db: Session = Depends(get_db)):
    # Verificar si el usuario ya existe
    db_user = db.query(Usuario).filter(Usuario.email == user.email).first()
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El email ya está registrado"
        )
    
    # Procesar avatar si existe
    avatar_bytes = None
    if user.avatar:
        try:
            # Eliminar el prefijo data:image/...;base64, si existe
            if "base64," in user.avatar:
                avatar_data = user.avatar.split("base64,")[1]
            else:
                avatar_data = user.avatar
            avatar_bytes = base64.b64decode(avatar_data)
        except Exception as e:
            print(f"Error procesando avatar: {e}")
    
    # Crear nuevo usuario
    hashed_password = get_password_hash(user.contrasena)
    db_user = Usuario(
        nombre=user.nombre,
        email=user.email,
        contrasena=hashed_password,
        avatar=avatar_bytes
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    # Convertir avatar a base64 para la respuesta
    if db_user.avatar:
        db_user.avatar = base64.b64encode(db_user.avatar).decode()
    
    return db_user

@router.post("/login", response_model=Token)
async def login(form_data: UsuarioLogin, db: Session = Depends(get_db)):
    user = db.query(Usuario).filter(Usuario.email == form_data.email).first()

    
    access_token = create_access_token(data={"id": user.id_usuario})
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=UsuarioResponse)
async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        user_id = payload.get("id")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido"
            )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido"
        )
    
    user = db.query(Usuario).filter(Usuario.id_usuario == user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuario no encontrado"
        )
    
    # Convertir avatar a base64 para la respuesta
    if user.avatar:
        user.avatar = base64.b64encode(user.avatar).decode()
    
    return user 