from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..database import get_db
from ..models.user_project import UsuarioProyecto
from ..models.user import Usuario
from ..models.role import Rol
from ..schemas.user_project import UsuarioProyectoResponse
from ..auth import get_current_user

router = APIRouter()

@router.get("/project/{project_id}/members", response_model=List[UsuarioProyectoResponse])
async def get_project_members(
    project_id: int,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Obtener todos los miembros del proyecto con sus roles y funciones
        members = db.query(
            UsuarioProyecto,
            Usuario,
            Rol
        ).join(
            Usuario,
            UsuarioProyecto.id_usuario == Usuario.id_usuario
        ).join(
            Rol,
            UsuarioProyecto.rol_id == Rol.id_rol
        ).filter(
            UsuarioProyecto.id_proyecto == project_id
        ).all()

        # Formatear la respuesta
        formatted_members = []
        for member, user, role in members:
            formatted_members.append({
                "id_usuario": user.id_usuario,
                "nombre": user.nombre,
                "email": user.email,
                "avatar": user.avatar,
                "rol_id": role.id_rol,
                "rol_nombre": role.nombre,
                "funcion": member.funcion
            })

        return formatted_members

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 