from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import base64
from ..database import get_db
from ..models.user import Usuario
from ..middleware.auth import get_current_user

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/")
async def get_all_users(db: Session = Depends(get_db)):
    try:
        users = db.query(Usuario).all()
        return [{
            "id_usuario": user.id_usuario,
            "nombre": user.nombre,
            "apellido": user.apellido,
            "email": user.email,
            "avatar": base64.b64encode(user.avatar).decode() if user.avatar else None
        } for user in users]
    except Exception as e:
        print(f"Error en get_all_users: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{user_id}")
async def get_user_by_id(user_id: int, db: Session = Depends(get_db)):
    try:
        user = db.query(Usuario).filter(Usuario.id_usuario == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        
        # Convertir avatar a base64 si existe
        avatar_base64 = None
        if user.avatar:
            try:
                avatar_base64 = base64.b64encode(user.avatar).decode()
            except Exception as e:
                print(f"Error al convertir avatar: {e}")
        
        return {
            "id_usuario": user.id_usuario,
            "nombre": user.nombre,
            "apellido": user.apellido,
            "email": user.email,
            "avatar": avatar_base64
        }
    except HTTPException as he:
        raise he
    except Exception as e:
        print(f"Error en get_user_by_id: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/search")
async def search_user_by_email(email: str, db: Session = Depends(get_db), current_user: Usuario = Depends(get_current_user)):
    try:
        user = db.query(Usuario).filter(Usuario.email == email).first()
        if not user:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        
        # Convertir avatar a base64 si existe
        avatar_base64 = None
        if user.avatar:
            try:
                avatar_base64 = base64.b64encode(user.avatar).decode()
            except Exception as e:
                print(f"Error al convertir avatar: {e}")
        
        return {
            "id_usuario": user.id_usuario,
            "nombre": user.nombre,
            "email": user.email,
            "avatar": avatar_base64
        }
    except HTTPException as he:
        raise he
    except Exception as e:
        print(f"Error en search_user_by_email: {e}")
        raise HTTPException(status_code=500, detail=str(e)) 