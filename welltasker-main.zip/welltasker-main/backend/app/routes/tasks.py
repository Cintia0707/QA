from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models.task import Tarea
from ..models.project import Proyecto
from ..models.user import Usuario
from ..models.user_project import UsuarioProyecto
from ..schemas.task import TareaCreate, TareaResponse
from ..middleware.auth import get_current_user
import base64

router = APIRouter(
    prefix="/tasks",
    tags=["tasks"]
)

@router.get("/", response_model=List[TareaResponse])
async def get_tasks(
    project_id: Optional[int] = Query(None, description="Filtrar por proyecto específico"),
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Construir la consulta base con join a la tabla de usuarios y usuario_proyecto
        query = db.query(
            Tarea,
            Usuario.nombre.label('nombre_asignado'),
            Usuario.avatar.label('avatar_asignado'),
            UsuarioProyecto.rol_id.label('rol_id')
        ).outerjoin(
            Usuario,
            Tarea.id_asignado == Usuario.id_usuario
        ).outerjoin(
            UsuarioProyecto,
            (Tarea.id_proyecto == UsuarioProyecto.id_proyecto) & 
            (current_user.id_usuario == UsuarioProyecto.id_usuario)
        )

        # Aplicar filtro de proyecto si se especifica
        if project_id:
            query = query.filter(Tarea.id_proyecto == project_id)

        # Obtener los resultados
        results = query.all()
        
        # Formatear la respuesta
        tasks = []
        for task, nombre_asignado, avatar_asignado, rol_id in results:
            task_dict = {
                "id_tarea": task.id_tarea,
                "titulo": task.titulo,
                "descripcion": task.descripcion,
                "fecha_creacion": task.fecha_creacion,
                "fecha_vencimiento": task.fecha_vencimiento,
                "prioridad": task.prioridad,
                "estado": task.estado,
                "id_proyecto": task.id_proyecto,
                "id_asignado": task.id_asignado,
                "nombre_asignado": nombre_asignado,
                "avatar_asignado": base64.b64encode(avatar_asignado).decode() if avatar_asignado else None,
                "rol_id": rol_id
            }
            tasks.append(task_dict)

        return tasks

    except Exception as e:
        print(f"Error en get_tasks: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/", response_model=TareaResponse)
async def create_task(
    task: TareaCreate,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == task.id_proyecto).first()
        if not proyecto:
            raise HTTPException(status_code=404, detail="Proyecto no encontrado")

        # Verificar que el usuario asignado existe
        if task.id_asignado:
            asignado = db.query(Usuario).filter(Usuario.id_usuario == task.id_asignado).first()
            if not asignado:
                raise HTTPException(status_code=404, detail="Usuario asignado no encontrado")

        # Crear la tarea
        db_task = Tarea(
            titulo=task.titulo,
            descripcion=task.descripcion,
            fecha_vencimiento=task.fecha_vencimiento,
            prioridad=task.prioridad,
            estado=task.estado,
            id_proyecto=task.id_proyecto,
            id_asignado=task.id_asignado
        )

        db.add(db_task)
        db.commit()
        db.refresh(db_task)

        return db_task

    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/{task_id}", response_model=TareaResponse)
async def update_task(
    task_id: int,
    task: TareaCreate,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que la tarea existe
        db_task = db.query(Tarea).filter(Tarea.id_tarea == task_id).first()
        if not db_task:
            raise HTTPException(status_code=404, detail="Tarea no encontrada")

        # Verificar que el proyecto existe
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == task.id_proyecto).first()
        if not proyecto:
            raise HTTPException(status_code=404, detail="Proyecto no encontrado")

        # Verificar que el usuario asignado existe
        if task.id_asignado:
            asignado = db.query(Usuario).filter(Usuario.id_usuario == task.id_asignado).first()
            if not asignado:
                raise HTTPException(status_code=404, detail="Usuario asignado no encontrado")

        # Actualizar la tarea
        db_task.titulo = task.titulo
        db_task.descripcion = task.descripcion
        db_task.fecha_vencimiento = task.fecha_vencimiento
        db_task.prioridad = task.prioridad
        db_task.estado = task.estado
        db_task.id_proyecto = task.id_proyecto
        db_task.id_asignado = task.id_asignado

        db.commit()
        db.refresh(db_task)

        return db_task

    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{task_id}")
async def delete_task(
    task_id: int,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        # Verificar que la tarea existe
        db_task = db.query(Tarea).filter(Tarea.id_tarea == task_id).first()
        if not db_task:
            raise HTTPException(status_code=404, detail="Tarea no encontrada")

        # Eliminar la tarea
        db.delete(db_task)
        db.commit()

        return {"message": "Tarea eliminada exitosamente"}

    except HTTPException as he:
        raise he
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e)) 