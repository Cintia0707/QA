from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class UsuarioBase(BaseModel):
    nombre: str
    email: EmailStr

class UsuarioCreate(UsuarioBase):
    contrasena: str
    avatar: Optional[str] = None

class UsuarioLogin(BaseModel):
    email: EmailStr
    contrasena: str

class UsuarioResponse(UsuarioBase):
    id_usuario: int
    fecha_registro: datetime
    fecha_ultima_edicion: datetime
    avatar: Optional[str] = None

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    id_usuario: Optional[int] = None 