from pydantic import BaseModel
from typing import Optional

class UsuarioProyectoResponse(BaseModel):
    id_usuario: int
    nombre: str
    email: str
    avatar: Optional[str] = None
    rol_id: int
    rol_nombre: str
    funcion: Optional[str] = None

    class Config:
        from_attributes = True 