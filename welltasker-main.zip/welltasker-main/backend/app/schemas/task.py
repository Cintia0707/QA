from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class TareaBase(BaseModel):
    titulo: str
    descripcion: Optional[str] = None
    fecha_vencimiento: Optional[datetime] = None
    prioridad: str = 'media'
    estado: str = 'pendiente'
    id_proyecto: int
    id_asignado: Optional[int] = None

class TareaCreate(TareaBase):
    pass

class TareaResponse(TareaBase):
    id_tarea: int
    fecha_creacion: datetime
    nombre_proyecto: Optional[str] = None
    nombre_asignado: Optional[str] = None
    avatar_asignado: Optional[str] = None

    class Config:
        from_attributes = True 