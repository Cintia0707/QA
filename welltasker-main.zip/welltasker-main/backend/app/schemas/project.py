from pydantic import BaseModel
from typing import Optional, List
from datetime import date

class ProyectoBase(BaseModel):
    nombre: str
    descripcion: Optional[str] = None
    fecha_inicio: date
    fecha_limite: Optional[date] = None
    estado: str = 'activo'
    tipo: Optional[str] = None

class ProyectoCreate(ProyectoBase):
    pass

class ProyectoResponse(ProyectoBase):
    id_proyecto: int
    id_creador: int
    rol_id: Optional[int] = None

    class Config:
        from_attributes = True 