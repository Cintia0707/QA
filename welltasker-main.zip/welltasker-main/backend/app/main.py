from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routes import auth, projects, users, tasks
from .database import engine, Base

# Crear las tablas en la base de datos
Base.metadata.create_all(bind=engine)

app = FastAPI(title="WellTasker API")

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080"],  # URL del frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"]
)

# Incluir routers
app.include_router(auth.router)
app.include_router(projects.router)
app.include_router(users.router)
app.include_router(tasks.router)

@app.get("/")
async def root():
    return {"message": "Bienvenido a la API de WellTasker"} 