from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy.orm import Session
from ..database import get_db
from ..models.user import Usuario
from ..schemas.user import TokenData
from ..config import settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Usuario:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="No se pudieron validar las credenciales",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET,
            algorithms=[settings.JWT_ALGORITHM]
        )
        id_usuario: int = payload.get("id")
        if id_usuario is None:
            raise credentials_exception
        token_data = TokenData(id_usuario=id_usuario)
    except JWTError:
        raise credentials_exception
        
    user = db.query(Usuario).filter(Usuario.id_usuario == token_data.id_usuario).first()
    if user is None:
        raise credentials_exception
        
    return user 