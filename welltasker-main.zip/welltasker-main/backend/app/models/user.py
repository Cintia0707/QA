from sqlalchemy import Column, Integer, String, DateTime, LargeBinary
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from ..database import Base

class Usuario(Base):
    __tablename__ = "usuario"

    id_usuario = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    contrasena = Column(String(255), nullable=False)
    fecha_registro = Column(DateTime(timezone=True), server_default=func.now())
    fecha_ultima_edicion = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    avatar = Column(LargeBinary, nullable=True)

    # Relaciones
    proyectos_creados = relationship("Proyecto", back_populates="creador", foreign_keys="Proyecto.id_creador")
    proyectos_miembro = relationship("UsuarioProyecto", back_populates="usuario", cascade="all, delete-orphan")