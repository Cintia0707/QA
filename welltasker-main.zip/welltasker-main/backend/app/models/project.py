from sqlalchemy import Column, Integer, String, Text, Date, ForeignKey
from sqlalchemy.orm import relationship
from ..database import Base

class Proyecto(Base):
    __tablename__ = "proyecto"

    id_proyecto = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(String(500))
    fecha_inicio = Column(Date, nullable=False)
    fecha_limite = Column(Date)
    estado = Column(String(20), default='activo')
    tipo = Column(String(50))
    id_creador = Column(Integer, ForeignKey('usuario.id_usuario'))

    # Relaciones
    creador = relationship("Usuario", back_populates="proyectos_creados")
    miembros = relationship("UsuarioProyecto", back_populates="proyecto") 