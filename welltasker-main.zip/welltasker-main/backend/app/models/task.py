from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum
from sqlalchemy.sql import func
from ..database import Base

class Tarea(Base):
    __tablename__ = "tarea"

    id_tarea = Column(Integer, primary_key=True, index=True)
    titulo = Column(String(100), nullable=False)
    descripcion = Column(String(500))
    fecha_creacion = Column(DateTime(timezone=True), server_default=func.now())
    fecha_vencimiento = Column(DateTime(timezone=True))
    prioridad = Column(Enum('alta', 'media', 'baja', name='prioridad_tarea'), default='media')
    estado = Column(Enum('pendiente', 'en_progreso', 'completada', name='estado_tarea'), default='pendiente')
    id_proyecto = Column(Integer, ForeignKey('proyecto.id_proyecto'), nullable=False)
    id_asignado = Column(Integer, ForeignKey('usuario.id_usuario')) 