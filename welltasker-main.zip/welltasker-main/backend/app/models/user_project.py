from sqlalchemy import Column, Integer, ForeignKey, String
from sqlalchemy.orm import relationship
from ..database import Base

class UsuarioProyecto(Base):
    __tablename__ = "usuarioproyecto"

    id_usuario = Column(Integer, ForeignKey('usuario.id_usuario'), primary_key=True)
    id_proyecto = Column(Integer, ForeignKey('proyecto.id_proyecto'), primary_key=True)
    rol_id = Column(Integer, ForeignKey('rol.id_rol'), nullable=False)
    funcion = Column(String(255))

    # Relaciones
    usuario = relationship("Usuario", back_populates="proyectos_miembro")
    proyecto = relationship("Proyecto", back_populates="miembros")
    rol = relationship("Rol", back_populates="usuarios_proyectos", lazy="joined") 